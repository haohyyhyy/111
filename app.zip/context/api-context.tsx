"use client"

import { createContext, useState, useEffect, type ReactNode } from "react"

interface DeepSeekConfig {
  apiKey: string
  model: "deepseek-r1" | "deepseek-v3"
  contextCount: number
  showThinking: boolean
  streamOutput: boolean
  maxTokens: number
  temperature: number
  connected: boolean
  jsonMode: boolean // 新增JSON模式控制
}

interface ApiContextType {
  deepseekConfig: DeepSeekConfig
  updateDeepseekConfig: (config: Partial<DeepSeekConfig>) => void
  testDeepseekConnection: () => Promise<{ success: boolean; message: string }>
}

export const ApiContext = createContext<ApiContextType>({
  deepseekConfig: {
    apiKey: "",
    model: "deepseek-v3",
    contextCount: 4,
    showThinking: false,
    streamOutput: true,
    maxTokens: 1000,
    temperature: 0.7,
    connected: false,
    jsonMode: false, // 默认关闭JSON模式
  },
  updateDeepseekConfig: () => {},
  testDeepseekConnection: async () => ({ success: false, message: "" }),
})

export function ApiProvider({ children }: { children: ReactNode }) {
  const [deepseekConfig, setDeepseekConfig] = useState<DeepSeekConfig>({
    apiKey: "",
    model: "deepseek-v3",
    contextCount: 4,
    showThinking: false,
    streamOutput: true,
    maxTokens: 1000,
    temperature: 0.7,
    connected: false,
    jsonMode: false, // 默认关闭JSON模式
  })

  // 从本地存储加载配置
  useEffect(() => {
    const storedConfig = localStorage.getItem("deepseekConfig")
    if (storedConfig) {
      const parsedConfig = JSON.parse(storedConfig)
      // 确保model只能是deepseek-r1或deepseek-v3
      if (parsedConfig.model !== "deepseek-r1" && parsedConfig.model !== "deepseek-v3") {
        parsedConfig.model = "deepseek-v3"
      }
      setDeepseekConfig(parsedConfig)
    }
  }, [])

  // 保存配置到本地存储
  useEffect(() => {
    localStorage.setItem("deepseekConfig", JSON.stringify(deepseekConfig))
  }, [deepseekConfig])

  // 更新配置
  const updateDeepseekConfig = (config: Partial<DeepSeekConfig>) => {
    setDeepseekConfig((prev) => ({ ...prev, ...config }))
  }

  // 测试连接
  const testDeepseekConnection = async () => {
    if (!deepseekConfig.apiKey) {
      return { success: false, message: "请输入API密钥" }
    }

    try {
      // 验证API密钥格式
      if (!deepseekConfig.apiKey.startsWith("sk-")) {
        return { success: false, message: "API密钥格式错误，应以sk-开头" }
      }

      // 尝试调用DeepSeek API
      try {
        const response = await fetch("https://api.deepseek.com/v1/models", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${deepseekConfig.apiKey}`,
          },
        })

        if (response.ok) {
          updateDeepseekConfig({ connected: true })
          return { success: true, message: "连接成功！API密钥有效。" }
        } else {
          const errorData = await response.json()
          return { success: false, message: `API错误: ${errorData.error?.message || response.statusText}` }
        }
      } catch (error) {
        return { success: false, message: `连接失败: ${error instanceof Error ? error.message : "未知错误"}` }
      }
    } catch (error) {
      return {
        success: false,
        message: error instanceof Error ? error.message : "未知错误",
      }
    }
  }

  return (
    <ApiContext.Provider
      value={{
        deepseekConfig,
        updateDeepseekConfig,
        testDeepseekConnection,
      }}
    >
      {children}
    </ApiContext.Provider>
  )
}

