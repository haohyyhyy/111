"use client"

import { createContext, useState, useEffect, useRef, useCallback, type ReactNode } from "react"
import { useContext } from "react"
import { UserContext } from "./user-context"

interface SettingsContextType {
  voiceEnabled: boolean
  setVoiceEnabled: (enabled: boolean) => void
  fontSize: number
  setFontSize: (size: number) => void
  darkMode: boolean
  setDarkMode: (enabled: boolean) => void
  adminDarkMode: boolean
  setAdminDarkMode: (enabled: boolean) => void
  hapticFeedback: boolean
  setHapticFeedback: (enabled: boolean) => void
  notifications: boolean
  setNotifications: (enabled: boolean) => void
}

export const SettingsContext = createContext<SettingsContextType>({
  voiceEnabled: false,
  setVoiceEnabled: () => {},
  fontSize: 16,
  setFontSize: () => {},
  darkMode: false,
  setDarkMode: () => {},
  adminDarkMode: false,
  setAdminDarkMode: () => {},
  hapticFeedback: false,
  setHapticFeedback: () => {},
  notifications: false,
  setNotifications: () => {},
})

// 修改 SettingsProvider 组件，防止无限循环更新
export function SettingsProvider({ children }: { children: ReactNode }) {
  const { currentUser } = useContext(UserContext)
  const userId = currentUser?.id || "guest"

  // 使用 useRef 来跟踪是否已经从本地存储加载过设置
  const hasLoadedSettings = useRef(false)

  const [voiceEnabled, setVoiceEnabled] = useState(false)
  const [fontSize, setFontSize] = useState(16)
  const [darkMode, setDarkMode] = useState(false)
  const [adminDarkMode, setAdminDarkMode] = useState(false)
  const [hapticFeedback, setHapticFeedback] = useState(false)
  const [notifications, setNotifications] = useState(true)

  // 从本地存储加载设置 - 使用用户ID作为前缀
  useEffect(() => {
    // 防止重复加载设置
    if (hasLoadedSettings.current) return

    try {
      const storedVoiceEnabled = localStorage.getItem(`${userId}_voiceEnabled`)
      if (storedVoiceEnabled) {
        setVoiceEnabled(storedVoiceEnabled === "true")
      }

      const storedFontSize = localStorage.getItem(`${userId}_fontSize`)
      if (storedFontSize) {
        setFontSize(Number.parseInt(storedFontSize))
      }

      const storedTheme = localStorage.getItem(`${userId}_theme`)
      const systemPrefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches
      const isDarkMode = storedTheme === "dark" || (!storedTheme && systemPrefersDark)
      setDarkMode(isDarkMode)

      const storedAdminTheme = localStorage.getItem("adminTheme") // 管理员主题不需要用户前缀
      const isAdminDarkMode = storedAdminTheme === "dark" || (!storedAdminTheme && systemPrefersDark)
      setAdminDarkMode(isAdminDarkMode)

      const storedHapticFeedback = localStorage.getItem(`${userId}_hapticFeedback`)
      if (storedHapticFeedback) {
        setHapticFeedback(storedHapticFeedback === "true")
      }

      const storedNotifications = localStorage.getItem(`${userId}_notifications`)
      if (storedNotifications) {
        setNotifications(storedNotifications === "true")
      }

      // 应用主题
      if (isDarkMode) {
        document.documentElement.classList.add("dark")
      } else {
        document.documentElement.classList.remove("dark")
      }

      // 标记已加载设置
      hasLoadedSettings.current = true
    } catch (error) {
      console.error("Error loading settings:", error)
    }
  }, [userId])

  // 使用 useCallback 包装设置更新函数，避免不必要的重新渲染
  const handleVoiceEnabledChange = useCallback(
    (value: boolean) => {
      setVoiceEnabled(value)
      try {
        localStorage.setItem(`${userId}_voiceEnabled`, value.toString())
      } catch (error) {
        console.error("Error saving voiceEnabled setting:", error)
      }
    },
    [userId],
  )

  const handleFontSizeChange = useCallback(
    (value: number) => {
      setFontSize(value)
      try {
        localStorage.setItem(`${userId}_fontSize`, value.toString())
      } catch (error) {
        console.error("Error saving fontSize setting:", error)
      }
    },
    [userId],
  )

  const handleDarkModeChange = useCallback(
    (value: boolean) => {
      setDarkMode(value)
      try {
        localStorage.setItem(`${userId}_theme`, value ? "dark" : "light")
        if (value) {
          document.documentElement.classList.add("dark")
        } else {
          document.documentElement.classList.remove("dark")
        }
      } catch (error) {
        console.error("Error saving darkMode setting:", error)
      }
    },
    [userId],
  )

  const handleAdminDarkModeChange = useCallback((value: boolean) => {
    setAdminDarkMode(value)
    try {
      localStorage.setItem("adminTheme", value ? "dark" : "light")
    } catch (error) {
      console.error("Error saving adminDarkMode setting:", error)
    }
  }, [])

  const handleHapticFeedbackChange = useCallback(
    (value: boolean) => {
      setHapticFeedback(value)
      try {
        localStorage.setItem(`${userId}_hapticFeedback`, value.toString())
      } catch (error) {
        console.error("Error saving hapticFeedback setting:", error)
      }
    },
    [userId],
  )

  const handleNotificationsChange = useCallback(
    (value: boolean) => {
      setNotifications(value)
      try {
        localStorage.setItem(`${userId}_notifications`, value.toString())
      } catch (error) {
        console.error("Error saving notifications setting:", error)
      }
    },
    [userId],
  )

  return (
    <SettingsContext.Provider
      value={{
        voiceEnabled,
        setVoiceEnabled: handleVoiceEnabledChange,
        fontSize,
        setFontSize: handleFontSizeChange,
        darkMode,
        setDarkMode: handleDarkModeChange,
        adminDarkMode,
        setAdminDarkMode: handleAdminDarkModeChange,
        hapticFeedback,
        setHapticFeedback: handleHapticFeedbackChange,
        notifications,
        setNotifications: handleNotificationsChange,
      }}
    >
      {children}
    </SettingsContext.Provider>
  )
}

