"use client"

import { createContext, useState, useEffect, type ReactNode } from "react"

interface FontSizeContextType {
  fontSize: number
  setFontSize: (size: number) => void
}

export const FontSizeContext = createContext<FontSizeContextType>({
  fontSize: 16,
  setFontSize: () => {},
})

export function FontSizeProvider({ children }: { children: ReactNode }) {
  const [fontSize, setFontSize] = useState(16)

  // 从本地存储加载字体大小设置
  useEffect(() => {
    const storedFontSize = localStorage.getItem("fontSize")
    if (storedFontSize) {
      setFontSize(Number.parseInt(storedFontSize))
    }
  }, [])

  // 保存字体大小设置到本地存储
  const handleSetFontSize = (size: number) => {
    setFontSize(size)
    localStorage.setItem("fontSize", size.toString())
  }

  return (
    <FontSizeContext.Provider value={{ fontSize, setFontSize: handleSetFontSize }}>{children}</FontSizeContext.Provider>
  )
}

