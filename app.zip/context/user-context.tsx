"use client"

import { createContext, useState, useEffect, type ReactNode } from "react"

// 用户类型定义
export interface User {
  id: string
  phone: string
  password: string
  key: string
}

// 管理员类型定义
export interface Admin {
  username: string
  password: string
}

// 上下文类型定义
interface UserContextType {
  users: User[]
  addUser: (user: User) => void
  updateUser: (user: User) => void
  currentUser: User | null
  setCurrentUser: (user: User | null) => void
  admin: Admin
  updateAdmin: (admin: Admin) => void
  isPhoneRegistered: (phone: string) => boolean
  generateKey: () => string
}

// 创建上下文
export const UserContext = createContext<UserContextType>({
  users: [],
  addUser: () => {},
  updateUser: () => {},
  currentUser: null,
  setCurrentUser: () => {},
  admin: { username: "hyy", password: "123456" },
  updateAdmin: () => {},
  isPhoneRegistered: () => false,
  generateKey: () => "",
})

// 上下文提供者组件
export function UserProvider({ children }: { children: ReactNode }) {
  // 初始用户列表
  const [users, setUsers] = useState<User[]>([
    { id: "1", phone: "13800138000", password: "123456", key: "ai-yonghu-1a2b3" },
    { id: "2", phone: "13900139000", password: "123456", key: "ai-yonghu-4c5d6" },
  ])

  // 当前登录用户
  const [currentUser, setCurrentUser] = useState<User | null>(null)

  // 管理员信息
  const [admin, setAdmin] = useState<Admin>({ username: "hyy", password: "123456" })

  // 从本地存储加载数据
  useEffect(() => {
    const storedUsers = localStorage.getItem("users")
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers))
    }

    const storedAdmin = localStorage.getItem("admin")
    if (storedAdmin) {
      setAdmin(JSON.parse(storedAdmin))
    }

    const storedCurrentUser = localStorage.getItem("currentUser")
    if (storedCurrentUser) {
      setCurrentUser(JSON.parse(storedCurrentUser))
    }
  }, [])

  // 保存数据到本地存储
  useEffect(() => {
    localStorage.setItem("users", JSON.stringify(users))
  }, [users])

  useEffect(() => {
    localStorage.setItem("admin", JSON.stringify(admin))
  }, [admin])

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem("currentUser", JSON.stringify(currentUser))
    }
  }, [currentUser])

  // 添加新用户
  const addUser = (user: User) => {
    setUsers((prev) => [...prev, user])
  }

  // 更新用户信息
  const updateUser = (updatedUser: User) => {
    setUsers((prev) => prev.map((user) => (user.id === updatedUser.id ? updatedUser : user)))

    // 如果更新的是当前用户，也更新当前用户状态
    if (currentUser && currentUser.id === updatedUser.id) {
      setCurrentUser(updatedUser)
    }
  }

  // 更新管理员信息
  const updateAdmin = (newAdmin: Admin) => {
    setAdmin(newAdmin)
  }

  // 检查手机号是否已注册
  const isPhoneRegistered = (phone: string) => {
    return users.some((user) => user.phone === phone)
  }

  // 生成唯一密钥
  const generateKey = () => {
    const prefix = "ai-yonghu-"
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
    let result = prefix
    for (let i = 0; i < 5; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  return (
    <UserContext.Provider
      value={{
        users,
        addUser,
        updateUser,
        currentUser,
        setCurrentUser,
        admin,
        updateAdmin,
        isPhoneRegistered,
        generateKey,
      }}
    >
      {children}
    </UserContext.Provider>
  )
}

