"use client"

import type React from "react"

import { useState, useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { UserContext } from "@/context/user-context"
import Image from "next/image"

export default function LoginPage() {
  const router = useRouter()
  const { users, admin, setCurrentUser } = useContext(UserContext)

  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [appIcon, setAppIcon] = useState("/placeholder.svg?height=80&width=80")

  // 从本地存储加载应用图标
  useEffect(() => {
    const storedIcon = localStorage.getItem("appIcon")
    if (storedIcon) {
      setAppIcon(storedIcon)
    }
  }, [])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // 检查是否是管理员登录
    if (username === admin.username && password === admin.password) {
      setTimeout(() => {
        setIsLoading(false)
        router.push("/admin")
      }, 800)
      return
    }

    // 检查是否是用户登录
    const user = users.find((user) => user.phone === username && user.password === password)
    if (user) {
      setCurrentUser(user)
      setTimeout(() => {
        setIsLoading(false)
        router.push("/chat")
      }, 800)
      return
    }

    // 登录失败
    setTimeout(() => {
      setError("用户名或密码错误")
      setIsLoading(false)
    }, 800)
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex items-center justify-center p-6">
      <div className="w-full max-w-[360px]">
        <div className="mb-12 flex justify-center">
          <div className="w-[80px] h-[80px] rounded-[24px] bg-black dark:bg-white flex items-center justify-center shadow-[0_8px_30px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_30px_rgba(255,255,255,0.12)] overflow-hidden">
            <Image
              src={appIcon || "/placeholder.svg"}
              alt="应用图标"
              width={80}
              height={80}
              className="object-cover w-full h-full"
              style={{ objectFit: "cover" }}
            />
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <div className="relative">
              <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="用户名/手机号"
                className="w-full h-[44px] px-5 rounded-full border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40"
                required
              />
            </div>
          </div>

          <div>
            <div className="relative">
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="密码"
                className="w-full h-[44px] px-5 rounded-full border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40"
                required
              />
            </div>
          </div>

          {error && <p className="text-red-500 text-center text-[14px]">{error}</p>}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[17px] font-[500] transition-all hover:opacity-90 disabled:opacity-50"
          >
            {isLoading ? "登录中..." : "登录"}
          </button>

          <div className="flex justify-between text-[14px] text-black/60 dark:text-white/60 pt-2">
            <button
              type="button"
              onClick={() => router.push("/register")}
              className="hover:text-black dark:hover:text-white transition-colors"
            >
              注册
            </button>
            <button
              type="button"
              onClick={() => router.push("/forgot-password")}
              className="hover:text-black dark:hover:text-white transition-colors"
            >
              忘记密码
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

