"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import ReactMarkdown from "react-markdown"

export default function AgreementPage() {
  const router = useRouter()
  const [agreement, setAgreement] = useState("")

  // 从本地存储加载用户协议
  useEffect(() => {
    const storedAgreement = localStorage.getItem("appAgreement")
    if (storedAgreement) {
      setAgreement(storedAgreement)
    }
  }, [])

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/settings")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">用户协议</h1>
      </header>

      <div className="p-6">
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <ReactMarkdown>{agreement}</ReactMarkdown>
        </div>
      </div>
    </div>
  )
}

