"use client"

import type React from "react"

import { useState, useRef, useContext } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { UserContext } from "@/context/user-context"

export default function UserSettingsPage() {
  const router = useRouter()
  const { currentUser, users, updateUser, isPhoneRegistered } = useContext(UserContext)

  const [showModal, setShowModal] = useState(false)
  const [avatar, setAvatar] = useState("/placeholder.svg?height=96&width=96")
  const [showPhoneModal, setShowPhoneModal] = useState(false)
  const [newPhone, setNewPhone] = useState("")
  const [phoneError, setPhoneError] = useState("")
  const [showWechatModal, setShowWechatModal] = useState(false)
  const [wechat, setWechat] = useState("")
  const [newWechat, setNewWechat] = useState("")

  const fileInputRef = useRef<HTMLInputElement>(null)

  // 检查用户是否已登录
  if (!currentUser) {
    router.push("/")
    return null
  }

  // 验证手机号格式
  const isValidPhone = (phone: string) => {
    return /^1[3-9]\d{9}$/.test(phone)
  }

  // 处理头像上传
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          setAvatar(e.target.result as string)
        }
      }
      reader.readAsDataURL(file)
    }
  }

  // 处理手机号修改
  const handlePhoneChange = () => {
    setPhoneError("")

    // 验证手机号
    if (!newPhone) {
      setPhoneError("请输入手机号")
      return
    }

    if (!isValidPhone(newPhone)) {
      setPhoneError("请输入正确的手机号")
      return
    }

    // 检查手机号是否已被其他用户注册
    if (newPhone !== currentUser.phone && isPhoneRegistered(newPhone)) {
      setPhoneError("此手机号已注册，请输入其他手机号")
      return
    }

    // 更新用户手机号
    updateUser({
      ...currentUser,
      phone: newPhone,
    })

    setShowPhoneModal(false)
  }

  // 处理微信绑定
  const handleWechatChange = () => {
    if (newWechat) {
      setWechat(newWechat)
      setShowWechatModal(false)
    }
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/settings")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">用户设置</h1>
      </header>

      <div className="p-4 space-y-4">
        <div className="flex items-center justify-center py-6">
          {/* 修改头像部分 */}
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-[#F5F5F7] dark:bg-[#1A1A1A] flex items-center justify-center overflow-hidden">
              <Image
                src={avatar || "/placeholder.svg"}
                alt="用户头像"
                width={96}
                height={96}
                className="object-cover w-full h-full"
              />
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-black dark:bg-white text-white dark:text-black flex items-center justify-center"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M14.5 2.5L12 5 9.5 2.5"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M12 5V15"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
            <input type="file" ref={fileInputRef} onChange={handleAvatarUpload} accept="image/*" className="hidden" />
          </div>
        </div>

        <button className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
          <span className="text-[16px] text-black dark:text-white">更换头像</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M9 6L15 12L9 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-black/40 dark:text-white/40"
            />
          </svg>
        </button>

        {/* 修改手机号按钮点击事件 */}
        <button
          onClick={() => {
            setNewPhone(currentUser.phone)
            setShowPhoneModal(true)
          }}
          className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
        >
          <span className="text-[16px] text-black dark:text-white">手机号</span>
          <div className="flex items-center">
            <span className="text-[14px] text-black/40 dark:text-white/40 mr-2">{currentUser.phone}</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M9 6L15 12L9 18"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-black/40 dark:text-white/40"
              />
            </svg>
          </div>
        </button>

        {/* 修改微信号按钮点击事件 */}
        <button
          onClick={() => setShowWechatModal(true)}
          className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
        >
          <span className="text-[16px] text-black dark:text-white">微信号</span>
          <div className="flex items-center">
            <span className="text-[14px] text-black/40 dark:text-white/40 mr-2">{wechat || "未绑定"}</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M9 6L15 12L9 18"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-black/40 dark:text-white/40"
              />
            </svg>
          </div>
        </button>

        <div className="w-full p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
          <div className="flex items-center justify-between">
            <span className="text-[16px] text-black dark:text-white">密钥</span>
            <span className="text-[14px] text-black/40 dark:text-white/40">{currentUser.key}</span>
          </div>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
        >
          <span className="text-[16px] text-red-500">注销账号</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M9 6L15 12L9 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-black/40 dark:text-white/40"
            />
          </svg>
        </button>
      </div>

      {/* 注销确认弹窗 */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 dark:bg-black/70 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-[320px] bg-white dark:bg-[#1A1A1A] rounded-2xl p-6">
            <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-4">确认注销</h3>
            <p className="text-[16px] text-black/70 dark:text-white/70 text-center mb-6">注销后所有数据将全部清除</p>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowModal(false)}
                className="flex-1 h-[48px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500]"
              >
                返回
              </button>
              <button
                onClick={() => router.push("/")}
                className="flex-1 h-[48px] rounded-full bg-red-500 text-white text-[16px] font-[500]"
              >
                注销
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 手机号修改弹窗 */}
      {showPhoneModal && (
        <div className="fixed inset-0 bg-black/50 dark:bg-black/70 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-[320px] bg-white dark:bg-[#1A1A1A] rounded-2xl p-6">
            <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-4">修改手机号</h3>
            <input
              type="tel"
              value={newPhone}
              onChange={(e) => setNewPhone(e.target.value)}
              placeholder="请输入新手机号"
              maxLength={11}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] mb-2 focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
            />
            {phoneError && <p className="text-red-500 text-[14px] mb-4">{phoneError}</p>}
            <div className="flex space-x-4 mt-4">
              <button
                onClick={() => setShowPhoneModal(false)}
                className="flex-1 h-[44px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500]"
              >
                取消
              </button>
              <button
                onClick={handlePhoneChange}
                className="flex-1 h-[44px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 微信绑定弹窗 */}
      {showWechatModal && (
        <div className="fixed inset-0 bg-black/50 dark:bg-black/70 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-[320px] bg-white dark:bg-[#1A1A1A] rounded-2xl p-6">
            <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-4">绑定微信</h3>
            <input
              type="text"
              value={newWechat}
              onChange={(e) => setNewWechat(e.target.value)}
              placeholder="请输入微信号"
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] mb-6 focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
            />
            <div className="flex space-x-4">
              <button
                onClick={() => setShowWechatModal(false)}
                className="flex-1 h-[44px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500]"
              >
                取消
              </button>
              <button
                onClick={handleWechatChange}
                className="flex-1 h-[44px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

