"use client"

import { useState, useEffect, useContext, useCallback, useRef } from "react"
import { useRouter } from "next/navigation"
import { Switch } from "@/components/ui/switch"
import { SettingsContext } from "@/context/settings-context"
import { UserContext } from "@/context/user-context"

// 修改 SettingsPage 组件，防止无限循环更新
export default function SettingsPage() {
  const router = useRouter()
  const {
    fontSize,
    setFontSize,
    darkMode,
    setDarkMode,
    voiceEnabled,
    setVoiceEnabled,
    hapticFeedback,
    setHapticFeedback,
    notifications,
    setNotifications,
  } = useContext(SettingsContext)
  const { setCurrentUser } = useContext(UserContext)

  // 修改字体大小滑动条为三个固定点
  // 使用 useRef 来跟踪初始化状态，防止无限循环
  const [fontSizeOption, setFontSizeOption] = useState(1) // 0: 小, 1: 中, 2: 大
  const initializedRef = useRef(false)

  // 根据选项设置字体大小
  useEffect(() => {
    // 防止在初始化后重复触发
    if (initializedRef.current) {
      // 根据选项设置对应的字体大小
      switch (fontSizeOption) {
        case 0: // 小
          setFontSize(13)
          break
        case 1: // 中
          setFontSize(14)
          break
        case 2: // 大
          setFontSize(15)
          break
        default:
          setFontSize(14)
      }
    }
  }, [fontSizeOption, setFontSize])

  // 从本地存储加载字体大小选项 - 只在组件挂载时运行一次
  useEffect(() => {
    if (!initializedRef.current) {
      const size = fontSize
      if (size <= 13) {
        setFontSizeOption(0)
      } else if (size <= 14) {
        setFontSizeOption(1)
      } else {
        setFontSizeOption(2)
      }
      initializedRef.current = true
    }
  }, [fontSize])

  // 处理深色模式切换 - 使用 useCallback 避免不必要的重新渲染
  const handleDarkModeToggle = useCallback(
    (checked: boolean) => {
      setDarkMode(checked)
    },
    [setDarkMode],
  )

  // 处理其他设置切换 - 使用 useCallback 避免不必要的重新渲染
  const handleVoiceEnabledToggle = useCallback(
    (checked: boolean) => {
      setVoiceEnabled(checked)
    },
    [setVoiceEnabled],
  )

  const handleHapticFeedbackToggle = useCallback(
    (checked: boolean) => {
      setHapticFeedback(checked)
    },
    [setHapticFeedback],
  )

  const handleNotificationsToggle = useCallback(
    (checked: boolean) => {
      setNotifications(checked)
    },
    [setNotifications],
  )

  // 处理退出登录
  const handleLogout = useCallback(() => {
    setCurrentUser(null)
    router.push("/")
  }, [setCurrentUser, router])

  // 1. 修改背景模式滑动块颜色为绿色
  // 2. 修改触感反应滑动块颜色为绿色
  // 3. 修改推送通知滑动块颜色为绿色
  // 4. 修改语音图标显示滑动块颜色为绿色
  // 5. 修改字体大小滑动条样式
  // 6. 固定设置页面顶部

  // 首先修改页面结构，添加固定顶部
  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black">
      <header className="h-[60px] flex items-center justify-center px-4 border-b border-black/[0.06] dark:border-white/[0.06] fixed top-0 left-0 right-0 z-10 bg-white dark:bg-black">
        <button
          onClick={() => router.push("/chat")}
          className="absolute left-4 w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white">设置</h1>
      </header>

      <div className="p-4 space-y-6 pt-[76px]">
        {" "}
        {/* 添加顶部内边距 */}
        {/* 用户设置 */}
        <section>
          <h2 className="text-[18px] font-[600] text-black dark:text-white mb-3">用户设置</h2>
          <div className="space-y-2">
            <button
              onClick={() => router.push("/settings/user")}
              className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
            >
              <span className="text-[16px] text-black dark:text-white">用户设置</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 6L15 12L9 18"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-black/40 dark:text-white/40"
                />
              </svg>
            </button>
          </div>
        </section>
        {/* 账号设置 */}
        <section>
          <h2 className="text-[18px] font-[600] text-black dark:text-white mb-3">账号设置</h2>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <span className="text-[16px] text-black dark:text-white">背景模式</span>
              <Switch
                checked={darkMode}
                onCheckedChange={handleDarkModeToggle}
                className="data-[state=checked]:bg-green-500 dark:data-[state=checked]:bg-green-500"
              />
            </div>

            <div className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <div className="flex items-center justify-center mb-2">
                <span className="text-[16px] text-black dark:text-white">字体大小</span>
              </div>
              <div className="flex justify-between text-[12px] text-black/60 dark:text-white/60 mb-1">
                <span>12</span>
                <span>14</span>
                <span>16</span>
              </div>
              <div className="relative w-full h-2 bg-black/10 dark:bg-white/10 rounded-full">
                <div className="absolute inset-y-0 left-0 flex items-center justify-between w-full px-0">
                  <button
                    onClick={() => setFontSizeOption(0)}
                    className={`w-4 h-4 rounded-full transition-all ${
                      fontSizeOption === 0 ? "bg-green-500 scale-125" : "bg-black/40 dark:bg-white/40"
                    }`}
                  />
                  <button
                    onClick={() => setFontSizeOption(1)}
                    className={`w-4 h-4 rounded-full transition-all ${
                      fontSizeOption === 1 ? "bg-green-500 scale-125" : "bg-black/40 dark:bg-white/40"
                    }`}
                  />
                  <button
                    onClick={() => setFontSizeOption(2)}
                    className={`w-4 h-4 rounded-full transition-all ${
                      fontSizeOption === 2 ? "bg-green-500 scale-125" : "bg-black/40 dark:bg-white/40"
                    }`}
                  />
                </div>
              </div>
              <div className="flex justify-between text-[12px] text-black/40 dark:text-white/40 mt-1">
                <span>小</span>
                <span>中</span>
                <span>大</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <span className="text-[16px] text-black dark:text-white">触感反应</span>
              <Switch
                checked={hapticFeedback}
                onCheckedChange={handleHapticFeedbackToggle}
                className="data-[state=checked]:bg-green-500 dark:data-[state=checked]:bg-green-500"
              />
            </div>

            <div className="flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <span className="text-[16px] text-black dark:text-white">推送通知</span>
              <Switch
                checked={notifications}
                onCheckedChange={handleNotificationsToggle}
                className="data-[state=checked]:bg-green-500 dark:data-[state=checked]:bg-green-500"
              />
            </div>

            <div className="flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <span className="text-[16px] text-black dark:text-white">语音图标显示</span>
              <Switch
                checked={voiceEnabled}
                onCheckedChange={handleVoiceEnabledToggle}
                className="data-[state=checked]:bg-green-500 dark:data-[state=checked]:bg-green-500"
              />
            </div>
          </div>
        </section>
        {/* 其他设置 */}
        <section>
          <h2 className="text-[18px] font-[600] text-black dark:text-white mb-3">其他</h2>
          <div className="space-y-2">
            <button
              onClick={() => router.push("/settings/agreement")}
              className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
            >
              <span className="text-[16px] text-black dark:text-white">用户协议</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 6L15 12L9 18"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-black/40 dark:text-white/40"
                />
              </svg>
            </button>

            <button
              onClick={() => router.push("/settings/privacy")}
              className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
            >
              <span className="text-[16px] text-black dark:text-white">隐私协议</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 6L15 12L9 18"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-black/40 dark:text-white/40"
                />
              </svg>
            </button>

            <button
              onClick={() => router.push("/settings/about")}
              className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
            >
              <span className="text-[16px] text-black dark:text-white">关于我们</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 6L15 12L9 18"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-black/40 dark:text-white/40"
                />
              </svg>
            </button>

            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
            >
              <span className="text-[16px] text-black dark:text-white">退出登录</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 6L15 12L9 18"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-black/40 dark:text-white/40"
                />
              </svg>
            </button>
          </div>
        </section>
      </div>
    </div>
  )
}

