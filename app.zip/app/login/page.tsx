"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // 模拟身份验证
    setTimeout(() => {
      setIsLoading(false)
      router.push("/chat")
    }, 1500)
  }

  return (
    <div className="min-h-[100dvh] bg-[#FFFFFF] dark:bg-[#000000] flex items-center justify-center px-6">
      <div className="w-full max-w-[360px]">
        <div className="w-[80px] h-[80px] rounded-[24px] bg-[#000000] dark:bg-[#FFFFFF] flex items-center justify-center mx-auto mb-12 shadow-[0_8px_30px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_30px_rgba(255,255,255,0.12)]">
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle
              cx="12"
              cy="12"
              r="10"
              stroke={`${typeof window !== "undefined" && document.documentElement.classList.contains("dark") ? "#000000" : "#FFFFFF"}`}
              strokeWidth="1.5"
            />
            <circle
              cx="12"
              cy="9"
              r="2"
              stroke={`${typeof window !== "undefined" && document.documentElement.classList.contains("dark") ? "#000000" : "#FFFFFF"}`}
              strokeWidth="1.5"
            />
            <path
              d="M7 18.5C7 15.5 9 14 12 14C15 14 17 15.5 17 18.5"
              stroke={`${typeof window !== "undefined" && document.documentElement.classList.contains("dark") ? "#000000" : "#FFFFFF"}`}
              strokeWidth="1.5"
            />
          </svg>
        </div>

        <h1 className="text-[32px] font-[600] tracking-[-0.02em] text-[#000000] dark:text-[#FFFFFF] text-center mb-4">
          欢迎回来
        </h1>

        <p className="text-[17px] text-[#6E6E73] dark:text-[#86868B] text-center mb-12 font-[400]">
          请登录您的账户继续对话
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-[15px] font-[500] text-[#000000] dark:text-[#FFFFFF]">
              邮箱
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="your.email@example.com"
              className="h-[52px] px-5 rounded-full border-[#000000]/10 dark:border-[#FFFFFF]/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-[#000000] dark:text-[#FFFFFF] text-[17px] focus-visible:ring-[#000000] dark:focus-visible:ring-[#FFFFFF] focus-visible:ring-1 focus-visible:border-transparent placeholder:text-[#6E6E73] dark:placeholder:text-[#86868B]"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password" className="text-[15px] font-[500] text-[#000000] dark:text-[#FFFFFF]">
                密码
              </Label>
              <Link
                href="/forgot-password"
                className="text-[15px] text-[#000000] dark:text-[#FFFFFF] font-[500] hover:opacity-70 transition-opacity"
              >
                忘记密码？
              </Link>
            </div>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                className="h-[52px] px-5 rounded-full border-[#000000]/10 dark:border-[#FFFFFF]/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-[#000000] dark:text-[#FFFFFF] text-[17px] focus-visible:ring-[#000000] dark:focus-visible:ring-[#FFFFFF] focus-visible:ring-1 focus-visible:border-transparent"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                className="absolute right-5 top-1/2 -translate-y-1/2 text-[#6E6E73] dark:text-[#86868B] hover:text-[#000000] dark:hover:text-[#FFFFFF] transition-colors text-[13px] font-[500]"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? "隐藏" : "显示"}
                <span className="sr-only">切换密码可见性</span>
              </button>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full h-[52px] rounded-full text-[17px] font-[500] bg-[#000000] dark:bg-[#FFFFFF] text-[#FFFFFF] dark:text-[#000000] hover:bg-[#000000]/90 dark:hover:bg-[#FFFFFF]/90 transition-all duration-300 mt-8"
            disabled={isLoading}
          >
            {isLoading ? "登录中..." : "登录"}
          </Button>

          <div className="text-center text-[15px] text-[#6E6E73] dark:text-[#86868B] pt-4 font-[400]">
            还没有账户？{" "}
            <Link
              href="/register"
              className="text-[#000000] dark:text-[#FFFFFF] font-[500] hover:opacity-70 transition-opacity"
            >
              创建账户
            </Link>
          </div>
        </form>
      </div>
    </div>
  )
}

