"use client"

import { useRouter } from "next/navigation"

export default function DataTypePage({ params }: { params: { type: string } }) {
  const router = useRouter()

  const typeNames: Record<string, string> = {
    storage: "数据存储",
    application: "数据应用",
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/data")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">
          {typeNames[params.type] || params.type}
        </h1>
      </header>

      <div className="flex items-center justify-center h-[calc(100vh-60px)]">
        <p className="text-black/40 dark:text-white/40 text-[16px]">敬请期待</p>
      </div>
    </div>
  )
}

