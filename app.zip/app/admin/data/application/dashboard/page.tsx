"use client"

import { useState, useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

interface Dashboard {
  id: string
  title: string
  url: string
}

export default function DashboardPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)

  const [showAddForm, setShowAddForm] = useState(false)
  const [title, setTitle] = useState("")
  const [url, setUrl] = useState("")
  const [dashboards, setDashboards] = useState<Dashboard[]>([])
  const [error, setError] = useState("")

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 从本地存储加载仪表盘
  useEffect(() => {
    const storedDashboards = localStorage.getItem("dashboards")
    if (storedDashboards) {
      setDashboards(JSON.parse(storedDashboards))
    }
  }, [])

  // 保存仪表盘到本地存储
  useEffect(() => {
    localStorage.setItem("dashboards", JSON.stringify(dashboards))
  }, [dashboards])

  // 添加仪表盘
  const handleAddDashboard = () => {
    setError("")

    if (!title.trim()) {
      setError("请输入标题")
      return
    }

    if (!url.trim()) {
      setError("请输入URL链接")
      return
    }

    // 验证URL格式
    try {
      new URL(url)
    } catch (e) {
      setError("请输入有效的URL链接")
      return
    }

    const newDashboard: Dashboard = {
      id: Date.now().toString(),
      title,
      url,
    }

    setDashboards((prev) => [...prev, newDashboard])
    setTitle("")
    setUrl("")
    setShowAddForm(false)
  }

  // 删除仪表盘
  const handleDeleteDashboard = (id: string) => {
    setDashboards((prev) => prev.filter((dashboard) => dashboard.id !== id))
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center justify-between px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <div className="flex items-center">
          <button
            onClick={() => router.push("/admin/data/application")}
            className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M15 6L9 12L15 18"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">仪表盘管理</h1>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="h-10 px-4 rounded-full bg-black dark:bg-white text-white dark:text-black text-[14px] font-[500]"
        >
          添加
        </button>
      </header>

      <div className="flex-1 p-4 space-y-4 pb-[76px]">
        {dashboards.length > 0 ? (
          dashboards.map((dashboard) => (
            <div
              key={dashboard.id}
              className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A] border border-black/[0.06] dark:border-white/[0.06]"
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-[16px] font-[500] text-black dark:text-white">{dashboard.title}</h3>
                <button onClick={() => handleDeleteDashboard(dashboard.id)} className="text-red-500 text-[14px]">
                  删除
                </button>
              </div>
              <p className="text-[14px] text-black/60 dark:text-white/60 truncate">{dashboard.url}</p>
              <div className="mt-3 flex justify-end">
                <button
                  onClick={() => window.open(dashboard.url, "_blank")}
                  className="text-[14px] text-black dark:text-white bg-black/10 dark:bg-white/10 px-3 py-1 rounded-full"
                >
                  查看
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center h-[200px] text-black/40 dark:text-white/40">
            <svg
              width="48"
              height="48"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mb-4"
            >
              <path
                d="M21 8V21H3V8"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M23 3H1V8H23V3Z"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M10 12H14"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <p className="text-[16px]">暂无仪表盘</p>
          </div>
        )}
      </div>

      {/* 添加仪表盘表单 */}
      {showAddForm && (
        <div className="fixed bottom-[60px] left-0 right-0 bg-white dark:bg-black border-t border-black/10 dark:border-white/10 p-4 space-y-4 animate-slide-up">
          <h3 className="text-[16px] font-[500] text-black dark:text-white">添加仪表盘</h3>

          <div className="space-y-4">
            <div>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="标题"
                className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
              />
            </div>

            <div>
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="URL链接"
                className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
              />
            </div>

            {error && <p className="text-red-500 text-[14px]">{error}</p>}

            <div className="flex space-x-4">
              <button
                onClick={() => setShowAddForm(false)}
                className="flex-1 h-[44px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500]"
              >
                取消
              </button>
              <button
                onClick={handleAddDashboard}
                className="flex-1 h-[44px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
              >
                加载仪表盘
              </button>
            </div>
          </div>
        </div>
      )}

      <AdminNavBar />
    </div>
  )
}

