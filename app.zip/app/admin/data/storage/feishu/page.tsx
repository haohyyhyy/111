"use client"

import { useState, useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

interface FeishuConfig {
  appId: string
  appSecret: string
  appToken: string
  tableId: string
  connected: boolean
}

export default function FeishuStoragePage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)

  const [config, setConfig] = useState<FeishuConfig>({
    appId: "",
    appSecret: "",
    appToken: "",
    tableId: "",
    connected: false,
  })

  const [isLocked, setIsLocked] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)
  const [activeTab, setActiveTab] = useState<"config" | "store" | "query">("config")
  const [storeData, setStoreData] = useState("")
  const [queryField, setQueryField] = useState("")
  const [queryValue, setQueryValue] = useState("")
  const [queryResults, setQueryResults] = useState<any[]>([])
  const [debugInfo, setDebugInfo] = useState<string>("")

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 从本地存储加载配置
  useEffect(() => {
    const storedConfig = localStorage.getItem("feishuConfig")
    if (storedConfig) {
      setConfig(JSON.parse(storedConfig))
      setIsLocked(JSON.parse(storedConfig).connected)
    }
  }, [])

  // 保存配置到本地存储
  useEffect(() => {
    localStorage.setItem("feishuConfig", JSON.stringify(config))
  }, [config])

  // 更新配置
  const updateConfig = (newConfig: Partial<FeishuConfig>) => {
    setConfig((prev) => ({ ...prev, ...newConfig }))
  }

  // 获取租户访问凭证
  const fetchTenantAccessToken = async (appId: string, appSecret: string) => {
    try {
      setDebugInfo("正在获取租户访问凭证...")

      // 构建请求体
      const requestBody = {
        app_id: appId,
        app_secret: appSecret,
      }

      // 使用服务器端API路由处理请求，避免跨域问题
      const response = await fetch("/api/feishu/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      })

      setDebugInfo((prev) => prev + "\n请求已发送，状态码: " + response.status)

      if (!response.ok) {
        const errorText = await response.text()
        setDebugInfo((prev) => prev + "\n响应错误: " + errorText)
        throw new Error(`获取凭证失败: 状态码 ${response.status}, ${response.statusText}`)
      }

      const result = await response.json()

      if (result.error) {
        throw new Error(`获取凭证失败: ${result.error}`)
      }

      setDebugInfo((prev) => prev + "\n成功获取租户访问凭证")
      return result.tenant_access_token
    } catch (error) {
      console.error("获取租户访问凭证错误:", error)
      setDebugInfo((prev) => prev + "\n错误: " + (error instanceof Error ? error.message : String(error)))
      throw error
    }
  }

  // 测试连接
  const handleTestConnection = async () => {
    setIsLoading(true)
    setTestResult(null)
    setDebugInfo("")

    try {
      // 验证输入
      if (!config.appId || !config.appSecret || !config.appToken) {
        setTestResult({
          success: false,
          message: "请填写所有必填字段",
        })
        setIsLoading(false)
        return
      }

      try {
        // 获取租户访问凭证
        const tenantAccessToken = await fetchTenantAccessToken(config.appId, config.appSecret)

        // 验证多维表格访问权限
        const appResponse = await fetch("/api/feishu/bitable", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            token: tenantAccessToken,
            appToken: config.appToken,
            tableId: config.tableId || undefined,
          }),
        })

        if (!appResponse.ok) {
          const errorData = await appResponse.json()
          throw new Error(`多维表格验证失败: ${errorData.error || appResponse.statusText}`)
        }

        const appResult = await appResponse.json()

        if (appResult.error) {
          throw new Error(`多维表格验证失败: ${appResult.error}`)
        }

        // 成功响应
        setTestResult({
          success: true,
          message: "连接成功！已成功连接到飞书多维表格。",
        })
        updateConfig({ connected: true })
      } catch (error) {
        setTestResult({
          success: false,
          message: `连接失败: ${error instanceof Error ? error.message : "未知错误"}`,
        })
      }
    } finally {
      setIsLoading(false)
    }
  }

  // 处理数据存储
  const handleDataStorage = async () => {
    setIsLoading(true)
    setDebugInfo("")

    try {
      if (!config.appId || !config.appSecret || !config.appToken || !config.tableId) {
        alert("请先完成配置并测试连接")
        setIsLoading(false)
        return
      }

      if (!storeData) {
        alert("请输入要存储的数据")
        setIsLoading(false)
        return
      }

      // 解析JSON数据
      let fieldsData
      try {
        fieldsData = JSON.parse(storeData)
      } catch (e) {
        alert("数据格式错误，请输入有效的JSON格式")
        setIsLoading(false)
        return
      }

      setDebugInfo("正在获取租户访问凭证...")

      // 获取租户访问凭证
      const tenantAccessToken = await fetchTenantAccessToken(config.appId, config.appSecret)

      setDebugInfo((prev) => prev + "\n正在存储数据...")

      // 存储数据
      const response = await fetch("/api/feishu/record", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          token: tenantAccessToken,
          appToken: config.appToken,
          tableId: config.tableId,
          fields: fieldsData,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`存储失败: ${errorData.error || response.statusText}`)
      }

      const result = await response.json()

      if (result.error) {
        throw new Error(`存储失败: ${result.error}`)
      }

      alert("数据存储成功！")
      setStoreData("")
    } catch (error) {
      alert(`存储失败: ${error instanceof Error ? error.message : "未知错误"}`)
      setDebugInfo((prev) => prev + "\n错误: " + (error instanceof Error ? error.message : String(error)))
    } finally {
      setIsLoading(false)
    }
  }

  // 处理数据查询
  const handleDataQuery = async () => {
    setIsLoading(true)
    setDebugInfo("")
    setQueryResults([])

    try {
      if (!config.appId || !config.appSecret || !config.appToken || !config.tableId) {
        alert("请先完成配置并测试连接")
        setIsLoading(false)
        return
      }

      setDebugInfo("正在获取租户访问凭证...")

      // 获取租户访问凭证
      const tenantAccessToken = await fetchTenantAccessToken(config.appId, config.appSecret)

      setDebugInfo((prev) => prev + "\n正在查询数据...")

      // 构建查询参数
      const queryParams = {
        token: tenantAccessToken,
        appToken: config.appToken,
        tableId: config.tableId,
      }

      // 如果有查询条件，添加过滤器
      if (queryField && queryValue) {
        Object.assign(queryParams, {
          filterField: queryField,
          filterValue: queryValue,
        })
      }

      // 查询数据
      const response = await fetch("/api/feishu/query", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(queryParams),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`查询失败: ${errorData.error || response.statusText}`)
      }

      const result = await response.json()

      if (result.error) {
        throw new Error(`查询失败: ${result.error}`)
      }

      setQueryResults(result.items || [])
    } catch (error) {
      alert(`查询失败: ${error instanceof Error ? error.message : "未知错误"}`)
      setDebugInfo((prev) => prev + "\n错误: " + (error instanceof Error ? error.message : String(error)))
    } finally {
      setIsLoading(false)
    }
  }

  // 处理保存/更改
  const handleSaveOrEdit = () => {
    if (isLocked) {
      // 解锁设置
      setIsLocked(false)
    } else {
      // 锁定设置
      setIsLocked(true)
    }
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/data/storage")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">飞书多维表格</h1>
      </header>

      <div className="flex-1 p-4 space-y-6 pb-[76px] overflow-auto">
        {/* 选项卡导航 */}
        <div className="flex border-b border-black/10 dark:border-white/10">
          <button
            onClick={() => setActiveTab("config")}
            className={`px-4 py-2 ${activeTab === "config" ? "border-b-2 border-black dark:border-white font-medium" : "text-black/60 dark:text-white/60"}`}
          >
            基础配置
          </button>
          <button
            onClick={() => setActiveTab("store")}
            className={`px-4 py-2 ${activeTab === "store" ? "border-b-2 border-black dark:border-white font-medium" : "text-black/60 dark:text-white/60"}`}
          >
            数据存储
          </button>
          <button
            onClick={() => setActiveTab("query")}
            className={`px-4 py-2 ${activeTab === "query" ? "border-b-2 border-black dark:border-white font-medium" : "text-black/60 dark:text-white/60"}`}
          >
            数据查询
          </button>
        </div>

        {/* 基础配置 */}
        {activeTab === "config" && (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[14px] text-black/60 dark:text-white/60">App ID</label>
              <input
                type="text"
                value={config.appId}
                onChange={(e) => updateConfig({ appId: e.target.value })}
                placeholder="请输入飞书应用的App ID"
                disabled={isLocked}
                className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[14px] text-black/60 dark:text-white/60">App Secret</label>
              <input
                type="password"
                value={config.appSecret}
                onChange={(e) => updateConfig({ appSecret: e.target.value })}
                placeholder="请输入飞书应用的App Secret"
                disabled={isLocked}
                className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[14px] text-black/60 dark:text-white/60">多维表格 App Token</label>
              <input
                type="text"
                value={config.appToken}
                onChange={(e) => updateConfig({ appToken: e.target.value })}
                placeholder="请输入多维表格的App Token"
                disabled={isLocked}
                className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[14px] text-black/60 dark:text-white/60">数据表 ID</label>
              <input
                type="text"
                value={config.tableId}
                onChange={(e) => updateConfig({ tableId: e.target.value })}
                placeholder="请输入数据表的Table ID"
                disabled={isLocked}
                className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
              />
            </div>

            <div className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <h3 className="text-[16px] font-[500] text-black dark:text-white mb-2">数据表配置</h3>
              <p className="text-[14px] text-black/60 dark:text-white/60 mb-4">
                连接成功后，系统将自动创建以下数据表：
              </p>
              <ul className="text-[14px] text-black/60 dark:text-white/60 space-y-2 list-disc pl-5">
                <li>用户表 - 存储用户账号、密码和ID</li>
                <li>会话表 - 存储用户的对话历史</li>
                <li>设置表 - 存储应用配置信息</li>
              </ul>
            </div>

            {testResult && (
              <div
                className={`p-3 rounded-lg text-[14px] ${
                  testResult.success
                    ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                    : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
                }`}
              >
                {testResult.message}
              </div>
            )}

            {debugInfo && (
              <div className="p-3 rounded-lg bg-gray-100 dark:bg-gray-900 text-[12px] font-mono whitespace-pre-wrap overflow-auto max-h-[200px]">
                <p className="font-medium mb-1">调试信息：</p>
                {debugInfo}
              </div>
            )}

            <div className="flex space-x-4 pt-4">
              <button
                onClick={handleTestConnection}
                disabled={isLoading || isLocked || !config.appId || !config.appSecret || !config.appToken}
                className="flex-1 h-[48px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500] disabled:opacity-50"
              >
                {isLoading ? "测试中..." : "测试连接"}
              </button>
              <button
                onClick={handleSaveOrEdit}
                className="flex-1 h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
              >
                {isLocked ? "更改" : "保存"}
              </button>
            </div>
          </div>
        )}

        {/* 数据存储 */}
        {activeTab === "store" && (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[14px] text-black/60 dark:text-white/60">数据内容 (JSON格式)</label>
              <textarea
                value={storeData}
                onChange={(e) => setStoreData(e.target.value)}
                placeholder='{"字段名称1": "字段值1", "字段名称2": "字段值2"}'
                className="w-full h-[200px] p-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white resize-none font-mono"
              />
            </div>

            <button
              onClick={handleDataStorage}
              disabled={isLoading || !config.connected}
              className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500] disabled:opacity-50"
            >
              {isLoading ? "存储中..." : "存储数据"}
            </button>

            <div className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <h3 className="text-[16px] font-[500] text-black dark:text-white mb-2">数据格式说明</h3>
              <p className="text-[14px] text-black/60 dark:text-white/60 mb-2">请按照以下JSON格式输入数据：</p>
              <pre className="text-[13px] text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 p-2 rounded overflow-auto">
                {`{
  "字段名称1": "字段值1",
  "字段名称2": "字段值2",
  "字段名称3": 123,
  "字段名称4": true
}`}
              </pre>
            </div>
          </div>
        )}

        {/* 数据查询 */}
        {activeTab === "query" && (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[14px] text-black/60 dark:text-white/60">查询条件</label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={queryField}
                  onChange={(e) => setQueryField(e.target.value)}
                  placeholder="字段名称"
                  className="flex-1 h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
                />
                <input
                  type="text"
                  value={queryValue}
                  onChange={(e) => setQueryValue(e.target.value)}
                  placeholder="字段值"
                  className="flex-1 h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
                />
              </div>
            </div>

            <button
              onClick={handleDataQuery}
              disabled={isLoading || !config.connected}
              className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500] disabled:opacity-50"
            >
              {isLoading ? "查询中..." : "查询数据"}
            </button>

            {queryResults.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-[16px] font-[500] text-black dark:text-white">查询结果</h3>
                <div className="max-h-[300px] overflow-auto">
                  {queryResults.map((item, index) => (
                    <div key={index} className="p-3 rounded-lg bg-[#F5F5F7] dark:bg-[#1A1A1A] mb-2">
                      <pre className="text-[13px] text-black/70 dark:text-white/70 overflow-auto">
                        {JSON.stringify(item.fields, null, 2)}
                      </pre>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {queryResults.length === 0 && (
              <div className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A] text-center">
                <p className="text-[14px] text-black/60 dark:text-white/60">暂无查询结果</p>
              </div>
            )}
          </div>
        )}

        <div className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
          <h3 className="text-[16px] font-[500] text-black dark:text-white mb-2">如何获取飞书多维表格配置</h3>
          <ol className="text-[14px] text-black/60 dark:text-white/60 space-y-2 list-decimal pl-5">
            <li>登录飞书开发者平台 (open.feishu.cn)</li>
            <li>创建一个企业自建应用</li>
            <li>在应用凭证页面获取App ID和App Secret</li>
            <li>开启云文档权限</li>
            <li>创建一个多维表格，并获取其App Token (URL中的bitable/app/xxx部分)</li>
            <li>
              通过API获取数据表的Table ID: 调用
              <a
                href="https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/reference/bitable-v1/app-table/list"
                target="_blank"
                className="text-blue-500 dark:text-blue-400"
                rel="noreferrer"
              >
                列出数据表
              </a>
              接口
            </li>
          </ol>
        </div>
      </div>

      <AdminNavBar />
    </div>
  )
}

