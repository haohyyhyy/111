"use client"

import { useRouter } from "next/navigation"
import { useContext, useEffect } from "react"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

export default function DataStoragePage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  const storageOptions = [
    { id: "local", name: "本地存储", icon: "💾" },
    { id: "feishu", name: "飞书多维表格+", icon: "📊" },
    { id: "cloud", name: "云存储", icon: "☁️" },
  ]

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/data")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">数据存储</h1>
      </header>

      <div className="flex-1 p-4 space-y-4 pb-[76px]">
        {storageOptions.map((option) => (
          <button
            key={option.id}
            onClick={() => router.push(`/admin/data/storage/${option.id}`)}
            className="w-full flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]"
          >
            <div className="flex items-center">
              <span className="text-[20px] mr-3">{option.icon}</span>
              <span className="text-[16px] text-black dark:text-white">{option.name}</span>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M9 6L15 12L9 18"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-black/40 dark:text-white/40"
              />
            </svg>
          </button>
        ))}
      </div>

      <AdminNavBar />
    </div>
  )
}

