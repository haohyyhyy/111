"use client"

import { useRouter } from "next/navigation"
import { AdminNavBar } from "@/components/admin-nav-bar"
import { useContext, useEffect } from "react"
import { SettingsContext } from "@/context/settings-context"

export default function AdminPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  const adminOptions = [
    { id: "api", name: "API管理", icon: "🔌" },
    { id: "users", name: "用户管理", icon: "👥" },
    { id: "data", name: "数据管理", icon: "📊" },
    { id: "routes", name: "路由管理", icon: "🔄" },
    { id: "settings", name: "设置", icon: "⚙️" },
  ]

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <h1 className="text-[17px] font-[600] text-black dark:text-white">管理员控制台</h1>
      </header>

      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-[24px] font-[600] text-black dark:text-white mb-2">欢迎使用管理员控制台</h2>
          <p className="text-[16px] text-black/60 dark:text-white/60">请使用底部导航栏访问各项功能</p>
        </div>
      </div>

      <AdminNavBar />
    </div>
  )
}

