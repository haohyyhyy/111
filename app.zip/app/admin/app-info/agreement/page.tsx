"use client"

import { useState, useEffect, useContext } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"

export default function AgreementEditPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)
  const [agreement, setAgreement] = useState("")
  const [isSaved, setIsSaved] = useState(false)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 从本地存储加载用户协议
  useEffect(() => {
    const storedAgreement = localStorage.getItem("appAgreement")
    if (storedAgreement) {
      setAgreement(storedAgreement)
    } else {
      // 默认用户协议
      const defaultAgreement = `# 用户协议

欢迎使用我们的AI对话应用。请仔细阅读以下条款和条件，它们构成了您与我们之间的协议。

## 1. 服务说明

我们提供一个AI对话平台，允许用户与人工智能进行交互。我们的服务可能会不时更新，我们保留随时修改、暂停或终止服务的权利。

## 2. 用户账户

您需要注册账户才能使用我们的服务。您有责任保护您的账户信息，并对您账户下发生的所有活动负责。

## 3. 用户行为

您同意不会使用我们的服务进行任何违法或不当的活动，包括但不限于：
- 发布、传输任何非法、有害、威胁、辱骂、骚扰、诽谤、淫秽或其他不当内容
- 侵犯他人的知识产权或其他权利
- 尝试未经授权访问我们的系统或其他用户的账户
- 使用自动化程序或脚本大量访问我们的服务

## 4. 知识产权

我们的服务及其内容受知识产权法保护。您不得复制、修改、分发或创建基于我们服务的衍生作品。

## 5. 免责声明

我们的服务按"现状"提供，不提供任何明示或暗示的保证。我们不保证服务不会中断或无错误，也不保证AI回答的准确性或完整性。

## 6. 责任限制

在法律允许的最大范围内，我们对因使用或无法使用我们的服务而导致的任何直接、间接、附带、特殊、惩罚性或后果性损害不承担责任。

## 7. 协议修改

我们保留随时修改本协议的权利。修改后的协议将在我们的网站上发布，并在发布时立即生效。

## 8. 适用法律

本协议受中华人民共和国法律管辖，并按其解释。`

      setAgreement(defaultAgreement)
      localStorage.setItem("appAgreement", defaultAgreement)
    }
  }, [])

  // 保存用户协议
  const handleSave = () => {
    localStorage.setItem("appAgreement", agreement)
    setIsSaved(true)
    setTimeout(() => setIsSaved(false), 2000)
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/app-info")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">编辑用户协议</h1>
      </header>

      <div className="flex-1 p-4 pb-[76px] flex flex-col">
        <textarea
          value={agreement}
          onChange={(e) => setAgreement(e.target.value)}
          className="flex-1 w-full p-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white resize-none font-mono"
          placeholder="请输入用户协议内容..."
        />

        <div className="mt-4">
          <button
            onClick={handleSave}
            className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
          >
            {isSaved ? "已保存" : "保存"}
          </button>
        </div>
      </div>
    </div>
  )
}

