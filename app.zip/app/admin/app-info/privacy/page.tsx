"use client"

import { useState, useEffect, useContext } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"

export default function PrivacyEditPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)
  const [privacy, setPrivacy] = useState("")
  const [isSaved, setIsSaved] = useState(false)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 从本地存储加载隐私协议
  useEffect(() => {
    const storedPrivacy = localStorage.getItem("appPrivacy")
    if (storedPrivacy) {
      setPrivacy(storedPrivacy)
    } else {
      // 默认隐私协议
      const defaultPrivacy = `# 隐私政策

我们重视您的隐私。本隐私政策说明我们如何收集、使用、披露、传输和存储您的个人信息。

## 1. 信息收集

我们可能收集以下类型的信息：
- 账户信息：如姓名、电子邮件地址、电话号码等
- 使用数据：如您与AI的对话内容、使用频率、功能偏好等
- 设备信息：如设备型号、操作系统、浏览器类型等
- 位置信息：如IP地址等

## 2. 信息使用

我们使用收集的信息来：
- 提供、维护和改进我们的服务
- 开发新功能和服务
- 个性化您的体验
- 与您沟通
- 防止欺诈和滥用

## 3. 信息共享

我们不会出售您的个人信息。我们可能在以下情况下共享您的信息：
- 经您同意
- 与我们的服务提供商共享，以帮助我们提供服务
- 遵守法律要求
- 保护我们的权利和财产

## 4. 数据安全

我们采取合理的技术和组织措施来保护您的个人信息。然而，没有任何互联网传输或电子存储方法是100%安全的。

## 5. 数据保留

我们会在必要的时间内保留您的个人信息，以实现本隐私政策中描述的目的，除非法律要求或允许更长的保留期。

## 6. 您的权利

根据适用的数据保护法，您可能有权访问、更正、删除您的个人信息，以及限制或反对某些处理活动。

## 7. 儿童隐私

我们的服务不面向13岁以下的儿童。如果我们发现我们收集了13岁以下儿童的个人信息，我们会立即删除这些信息。

## 8. 隐私政策更新

我们可能会不时更新本隐私政策。更新后的政策将在我们的网站上发布，并在发布时立即生效。

## 9. 联系我们

如果您对本隐私政策有任何疑问，请联系我们的数据保护团队。`

      setPrivacy(defaultPrivacy)
      localStorage.setItem("appPrivacy", defaultPrivacy)
    }
  }, [])

  // 保存隐私协议
  const handleSave = () => {
    localStorage.setItem("appPrivacy", privacy)
    setIsSaved(true)
    setTimeout(() => setIsSaved(false), 2000)
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/app-info")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">编辑隐私协议</h1>
      </header>

      <div className="flex-1 p-4 pb-[76px] flex flex-col">
        <textarea
          value={privacy}
          onChange={(e) => setPrivacy(e.target.value)}
          className="flex-1 w-full p-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white resize-none font-mono"
          placeholder="请输入隐私协议内容..."
        />

        <div className="mt-4">
          <button
            onClick={handleSave}
            className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
          >
            {isSaved ? "已保存" : "保存"}
          </button>
        </div>
      </div>
    </div>
  )
}

