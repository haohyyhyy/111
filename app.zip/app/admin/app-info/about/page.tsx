"use client"

import { useState, useEffect, useContext } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"

export default function AboutEditPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)
  const [about, setAbout] = useState("")
  const [isSaved, setIsSaved] = useState(false)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 从本地存储加载关于我们
  useEffect(() => {
    const storedAbout = localStorage.getItem("appAbout")
    if (storedAbout) {
      setAbout(storedAbout)
    } else {
      // 默认关于我们
      const defaultAbout = `# 关于我们

## 我们的使命

我们致力于打造最智能、最人性化的AI对话助手，帮助用户获取信息、解决问题、激发创意，让人工智能技术真正融入日常生活，为每个人带来便利和价值。

## 技术支持

我们的AI对话助手基于最先进的大型语言模型技术，支持多种AI模型接入，包括OpenAI、DeepSeek、文心一言等，为用户提供多样化的智能对话体验。

## 联系我们

邮箱：support@aichat.com
电话：400-123-4567
地址：北京市海淀区科技园区88号

© 2023-2025 AI对话助手 版权所有`

      setAbout(defaultAbout)
      localStorage.setItem("appAbout", defaultAbout)
    }
  }, [])

  // 保存关于我们
  const handleSave = () => {
    localStorage.setItem("appAbout", about)
    setIsSaved(true)
    setTimeout(() => setIsSaved(false), 2000)
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/app-info")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">编辑关于我们</h1>
      </header>

      <div className="flex-1 p-4 pb-[76px] flex flex-col">
        <textarea
          value={about}
          onChange={(e) => setAbout(e.target.value)}
          className="flex-1 w-full p-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white resize-none font-mono"
          placeholder="请输入关于我们内容..."
        />

        <div className="mt-4">
          <button
            onClick={handleSave}
            className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
          >
            {isSaved ? "已保存" : "保存"}
          </button>
        </div>
      </div>
    </div>
  )
}

