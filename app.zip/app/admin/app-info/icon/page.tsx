"use client"

import type React from "react"

import { useState, useEffect, useContext, useRef } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"
import Image from "next/image"

export default function IconEditPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)
  const [iconSrc, setIconSrc] = useState("/placeholder.svg?height=120&width=120")
  const [iconUrl, setIconUrl] = useState("")
  const [isSaved, setIsSaved] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [previewStyle, setPreviewStyle] = useState({})
  const [isLoading, setIsLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState("")
  const [imageLoaded, setImageLoaded] = useState(true)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 从本地存储加载图标
  useEffect(() => {
    const storedIcon = localStorage.getItem("appIcon")
    if (storedIcon) {
      setIconSrc(storedIcon)
      setImageLoaded(true)
    }
  }, [])

  // 处理文件上传 - 修复加载状态问题
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setIsLoading(true)
      setErrorMessage("")
      setImageLoaded(false)

      // 创建一个新的FileReader实例
      const reader = new FileReader()

      // 设置onload处理函数 - 修复事件处理方式
      reader.onload = () => {
        // 使用reader.result而不是从事件对象中获取
        if (reader.result) {
          const result = reader.result as string

          // 预加载图片以获取尺寸
          const img = new Image()

          img.onload = () => {
            // 图片加载成功后设置图片源和样式
            setIconSrc(result)
            optimizeImageDisplay(img.width, img.height)
            setIsLoading(false)
            setImageLoaded(true)
          }

          img.onerror = () => {
            // 图片加载失败
            setErrorMessage("图片加载失败，请尝试其他图片")
            setIsLoading(false)
            setImageLoaded(false)
          }

          // 设置图片源触发加载
          img.src = result
        } else {
          setErrorMessage("读取文件结果为空")
          setIsLoading(false)
          setImageLoaded(false)
        }
      }

      // 设置onerror处理函数
      reader.onerror = () => {
        setErrorMessage("读取文件时出错，请重试")
        setIsLoading(false)
        setImageLoaded(false)
      }

      // 开始读取文件
      reader.readAsDataURL(file)
    }
  }

  // 处理URL加载
  const handleUrlLoad = () => {
    if (!iconUrl.trim()) {
      setErrorMessage("请输入有效的图片URL")
      return
    }

    setIsLoading(true)
    setErrorMessage("")
    setImageLoaded(false)

    // 预加载图片以获取尺寸
    const img = new Image()

    // 设置加载超时
    const timeoutId = setTimeout(() => {
      if (isLoading) {
        setErrorMessage("图片加载超时，请检查URL是否正确")
        setIsLoading(false)
        img.src = "" // 中止加载
      }
    }, 10000) // 10秒超时

    img.onload = () => {
      clearTimeout(timeoutId)
      setIconSrc(iconUrl)
      optimizeImageDisplay(img.width, img.height)
      setIsLoading(false)
      setImageLoaded(true)
    }

    img.onerror = () => {
      clearTimeout(timeoutId)
      setErrorMessage("无法加载图片，请检查URL是否正确")
      setIsLoading(false)
      setImageLoaded(false)
    }

    // 设置图片源触发加载
    img.src = iconUrl
  }

  // 优化图片显示
  const optimizeImageDisplay = (width: number, height: number) => {
    // 计算最佳的objectFit和objectPosition
    if (width === height) {
      // 正方形图片
      setPreviewStyle({ objectFit: "cover" as const })
    } else if (width > height) {
      // 宽图片
      setPreviewStyle({
        objectFit: "cover" as const,
        objectPosition: "center",
      })
    } else {
      // 高图片
      setPreviewStyle({
        objectFit: "cover" as const,
        objectPosition: "center",
      })
    }
  }

  // 保存图标
  const handleSave = () => {
    if (imageLoaded && iconSrc) {
      localStorage.setItem("appIcon", iconSrc)
      setIsSaved(true)
      setTimeout(() => setIsSaved(false), 2000)
    } else {
      setErrorMessage("请先上传或加载图片")
    }
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/app-info")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">编辑应用图标</h1>
      </header>

      <div className="flex-1 p-4 pb-[76px] flex flex-col">
        <div className="flex flex-col items-center mb-8">
          <div className="w-[120px] h-[120px] rounded-[30px] bg-[#F5F5F7] dark:bg-[#1A1A1A] flex items-center justify-center overflow-hidden mb-4 border border-black/10 dark:border-white/10 relative">
            {isLoading ? (
              <div className="absolute inset-0 flex items-center justify-center bg-black/5 dark:bg-white/5">
                <div className="w-8 h-8 border-2 border-black/30 dark:border-white/30 border-t-black dark:border-t-white rounded-full animate-spin"></div>
              </div>
            ) : (
              <Image
                src={iconSrc || "/placeholder.svg"}
                alt="应用图标"
                width={120}
                height={120}
                className="w-full h-full"
                style={{ ...previewStyle, objectFit: "cover" }}
                onLoad={() => setImageLoaded(true)}
                onError={() => {
                  setErrorMessage("图片加载失败，请尝试其他图片")
                  setImageLoaded(false)
                }}
              />
            )}
          </div>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2 rounded-full bg-black dark:bg-white text-white dark:text-black text-[14px] font-[500]"
            disabled={isLoading}
          >
            选择图片
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />

          {errorMessage && <p className="text-red-500 text-[14px] mt-2">{errorMessage}</p>}
        </div>

        <div className="space-y-4 mb-8">
          <h3 className="text-[16px] font-[600] text-black dark:text-white">通过URL加载图标</h3>
          <div className="flex space-x-2">
            <input
              type="text"
              value={iconUrl}
              onChange={(e) => setIconUrl(e.target.value)}
              placeholder="请输入图片URL"
              className="flex-1 h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
              disabled={isLoading}
            />
            <button
              onClick={handleUrlLoad}
              className="px-4 h-[44px] rounded-xl bg-black dark:bg-white text-white dark:text-black text-[14px] font-[500]"
              disabled={isLoading || !iconUrl}
            >
              {isLoading ? "加载中..." : "加载"}
            </button>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A] mb-8">
          <h3 className="text-[16px] font-[500] text-black dark:text-white mb-2">图标显示提示</h3>
          <p className="text-[14px] text-black/60 dark:text-white/60">
            为获得最佳显示效果，请上传正方形图片（1:1比例）。图片将自动适配显示区域，确保没有空白区域。
          </p>
        </div>

        <div className="mt-auto">
          <button
            onClick={handleSave}
            className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
            disabled={isLoading || !imageLoaded}
          >
            {isSaved ? "已保存" : "保存图标"}
          </button>
        </div>
      </div>
    </div>
  )
}

