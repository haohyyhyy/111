"use client"

import { useState, useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { UserContext } from "@/context/user-context"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

export default function AdminAccountSettingsPage() {
  const router = useRouter()
  const { admin, updateAdmin } = useContext(UserContext)
  const { adminDarkMode } = useContext(SettingsContext)

  const [username, setUsername] = useState(admin.username)
  const [password, setPassword] = useState(admin.password)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 处理保存
  const handleSave = () => {
    setError("")
    setSuccess(false)

    // 验证输入
    if (!username) {
      setError("请输入用户名")
      return
    }

    if (!password) {
      setError("请输入密码")
      return
    }

    // 更新管理员信息
    updateAdmin({
      username,
      password,
    })

    // 显示成功提示
    setSuccess(true)

    // 3秒后隐藏成功提示
    setTimeout(() => {
      setSuccess(false)
    }, 3000)
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/settings")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">账号设置</h1>
      </header>

      <div className="flex-1 p-4 space-y-6 pb-[76px]">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-[14px] text-black/60 dark:text-white/60">用户名</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[14px] text-black/60 dark:text-white/60">密码</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
            />
          </div>

          {error && <p className="text-red-500 text-[14px]">{error}</p>}
          {success && <p className="text-green-500 text-[14px]">保存成功</p>}

          <button
            onClick={handleSave}
            className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500] mt-4"
          >
            保存
          </button>
        </div>
      </div>

      <AdminNavBar />
    </div>
  )
}

