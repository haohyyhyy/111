"use client"

import { useState, useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { UserContext } from "@/context/user-context"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

export default function UsersPage() {
  const router = useRouter()
  const { users, setCurrentUser, addUser } = useContext(UserContext)
  const { adminDarkMode } = useContext(SettingsContext)
  const [showAddModal, setShowAddModal] = useState(false)
  const [newPhone, setNewPhone] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [error, setError] = useState("")

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 验证手机号格式
  const isValidPhone = (phone: string) => {
    return /^1[3-9]\d{9}$/.test(phone)
  }

  // 处理添加用户
  const handleAddUser = () => {
    setError("")

    // 验证手机号
    if (!newPhone) {
      setError("请输入手机号")
      return
    }

    if (!isValidPhone(newPhone)) {
      setError("请输入正确的手机号")
      return
    }

    // 检查手机号是否已注册
    if (users.some((user) => user.phone === newPhone)) {
      setError("此手机号已注册")
      return
    }

    // 验证密码
    if (!newPassword) {
      setError("请输入密码")
      return
    }

    if (newPassword.length < 6) {
      setError("密码需6位以上")
      return
    }

    // 添加新用户
    const newUser = {
      id: Date.now().toString(),
      phone: newPhone,
      password: newPassword,
      key: `ai-yonghu-${Math.random().toString(36).substring(2, 7)}`,
    }

    addUser(newUser)

    // 关闭弹窗并清空输入
    setShowAddModal(false)
    setNewPhone("")
    setNewPassword("")
  }

  // 查看用户详情
  const viewUserDetail = (userId: string) => {
    const user = users.find((user) => user.id === userId)
    if (user) {
      setCurrentUser(user)
      router.push("/chat")
    }
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center justify-between px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <div className="flex items-center">
          <button
            onClick={() => router.push("/admin")}
            className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M15 6L9 12L15 18"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">用户管理</h1>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="h-10 px-4 rounded-full bg-black dark:bg-white text-white dark:text-black text-[14px] font-[500]"
        >
          添加用户
        </button>
      </header>

      <div className="flex-1 p-4 space-y-4 pb-[76px]">
        {users.map((user) => (
          <div
            key={user.id}
            className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A] border border-black/[0.06] dark:border-white/[0.06]"
          >
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-[16px] font-[500] text-black dark:text-white">{user.phone}</h3>
              <button
                onClick={() => viewUserDetail(user.id)}
                className="text-[14px] text-black/60 dark:text-white/60 hover:text-black hover:dark:text-white"
              >
                详情
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-[12px] text-black/40 dark:text-white/40">密码</p>
                <p className="text-[14px] text-black/80 dark:text-white/80">******</p>
              </div>
              <div>
                <p className="text-[12px] text-black/40 dark:text-white/40">密钥</p>
                <p className="text-[14px] text-black/80 dark:text-white/80">{user.key}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <AdminNavBar />

      {/* 添加用户弹窗 */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 dark:bg-black/70 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-[320px] bg-white dark:bg-[#1A1A1A] rounded-2xl p-6">
            <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-4">添加用户</h3>

            <div className="space-y-4">
              <div>
                <input
                  type="tel"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="手机号"
                  maxLength={11}
                  className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
                />
              </div>

              <div>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="密码"
                  className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white"
                />
              </div>

              {error && <p className="text-red-500 text-[14px]">{error}</p>}
            </div>

            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 h-[44px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500]"
              >
                取消
              </button>
              <button
                onClick={handleAddUser}
                className="flex-1 h-[44px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
              >
                添加
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

