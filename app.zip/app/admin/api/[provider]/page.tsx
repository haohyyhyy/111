"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"

export default function ApiProviderPage({ params }: { params: { provider: string } }) {
  const router = useRouter()
  const [apiKey, setApiKey] = useState("")
  const [isSaved, setIsSaved] = useState(false)

  const providerNames: Record<string, string> = {
    deepseek: "DeepSeek",
    silicon: "硅基流动",
    openai: "OpenAI",
    wenxin: "文心一言",
    qianwen: "通义千问",
  }

  const handleSave = () => {
    if (apiKey.trim()) {
      setIsSaved(true)
      setTimeout(() => setIsSaved(false), 2000)
    }
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/api")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">
          {providerNames[params.provider] || params.provider}
        </h1>
      </header>

      <div className="p-4 space-y-6">
        <div className="space-y-2">
          <label className="text-[14px] text-black/60 dark:text-white/60">API 密钥</label>
          <input
            type="text"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="请输入API密钥"
            className="w-full h-[52px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40"
          />
        </div>

        <div className="space-y-2">
          <label className="text-[14px] text-black/60 dark:text-white/60">模型选择</label>
          <select className="w-full h-[52px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white appearance-none">
            <option>默认模型</option>
            <option>高级模型</option>
            <option>专业模型</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-[14px] text-black/60 dark:text-white/60">温度设置</label>
          <input
            type="range"
            min="0"
            max="100"
            defaultValue="70"
            className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-black [&::-webkit-slider-thumb]:dark:bg-white"
          />
          <div className="flex justify-between text-[12px] text-black/40 dark:text-white/40">
            <span>精确</span>
            <span>平衡</span>
            <span>创意</span>
          </div>
        </div>

        <button
          onClick={handleSave}
          className="w-full h-[52px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500] transition-all hover:opacity-90"
        >
          {isSaved ? "已保存" : "保存设置"}
        </button>
      </div>
    </div>
  )
}

