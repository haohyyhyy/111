"use client"

import { useState, useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

export default function XunfeiApiPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)

  const [appId, setAppId] = useState("")
  const [apiKey, setApiKey] = useState("")
  const [apiSecret, setApiSecret] = useState("") // 新增API Secret字段
  const [isLocked, setIsLocked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 从本地存储加载配置
  useEffect(() => {
    const storedConfig = localStorage.getItem("xunfeiConfig")
    if (storedConfig) {
      const config = JSON.parse(storedConfig)
      setAppId(config.appId || "")
      setApiKey(config.apiKey || "")
      setApiSecret(config.apiSecret || "") // 加载API Secret
      setIsLocked(!!config.appId && !!config.apiKey && !!config.apiSecret)
    }
  }, [])

  // 保存配置
  const handleSave = () => {
    if (!appId || !apiKey || !apiSecret) {
      // 检查所有必填字段
      setTestResult({
        success: false,
        message: "请填写完整的APP ID、API KEY和API SECRET",
      })
      return
    }

    const config = {
      appId,
      apiKey,
      apiSecret, // 保存API Secret
    }

    localStorage.setItem("xunfeiConfig", JSON.stringify(config))
    setIsLocked(true)
    setIsSaved(true)
    setTimeout(() => setIsSaved(false), 2000)
  }

  // 测试连接
  const handleTestConnection = async () => {
    if (!appId || !apiKey || !apiSecret) {
      // 检查所有必填字段
      setTestResult({
        success: false,
        message: "请填写完整的APP ID、API KEY和API SECRET",
      })
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      // 这里只是模拟测试，实际应用中应该调用讯飞API进行测试
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setTestResult({
        success: true,
        message: "连接成功！API配置有效。",
      })
    } catch (error) {
      setTestResult({
        success: false,
        message: `连接失败: ${error instanceof Error ? error.message : "未知错误"}`,
      })
    } finally {
      setIsLoading(false)
    }
  }

  // 处理保存/更改
  const handleSaveOrEdit = () => {
    if (isLocked) {
      // 解锁设置
      setIsLocked(false)
    } else {
      // 保存设置
      handleSave()
    }
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/api/voice")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">讯飞语音听写</h1>
      </header>

      <div className="flex-1 p-4 space-y-6 pb-[76px]">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-[14px] text-black/60 dark:text-white/60">APP ID</label>
            <input
              type="text"
              value={appId}
              onChange={(e) => setAppId(e.target.value)}
              placeholder="请输入讯飞应用的APP ID"
              disabled={isLocked}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[14px] text-black/60 dark:text-white/60">API SECRET</label>
            <input
              type="password"
              value={apiSecret}
              onChange={(e) => setApiSecret(e.target.value)}
              placeholder="请输入讯飞应用的API SECRET"
              disabled={isLocked}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[14px] text-black/60 dark:text-white/60">API KEY</label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="请输入讯飞应用的API KEY"
              disabled={isLocked}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
            />
          </div>

          {testResult && (
            <div
              className={`p-3 rounded-lg text-[14px] ${
                testResult.success
                  ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                  : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
              }`}
            >
              {testResult.message}
            </div>
          )}

          <div className="flex space-x-4 pt-4">
            <button
              onClick={handleTestConnection}
              disabled={isLoading || !appId || !apiKey || !apiSecret}
              className="flex-1 h-[48px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500] disabled:opacity-50"
            >
              {isLoading ? "测试中..." : "测试连接"}
            </button>
            <button
              onClick={handleSaveOrEdit}
              className="flex-1 h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
            >
              {isLocked ? "更改" : isSaved ? "已保存" : "保存"}
            </button>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
          <h3 className="text-[16px] font-[500] text-black dark:text-white mb-2">讯飞语音听写说明</h3>
          <p className="text-[14px] text-black/60 dark:text-white/60 mb-4">
            讯飞语音听写API可以将语音实时转换为文字，支持中文、英文等多种语言，适用于各种语音输入场景。
          </p>
          <ol className="text-[14px] text-black/60 dark:text-white/60 space-y-2 list-decimal pl-5">
            <li>登录讯飞开放平台官网 (https://www.xfyun.cn/)</li>
            <li>创建应用并开通语音听写服务</li>
            <li>获取应用的APP ID、API SECRET和API KEY</li>
            <li>填写到上方对应输入框并保存</li>
            <li>保存后，语音听写功能将在对话页面的语音输入中自动启用</li>
          </ol>
        </div>
      </div>

      <AdminNavBar />
    </div>
  )
}

