"use client"

import { useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

export default function AliApiPage() {
  const router = useRouter()
  const { adminDarkMode } = useContext(SettingsContext)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/api/voice")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">阿里语音转写</h1>
      </header>

      <div className="flex-1 p-4 space-y-4 pb-[76px] flex items-center justify-center">
        <p className="text-black/40 dark:text-white/40 text-[16px]">功能开发中，敬请期待</p>
      </div>

      <AdminNavBar />
    </div>
  )
}

