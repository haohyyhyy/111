"use client"

import { useState, useContext, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Switch } from "@/components/ui/switch"
import { ApiContext } from "@/context/api-context"
import { SettingsContext } from "@/context/settings-context"
import { AdminNavBar } from "@/components/admin-nav-bar"

export default function DeepseekApiPage() {
  const router = useRouter()
  const { deepseekConfig, updateDeepseekConfig, testDeepseekConnection } = useContext(ApiContext)
  const { adminDarkMode } = useContext(SettingsContext)

  const [isLocked, setIsLocked] = useState(deepseekConfig.connected)
  const [isLoading, setIsLoading] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)

  // 确保应用正确的主题
  useEffect(() => {
    if (adminDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [adminDarkMode])

  // 修改testDeepseekConnection函数
  const handleTestConnection = async () => {
    setIsLoading(true)
    setTestResult(null)

    try {
      // 检查API密钥是否存在
      if (!deepseekConfig.apiKey) {
        setTestResult({
          success: false,
          message: "请输入API密钥",
        })
        setIsLoading(false)
        return
      }

      // 验证API密钥格式
      if (!deepseekConfig.apiKey.startsWith("sk-")) {
        setTestResult({
          success: false,
          message: "API密钥格式错误，应以sk-开头",
        })
        setIsLoading(false)
        return
      }

      // 尝试调用DeepSeek API
      try {
        const response = await fetch("https://api.deepseek.com/v1/models", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${deepseekConfig.apiKey}`,
          },
        })

        if (response.ok) {
          updateDeepseekConfig({ connected: true })
          setTestResult({
            success: true,
            message: "连接成功！API密钥有效。",
          })
        } else {
          const errorData = await response.json()
          setTestResult({
            success: false,
            message: `API错误: ${errorData.error?.message || response.statusText}`,
          })
        }
      } catch (error) {
        setTestResult({
          success: false,
          message: `连接失败: ${error instanceof Error ? error.message : "未知错误"}`,
        })
      }
    } finally {
      setIsLoading(false)
    }
  }

  // 处理保存/更改
  const handleSaveOrEdit = () => {
    if (isLocked) {
      // 解锁设置
      setIsLocked(false)
    } else {
      // 锁定设置
      setIsLocked(true)
    }
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex flex-col">
      <header className="h-[60px] flex items-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/admin/api")}
          className="w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white ml-2">DeepSeek</h1>
      </header>

      <div className="flex-1 p-4 space-y-6 pb-[76px]">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-[14px] text-black/60 dark:text-white/60">API 密钥</label>
            <input
              type="text"
              value={deepseekConfig.apiKey}
              onChange={(e) => updateDeepseekConfig({ apiKey: e.target.value })}
              placeholder="请输入DeepSeek API密钥"
              disabled={isLocked}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white disabled:opacity-70"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[14px] text-black/60 dark:text-white/60">模型选择</label>
            <select
              value={deepseekConfig.model}
              onChange={(e) => {
                const newModel = e.target.value as "deepseek-r1" | "deepseek-v3"
                // 如果切换到deepseek-r1，自动关闭JSON模式
                if (newModel === "deepseek-r1") {
                  updateDeepseekConfig({ model: newModel, jsonMode: false })
                } else {
                  updateDeepseekConfig({ model: newModel })
                }
              }}
              disabled={isLocked}
              className="w-full h-[44px] px-4 rounded-xl border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white appearance-none disabled:opacity-70"
            >
              <option value="deepseek-v3">DeepSeek V3</option>
              <option value="deepseek-r1">DeepSeek R1</option>
            </select>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-[14px] text-black/60 dark:text-white/60">携带上下文次数</label>
              <span className="text-[14px] text-black/60 dark:text-white/60">{deepseekConfig.contextCount}</span>
            </div>
            <input
              type="range"
              min="1"
              max="6"
              value={deepseekConfig.contextCount}
              onChange={(e) => updateDeepseekConfig({ contextCount: Number.parseInt(e.target.value) })}
              disabled={isLocked}
              className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-black [&::-webkit-slider-thumb]:dark:bg-white disabled:opacity-70"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
              <div>
                <span className="text-[16px] text-black dark:text-white">JSON 模式</span>
                <p className="text-[12px] text-black/60 dark:text-white/60 mt-1">
                  {deepseekConfig.model === "deepseek-r1"
                    ? "Reasoner模型不支持JSON输出"
                    : "启用后模型将以结构化JSON格式输出内容"}
                </p>
              </div>
              <Switch
                checked={deepseekConfig.model === "deepseek-r1" ? false : deepseekConfig.jsonMode}
                onCheckedChange={(checked) => updateDeepseekConfig({ jsonMode: checked })}
                disabled={isLocked || deepseekConfig.model === "deepseek-r1"}
                className="data-[state=checked]:bg-green-500 dark:data-[state=checked]:bg-green-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
            <span className="text-[16px] text-black dark:text-white">思考过程输出</span>
            <Switch
              checked={deepseekConfig.showThinking}
              onCheckedChange={(checked) => updateDeepseekConfig({ showThinking: checked })}
              disabled={isLocked}
            />
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-[#F5F5F7] dark:bg-[#1A1A1A]">
            <span className="text-[16px] text-black dark:text-white">流式输出</span>
            <Switch
              checked={deepseekConfig.streamOutput}
              onCheckedChange={(checked) => updateDeepseekConfig({ streamOutput: checked })}
              disabled={isLocked}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-[14px] text-black/60 dark:text-white/60">生成文本长度</label>
              <span className="text-[14px] text-black/60 dark:text-white/60">{deepseekConfig.maxTokens}</span>
            </div>
            <input
              type="range"
              min="100"
              max="4000"
              step="100"
              value={deepseekConfig.maxTokens}
              onChange={(e) => updateDeepseekConfig({ maxTokens: Number.parseInt(e.target.value) })}
              disabled={isLocked}
              className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-black [&::-webkit-slider-thumb]:dark:bg-white disabled:opacity-70"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-[14px] text-black/60 dark:text-white/60">随机性</label>
              <span className="text-[14px] text-black/60 dark:text-white/60">
                {deepseekConfig.temperature.toFixed(1)}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={deepseekConfig.temperature}
              onChange={(e) => updateDeepseekConfig({ temperature: Number.parseFloat(e.target.value) })}
              disabled={isLocked}
              className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-black [&::-webkit-slider-thumb]:dark:bg-white disabled:opacity-70"
            />
            <div className="flex justify-between text-[12px] text-black/40 dark:text-white/40">
              <span>精确</span>
              <span>平衡</span>
              <span>创意</span>
            </div>
          </div>

          {testResult && (
            <div
              className={`p-3 rounded-lg text-[14px] ${
                testResult.success
                  ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
                  : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
              }`}
            >
              {testResult.message}
            </div>
          )}

          <div className="flex space-x-4 pt-4">
            <button
              onClick={handleTestConnection}
              disabled={isLoading || !deepseekConfig.apiKey}
              className="flex-1 h-[48px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500] disabled:opacity-50"
            >
              {isLoading ? "测试中..." : "测试连接"}
            </button>
            <button
              onClick={handleSaveOrEdit}
              className="flex-1 h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[16px] font-[500]"
            >
              {isLocked ? "更改" : "保存"}
            </button>
          </div>
        </div>
      </div>

      <AdminNavBar />
    </div>
  )
}

