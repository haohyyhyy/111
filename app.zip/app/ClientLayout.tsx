"use client"

import type React from "react"
import { UserProvider } from "@/context/user-context"
import { SettingsProvider } from "@/context/settings-context"
import { ApiProvider } from "@/context/api-context"

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <UserProvider>
      <SettingsProvider>
        <ApiProvider>
          <body>{children}</body>
        </ApiProvider>
      </SettingsProvider>
    </UserProvider>
  )
}

