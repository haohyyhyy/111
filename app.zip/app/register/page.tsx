"use client"

import type React from "react"

import { useState, useContext, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { UserContext } from "@/context/user-context"

export default function RegisterPage() {
  const router = useRouter()
  const { addUser, isPhoneRegistered, generateKey } = useContext(UserContext)

  const [phone, setPhone] = useState("")
  const [code, setCode] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [countdown, setCountdown] = useState(0)
  const [generatedCode, setGeneratedCode] = useState("")
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [passwordFocused, setPasswordFocused] = useState(false)

  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // 清理定时器
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [])

  // 验证手机号格式
  const isValidPhone = (phone: string) => {
    return /^1[3-9]\d{9}$/.test(phone)
  }

  // 处理发送验证码
  const handleSendCode = () => {
    setError("")

    // 验证手机号
    if (!phone) {
      setError("请输入手机号")
      return
    }

    if (!isValidPhone(phone)) {
      setError("请输入正确的手机号")
      return
    }

    // 检查手机号是否已注册
    if (isPhoneRegistered(phone)) {
      setError("此手机号已注册，请更换其他手机号")
      return
    }

    // 生成6位随机验证码
    const newCode = Math.floor(100000 + Math.random() * 900000).toString()
    setGeneratedCode(newCode)
    setCode(newCode) // 自动填入验证码，实际应用中应该通过短信发送

    // 开始倒计时
    setCountdown(60)
    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (timerRef.current) {
            clearInterval(timerRef.current)
          }
          return 0
        }
        return prev - 1
      })
    }, 1000)
  }

  // 处理注册
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // 验证手机号
    if (!phone) {
      setError("请输入手机号")
      return
    }

    if (!isValidPhone(phone)) {
      setError("请输入正确的手机号")
      return
    }

    // 检查手机号是否已注册
    if (isPhoneRegistered(phone)) {
      setError("此手机号已注册，请更换其他手机号")
      return
    }

    // 验证验证码
    if (!code) {
      setError("请输入验证码")
      return
    }

    if (code !== generatedCode) {
      setError("验证码错误")
      return
    }

    // 验证密码
    if (!password) {
      setError("请设置密码")
      return
    }

    if (password.length < 6) {
      setError("密码需6位以上请重新输入")
      return
    }

    if (password !== confirmPassword) {
      setError("两次输入的密码不一致请重新输入")
      return
    }

    setIsLoading(true)

    // 生成用户ID和密钥
    const userId = Date.now().toString()
    const userKey = generateKey()

    // 添加新用户
    addUser({
      id: userId,
      phone,
      password,
      key: userKey,
    })

    // 显示成功弹窗
    setShowSuccessModal(true)

    // 1秒后跳转到登录页面
    setTimeout(() => {
      setIsLoading(false)
      router.push("/")
    }, 1000)
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black flex items-center justify-center p-6">
      <div className="w-full max-w-[360px]">
        <div className="mb-12 flex justify-center">
          <div className="w-[80px] h-[80px] rounded-[24px] bg-black dark:bg-white flex items-center justify-center shadow-[0_8px_30px_rgba(0,0,0,0.12)] dark:shadow-[0_8px_30px_rgba(255,255,255,0.12)]">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle
                cx="12"
                cy="12"
                r="10"
                stroke={`${typeof window !== "undefined" && document.documentElement.classList.contains("dark") ? "#000000" : "#FFFFFF"}`}
                strokeWidth="1.5"
              />
              <circle
                cx="12"
                cy="9"
                r="2"
                stroke={`${typeof window !== "undefined" && document.documentElement.classList.contains("dark") ? "#000000" : "#FFFFFF"}`}
                strokeWidth="1.5"
              />
              <path
                d="M7 18.5C7 15.5 9 14 12 14C15 14 17 15.5 17 18.5"
                stroke={`${typeof window !== "undefined" && document.documentElement.classList.contains("dark") ? "#000000" : "#FFFFFF"}`}
                strokeWidth="1.5"
              />
            </svg>
          </div>
        </div>

        <h1 className="text-[24px] font-[600] text-black dark:text-white text-center mb-8">新用户注册</h1>

        <form onSubmit={handleRegister} className="space-y-5">
          <div>
            <div className="relative">
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="手机号"
                maxLength={11}
                className="w-full h-[44px] px-5 rounded-full border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40"
                required
              />
            </div>
          </div>

          <div>
            <div className="relative flex items-center">
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="验证码"
                className="w-full h-[44px] px-5 rounded-full border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40"
                required
              />
              <button
                type="button"
                onClick={handleSendCode}
                disabled={countdown > 0}
                className="absolute right-2 h-[36px] px-3 rounded-full bg-black dark:bg-white text-white dark:text-black text-[14px] font-[500] disabled:opacity-50"
              >
                {countdown > 0 ? `${countdown}秒后重发` : "获取验证码"}
              </button>
            </div>
          </div>

          <div>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onFocus={() => setPasswordFocused(true)}
                onBlur={() => setPasswordFocused(false)}
                placeholder="设置密码"
                className="w-full h-[44px] px-5 rounded-full border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40"
                required
              />
              {passwordFocused && (
                <div className="absolute -bottom-6 left-0 text-[12px] text-black/60 dark:text-white/60">
                  密码长度为6位以上
                </div>
              )}
            </div>
          </div>

          <div>
            <div className="relative">
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="确认密码"
                className="w-full h-[44px] px-5 rounded-full border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[16px] focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40"
                required
              />
            </div>
          </div>

          {error && <p className="text-red-500 text-center text-[14px]">{error}</p>}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-[48px] rounded-full bg-black dark:bg-white text-white dark:text-black text-[17px] font-[500] transition-all hover:opacity-90 disabled:opacity-50"
          >
            {isLoading ? "注册中..." : "注册"}
          </button>

          <div className="text-center text-[14px] text-black/60 dark:text-white/60 pt-2">
            <button
              type="button"
              onClick={() => router.push("/")}
              className="hover:text-black dark:hover:text-white transition-colors"
            >
              已有账号？返回登录
            </button>
          </div>
        </form>
      </div>

      {/* 成功弹窗 */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/50 dark:bg-black/70 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-[#1A1A1A] rounded-xl p-6 max-w-[280px] text-center">
            <svg
              className="w-16 h-16 text-green-500 mx-auto mb-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            <h3 className="text-[18px] font-[600] text-black dark:text-white mb-2">恭喜你已注册成功</h3>
            <p className="text-[14px] text-black/60 dark:text-white/60">请登录</p>
          </div>
        </div>
      )}
    </div>
  )
}

