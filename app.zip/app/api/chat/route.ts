import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"

// 允许流式响应最多30秒
export const maxDuration = 30

export async function POST(req: Request) {
  const { messages } = await req.json()

  // 使用AI SDK生成响应
  const result = streamText({
    model: openai("gpt-4-turbo"),
    messages,
  })

  return result.toDataStreamResponse()
}

