import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { app_id, app_secret } = await req.json()

    // 验证必要参数
    if (!app_id || !app_secret) {
      return NextResponse.json({ error: "缺少必要参数 app_id 或 app_secret" }, { status: 400 })
    }

    // 调用飞书API获取租户访问凭证
    const response = await fetch("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        app_id,
        app_secret,
      }),
    })

    // 解析响应
    const data = await response.json()

    // 检查响应状态
    if (data.code !== 0) {
      return NextResponse.json({ error: `飞书API错误: ${data.msg} (错误码: ${data.code})` }, { status: 400 })
    }

    // 返回成功响应
    return NextResponse.json({
      tenant_access_token: data.tenant_access_token,
      expire: data.expire,
    })
  } catch (error) {
    console.error("获取飞书租户访问凭证错误:", error)
    return NextResponse.json(
      { error: `服务器错误: ${error instanceof Error ? error.message : "未知错误"}` },
      { status: 500 },
    )
  }
}

