import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { token, appToken, tableId } = await req.json()

    // 验证必要参数
    if (!token || !appToken) {
      return NextResponse.json({ error: "缺少必要参数 token 或 appToken" }, { status: 400 })
    }

    // 验证多维表格访问权限
    const appResponse = await fetch(`https://open.feishu.cn/open-apis/bitable/v1/apps/${appToken}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    })

    // 解析响应
    const appData = await appResponse.json()

    // 检查响应状态
    if (appData.code !== 0) {
      return NextResponse.json({ error: `多维表格验证失败: ${appData.msg} (错误码: ${appData.code})` }, { status: 400 })
    }

    // 如果提供了tableId，验证表格访问权限
    if (tableId) {
      const tableResponse = await fetch(
        `https://open.feishu.cn/open-apis/bitable/v1/apps/${appToken}/tables/${tableId}`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      )

      // 解析响应
      const tableData = await tableResponse.json()

      // 检查响应状态
      if (tableData.code !== 0) {
        return NextResponse.json(
          { error: `数据表验证失败: ${tableData.msg} (错误码: ${tableData.code})` },
          { status: 400 },
        )
      }

      // 返回表格信息
      return NextResponse.json({
        app: appData.data,
        table: tableData.data,
      })
    }

    // 返回应用信息
    return NextResponse.json({
      app: appData.data,
    })
  } catch (error) {
    console.error("验证飞书多维表格错误:", error)
    return NextResponse.json(
      { error: `服务器错误: ${error instanceof Error ? error.message : "未知错误"}` },
      { status: 500 },
    )
  }
}

