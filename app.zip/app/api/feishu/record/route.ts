import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { token, appToken, tableId, fields } = await req.json()

    // 验证必要参数
    if (!token || !appToken || !tableId || !fields) {
      return NextResponse.json({ error: "缺少必要参数 token, appToken, tableId 或 fields" }, { status: 400 })
    }

    // 调用飞书API存储数据
    const response = await fetch(
      `https://open.feishu.cn/open-apis/bitable/v1/apps/${appToken}/tables/${tableId}/records`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fields,
        }),
      },
    )

    // 解析响应
    const data = await response.json()

    // 检查响应状态
    if (data.code !== 0) {
      return NextResponse.json({ error: `存储数据失败: ${data.msg} (错误码: ${data.code})` }, { status: 400 })
    }

    // 返回成功响应
    return NextResponse.json({
      record: data.data.record,
    })
  } catch (error) {
    console.error("存储飞书多维表格数据错误:", error)
    return NextResponse.json(
      { error: `服务器错误: ${error instanceof Error ? error.message : "未知错误"}` },
      { status: 500 },
    )
  }
}

