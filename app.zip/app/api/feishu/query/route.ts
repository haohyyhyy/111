import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { token, appToken, tableId, filterField, filterValue } = await req.json()

    // 验证必要参数
    if (!token || !appToken || !tableId) {
      return NextResponse.json({ error: "缺少必要参数 token, appToken 或 tableId" }, { status: 400 })
    }

    // 构建查询URL
    let url = `https://open.feishu.cn/open-apis/bitable/v1/apps/${appToken}/tables/${tableId}/records`

    // 如果有查询条件，添加过滤器
    if (filterField && filterValue) {
      const filter = JSON.stringify({
        field_name: filterField,
        operator: "contains",
        value: filterValue,
      })
      url += `?filter=${encodeURIComponent(filter)}`
    }

    // 调用飞书API查询数据
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    })

    // 解析响应
    const data = await response.json()

    // 检查响应状态
    if (data.code !== 0) {
      return NextResponse.json({ error: `查询数据失败: ${data.msg} (错误码: ${data.code})` }, { status: 400 })
    }

    // 返回成功响应
    return NextResponse.json({
      items: data.data.items || [],
      page_token: data.data.page_token,
      has_more: data.data.has_more,
      total: data.data.total,
    })
  } catch (error) {
    console.error("查询飞书多维表格数据错误:", error)
    return NextResponse.json(
      { error: `服务器错误: ${error instanceof Error ? error.message : "未知错误"}` },
      { status: 500 },
    )
  }
}

