"use client"

import type React from "react"

import { useState, useRef, useEffect, useContext, useCallback } from "react"
import { useRouter } from "next/navigation"
import { AnimatePresence, motion } from "framer-motion"

import { NavBar } from "@/components/nav-bar"
import { VoiceWave } from "@/components/voice-wave"
import { VoiceTranscriptionModal } from "@/components/voice-transcription-modal"
import { SettingsContext } from "@/context/settings-context"
import { UserContext } from "@/context/user-context"
import { ApiContext } from "@/context/api-context"

// 在组件顶部添加全局变量，用于跨组件共享语音识别实例
// 添加在import语句之后
if (typeof window !== "undefined") {
  window.speechRecognition = null
}

// 将formatResponseText函数移到全局作用域，解决"formatResponseText is not defined"错误
// 在文件顶部，import语句之后，组件定义之前添加这个函数

// 格式化响应文本
function formatResponseText(text: string) {
  // 将换行符替换为HTML换行符
  const formattedText = text.replace(/\n/g, "<br />")
  return formattedText
}

export default function ChatPage() {
  const router = useRouter()
  const { fontSize, voiceEnabled } = useContext(SettingsContext)
  const { currentUser } = useContext(UserContext)
  const { deepseekConfig } = useContext(ApiContext)

  // 移除初始欢迎语
  const [messages, setMessages] = useState<{ role: "user" | "assistant"; content: string; thinking?: string }[]>([])
  const [input, setInput] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [isThinking, setIsThinking] = useState(false)
  const [displayedThinking, setDisplayedThinking] = useState("")
  const [displayedResponse, setDisplayedResponse] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [isInputDisabled, setIsInputDisabled] = useState(false)
  const [showThinking, setShowThinking] = useState(false)
  const [thinkingComplete, setThinkingComplete] = useState(false)
  const [hasStartedOutput, setHasStartedOutput] = useState(false)
  const [outputLineCount, setOutputLineCount] = useState(0)
  const [shouldScroll, setShouldScroll] = useState(false)
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [isProcessingMessage, setIsProcessingMessage] = useState(false)
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const messageContainerRef = useRef<HTMLDivElement>(null)
  const outputContainerRef = useRef<HTMLDivElement>(null)
  const thinkingContainerRef = useRef<HTMLDivElement>(null)
  const responseContainerRef = useRef<HTMLDivElement>(null)
  const lastOutputLength = useRef(0)
  const scrollTimer = useRef<NodeJS.Timeout | null>(null)
  const outputObserver = useRef<ResizeObserver | null>(null)
  const isScrolling = useRef(false)
  const lastScrollPosition = useRef(0)
  const messageProcessingRef = useRef<{
    userMessage: string
    isProcessing: boolean
    abortController: AbortController | null
  }>({
    userMessage: "",
    isProcessing: false,
    abortController: null,
  })
  const thinkingContainerHeight = useRef<number>(0)
  const responseContainerHeight = useRef<number>(0)
  const outputBuffer = useRef<string>("")
  const outputQueue = useRef<{ type: "thinking" | "response"; text: string }[]>([])
  const isProcessingOutput = useRef<boolean>(false)

  // 添加新的状态变量
  const [isRecordingInPlace, setIsRecordingInPlace] = useState(false)

  // 检查用户是否已登录
  useEffect(() => {
    if (!currentUser) {
      router.push("/")
    }
  }, [currentUser, router])

  // Make sure scrollToBottom is defined before checkIfShouldScroll
  // 1. 修改滑动逻辑，让滑动条向页面底部滑动
  // 修改 scrollToBottom 函数，确保滚动方向正确
  const scrollToBottom = useCallback((duration = 300) => {
    if (!messageContainerRef.current) return

    const container = messageContainerRef.current
    const scrollHeight = container.scrollHeight
    const currentScrollTop = container.scrollTop
    const targetScrollTop = scrollHeight - container.clientHeight
    const scrollDistance = targetScrollTop - currentScrollTop

    // 如果已经在底部或接近底部，不需要滚动
    if (scrollDistance < 10) return

    // 清除之前的滚动计时器
    if (scrollTimer.current) {
      clearInterval(scrollTimer.current)
    }

    const startTime = performance.now()
    const startScrollTop = container.scrollTop

    const scrollStep = (timestamp: number) => {
      // 如果用户正在手动滚动，取消自动滚动
      if (isScrolling.current) return

      const elapsed = timestamp - startTime
      const progress = Math.min(elapsed / duration, 1)

      // 使用缓动函数使滚动更平滑
      const easeInOutQuad = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2)
      const easedProgress = easeInOutQuad(progress)

      // 确保滚动方向是向下的
      container.scrollTop = startScrollTop + scrollDistance * easedProgress

      if (progress < 1) {
        requestAnimationFrame(scrollStep)
      }
    }

    requestAnimationFrame(scrollStep)
  }, [])

  // 2. 清除大模型输出内容时的所有滚动条的滑动功能
  // 修改 checkIfShouldScroll 函数，只在用户输入时触发滚动
  const checkIfShouldScroll = useCallback(() => {
    const container = messageContainerRef.current
    if (!container) return

    // 如果用户正在手动滚动，不要自动滚动
    if (isScrolling.current) return

    // 只在用户输入消息时自动滚动，大模型输出时不自动滚动
    if (!isTyping && !isThinking && !isProcessingMessage) return

    // 只有当用户刚刚发送消息时才自动滚动
    if (messages.length > 0 && messages[messages.length - 1].role === "user") {
      scrollToBottom(200)
    }
  }, [isTyping, isThinking, isProcessingMessage, scrollToBottom, messages])

  // 初始化ResizeObserver监听输出容器大小变化
  useEffect(() => {
    // 创建ResizeObserver实例
    outputObserver.current = new ResizeObserver((entries) => {
      // 如果用户正在手动滚动，不要自动滚动
      if (isScrolling.current) return

      for (const entry of entries) {
        if (entry.target === thinkingContainerRef.current) {
          // 记录思考容器高度
          thinkingContainerHeight.current = entry.contentRect.height
        } else if (entry.target === responseContainerRef.current) {
          // 记录响应容器高度
          responseContainerHeight.current = entry.contentRect.height
        }

        // 检查是否需要滚动
        checkIfShouldScroll()
      }
    })

    // 监听输出容器
    if (outputContainerRef.current) {
      outputObserver.current.observe(outputContainerRef.current)
    }

    // 监听思考容器
    if (thinkingContainerRef.current) {
      outputObserver.current.observe(thinkingContainerRef.current)
    }

    // 监听响应容器
    if (responseContainerRef.current) {
      outputObserver.current.observe(responseContainerRef.current)
    }

    // 清理函数
    return () => {
      if (outputObserver.current) {
        outputObserver.current.disconnect()
      }
    }
  }, [checkIfShouldScroll])

  // 监听用户手动滚动
  useEffect(() => {
    const container = messageContainerRef.current
    if (!container) return

    const handleScroll = () => {
      // 记录当前滚动位置
      lastScrollPosition.current = container.scrollTop

      // 标记用户正在滚动
      isScrolling.current = true

      // 设置一个定时器，在滚动停止后重置标志
      if (scrollTimer.current) {
        clearTimeout(scrollTimer.current)
      }

      scrollTimer.current = setTimeout(() => {
        isScrolling.current = false

        // 检查是否需要滚动
        checkIfShouldScroll()
      }, 100)
    }

    container.addEventListener("scroll", handleScroll)

    return () => {
      container.removeEventListener("scroll", handleScroll)
      if (scrollTimer.current) {
        clearTimeout(scrollTimer.current)
      }
    }
  }, [checkIfShouldScroll])

  // 修改滑动条逻辑，每输出三行内容自动滑动到底部
  // 添加以下函数和变量：

  // 添加行计数器和上次滚动时间
  const [lineCounter, setLineCounter] = useState(0)
  const lastScrollTime = useRef(0)

  // 修改processOutputQueue函数，添加行计数和滚动逻辑
  const processOutputQueue = useCallback(() => {
    if (isProcessingOutput.current || outputQueue.current.length === 0) return

    isProcessingOutput.current = true

    // 使用requestAnimationFrame确保UI更新平滑
    requestAnimationFrame(() => {
      // 处理队列中的第一项
      const item = outputQueue.current.shift()
      if (!item) {
        isProcessingOutput.current = false
        return
      }

      if (item.type === "thinking") {
        setDisplayedThinking((prev) => prev + item.text)
      } else {
        setDisplayedResponse((prev) => prev + item.text)

        // 检测换行符，计算行数
        if (item.text.includes("\n")) {
          // 计算新增的行数
          const newLines = item.text.split("\n").length - 1
          setLineCounter((prev) => {
            const newCount = prev + newLines

            // 每累积三行内容，滚动到底部
            if (newCount >= 3) {
              const now = Date.now()
              // 确保滚动间隔至少300ms，避免滚动过于频繁
              if (now - lastScrollTime.current > 300) {
                scrollToBottom(200)
                lastScrollTime.current = now
                return 0 // 重置计数器
              }
            }
            return newCount
          })
        }
      }

      // 处理完成后，设置处理标志为false
      isProcessingOutput.current = false

      // 如果队列中还有项目，继续处理
      if (outputQueue.current.length > 0) {
        // 使用setTimeout给UI一点时间更新
        setTimeout(processOutputQueue, 10)
      }
    })
  }, [scrollToBottom])

  // 保存对话到历史记录
  const saveConversation = useCallback(
    (msgs: typeof messages, updateExisting = false) => {
      if (msgs.length === 0) return null

      // 使用用户ID作为前缀
      const userId = currentUser?.id || "guest"
      const storageKey = `${userId}_chatHistory`

      const existingChats = JSON.parse(localStorage.getItem(storageKey) || "[]")
      const now = new Date().toISOString()

      // 如果需要更新现有对话
      if (updateExisting && conversationId) {
        const updatedChats = existingChats.map((chat: any) => {
          if (chat.id === conversationId) {
            return {
              ...chat,
              messages: msgs,
              date: now, // 更新时间戳为最新
            }
          }
          return chat
        })

        localStorage.setItem(storageKey, JSON.stringify(updatedChats))
        return conversationId
      } else {
        // 创建新对话
        const newChatId = Date.now().toString()
        const newChat = {
          id: newChatId,
          title: msgs[0]?.content.substring(0, 20) + "..." || "新对话",
          date: now,
          messages: msgs,
        }

        localStorage.setItem(storageKey, JSON.stringify([newChat, ...existingChats]))
        return newChatId
      }
    },
    [conversationId, currentUser],
  )

  // 处理页面可见性变化
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === "hidden") {
        // 页面隐藏时，立即保存当前状态，无论是否正在处理消息
        if (messages.length > 0) {
          const chatId = saveConversation(messages, !!conversationId)
          if (chatId && !conversationId) {
            setConversationId(chatId)
          }
        }
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [messages, conversationId, saveConversation])

  // 修改handleSendMessage函数中的滚动行为
  const handleSendMessage = async () => {
    if (!input.trim() || isInputDisabled) return

    // 重置滚动状态，确保新消息可见
    isScrolling.current = false

    const userMessage = input.trim()

    // 添加用户消息
    const updatedMessages = [...messages, { role: "user", content: userMessage }]
    setMessages(updatedMessages)
    setInput("")

    // 重置所有状态
    setIsTyping(true)
    setIsInputDisabled(true)
    setDisplayedResponse("")
    setDisplayedThinking("")
    setShowThinking(false)
    setThinkingComplete(false)
    setIsThinking(true)
    setHasStartedOutput(false)
    setOutputLineCount(0)
    setShouldScroll(true) // 强制启用滚动
    lastOutputLength.current = 0
    setIsProcessingMessage(true)

    // 清空输出缓冲区和队列
    outputBuffer.current = ""
    outputQueue.current = []
    isProcessingOutput.current = false

    // 更新消息处理状态
    messageProcessingRef.current = {
      userMessage,
      isProcessing: true,
      abortController: new AbortController(),
    }

    // 如果不是第一次对话，直接滚动到底部
    if (messages.length > 0) {
      setTimeout(() => {
        scrollToBottom(200)
      }, 50)
    }

    try {
      // 如果是在历史会话中，更新历史会话
      if (conversationId) {
        saveConversation(updatedMessages, true)
      }

      // 检查是否有API配置
      if (deepseekConfig.connected && deepseekConfig.apiKey) {
        // 使用DeepSeek API
        await fetchAIResponse(userMessage, deepseekConfig)
      } else {
        // 使用模拟响应
        // 先显示思考中...
        await new Promise((resolve) => setTimeout(resolve, 800))

        // 模拟思考过程
        if (deepseekConfig.showThinking) {
          setShowThinking(true)
          const thinkingText = `我需要分析用户的问题："${userMessage}"。\n\n这个问题涉及到几个方面：\n1. 用户的具体需求是什么\n2. 我需要提供什么类型的信息\n3. 如何组织回答使其清晰易懂\n\n让我逐步思考这个问题...`

          // 模拟流式输出思考过程，确保平滑输出
          await streamTextWithConstantRate(
            thinkingText,
            (chunk) => {
              if (chunk === thinkingText.charAt(0)) {
                setIsThinking(false)
                setHasStartedOutput(true)
              }

              // 将思考内容添加到队列
              outputQueue.current.push({
                type: "thinking",
                text: chunk,
              })

              // 处理输出队列
              processOutputQueue()
            },
            30,
          )

          setThinkingComplete(true)
          await new Promise((resolve) => setTimeout(resolve, 300))
        } else {
          setIsThinking(false)
          setHasStartedOutput(true)
        }

        // 模拟最终答案
        const response = `# 解决方案分析

针对您提出的问题，我提供以下全面分析和建议：

## 一、需求分析

在开始解决问题前，我们需要明确以下几点：

1. 目标定义 - 确定您希望达成的具体目标
2. 约束条件 - 了解时间、资源和技术限制
3. 优先级排序 - 区分核心需求和次要功能

## 二、解决方案

### 1. 技术路径选择

根据您的需求，我建议采用以下技术路径：

① 前端框架选择React或Vue，提供响应式用户体验
② 后端采用Node.js或Python，确保开发效率
③ 数据存储使用MongoDB，适合快速迭代

### 2. 实施步骤

具体实施可分为以下几个阶段：

<背景框>重要提示：请在每个阶段结束时进行全面测试，确保质量</背景框>

① 需求分析与规划（1-2周）
② 基础架构搭建（1周）
③ 核心功能开发（2-4周）
④ 测试与优化（1-2周）
⑤ 部署上线（3-5天）

## 三、预期成果

通过上述方案，您将获得：

1. 高质量产品 - 符合现代设计标准的应用
2. 可扩展架构 - 便于未来功能扩展
3. 优质用户体验 - 流畅的交互和响应速度

希望这个方案能够满足您的需求！`

        // 模拟流式输出最终答案，确保平滑输出
        await streamTextWithConstantRate(
          response,
          (chunk) => {
            // 将响应内容添加到队列
            outputQueue.current.push({
              type: "response",
              text: chunk,
            })

            // 处理输出队列
            processOutputQueue()
          },
          30,
        )

        // 添加到消息列表
        const finalMessages = [
          ...updatedMessages,
          {
            role: "assistant",
            content: formatResponseText(response),
            thinking: deepseekConfig.showThinking ? formatThinkingText(displayedThinking) : undefined,
          },
        ]

        setMessages(finalMessages)

        // 如果是在历史会话中，更新历史会话
        if (conversationId) {
          saveConversation(finalMessages, true)
        } else {
          // 创建新的历史会话
          const newChatId = saveConversation(finalMessages)
          if (newChatId) {
            setConversationId(newChatId)
          }
        }

        // 完全重置所有状态
        setIsTyping(false)
        setIsInputDisabled(false)
        setDisplayedResponse("")
        setDisplayedThinking("")
        setIsProcessingMessage(false)
        setIsThinking(false)
        setShowThinking(false)
        setThinkingComplete(false)

        // 更新消息处理状态
        messageProcessingRef.current = {
          userMessage: "",
          isProcessing: false,
          abortController: null,
        }

        // 如果语音播放开启，则朗读回复
        if (voiceEnabled) {
          speakText(formatResponseText(response))
        }
      }
    } catch (error) {
      console.error("Error fetching AI response:", error)

      // 添加错误消息
      const errorMessages = [
        ...updatedMessages,
        {
          role: "assistant",
          content: "抱歉，我遇到了一些问题，请稍后再试。",
        },
      ]

      setMessages(errorMessages)

      // 如果是在历史会话中，更新历史会话
      if (conversationId) {
        saveConversation(errorMessages, true)
      }

      // 完全重置所有状态
      setIsTyping(false)
      setIsInputDisabled(false)
      setIsThinking(false)
      setIsProcessingMessage(false)
      setShowThinking(false)
      setThinkingComplete(false)

      // 更新消息处理状态
      messageProcessingRef.current = {
        userMessage: "",
        isProcessing: false,
        abortController: null,
      }
    }
  }

  // 在fetchAIResponse函数前添加buildContextMessages函数
  // 构建包含上下文的消息数组
  // const buildContextMessages = (currentMessage: string, contextCount: number): { role: string; content: string }[] => {
  //   // 创建消息数组，从最新的开始
  //   const contextMessages: { role: string; content: string }[] = [{ role: "user", content: currentMessage }]

  //   // 如果没有历史消息或上下文计数为0，则只返回当前消息
  //   if (messages.length === 0 || contextCount <= 0) {
  //     return contextMessages
  //   }

  //   // 计算要包含的历史消息数量（每轮对话包含用户和助手两条消息）
  //   // 所以实际消息数量是contextCount * 2
  //   const maxHistoryMessages = contextCount * 2

  //   // 从最近的消息开始，最多添加maxHistoryMessages条历史消息
  //   const historyMessages = [...messages].reverse().slice(0, maxHistoryMessages).reverse()

  //   // 将历史消息添加到contextMessages数组前面
  //   return [
  //     ...historyMessages.map((msg) => ({
  //       role: msg.role,
  //       content: msg.content,
  //     })),
  //     ...contextMessages,
  //   ]
  // }

  // 修改fetchAIResponse函数，实现多轮对话功能
  // 在函数开始处，添加历史消息处理逻辑
  const fetchAIResponse = async (message: string, config: typeof deepseekConfig) => {
    try {
      // 检查API密钥是否存在
      if (!config.apiKey) {
        throw new Error("API密钥未设置，请在管理员页面配置API密钥")
      }

      // 构建请求体 - 修正模型名称
      // DeepSeek API实际模型名称与我们的自定义名称映射
      let actualModel = "deepseek-chat"
      let extraParams = {}

      if (config.model === "deepseek-r1") {
        // 如果选择了R1模型，使用deepseek-reasoner并启用思考过程
        actualModel = "deepseek-reasoner"
        if (config.showThinking) {
          extraParams = { return_reasoning: true }
          setShowThinking(true)
        }
      } else if (config.model === "deepseek-v3") {
        actualModel = "deepseek-chat-v2"
      }

      console.log("API请求模型:", actualModel, "额外参数:", extraParams)

      // 先显示思考中...
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // 创建AbortController用于取消请求
      const abortController = messageProcessingRef.current.abortController

      // 构建多轮对话的消息历史
      // 根据config.contextCount决定携带多少轮对话历史
      const historyMessages = []

      // 如果有历史消息且contextCount > 0，则添加历史消息
      if (messages.length > 0 && config.contextCount > 0) {
        // 计算要包含的历史消息数量（每轮对话包含用户和助手两条消息）
        const historyCount = Math.min(config.contextCount * 2, messages.length)
        // 从最近的消息开始，向前获取历史消息
        const startIndex = Math.max(0, messages.length - historyCount)

        for (let i = startIndex; i < messages.length; i++) {
          historyMessages.push({
            role: messages[i].role,
            content: messages[i].content,
          })
        }
      }

      // 添加当前用户消息
      historyMessages.push({ role: "user", content: message })

      // 修改fetchAIResponse函数，添加JSON模式支持
      // 在构建请求体部分添加jsonMode参数

      // 发送请求到DeepSeek API，包含历史消息
      const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          model: actualModel,
          messages: historyMessages, // 使用包含历史的消息数组
          temperature: config.temperature,
          max_tokens: config.maxTokens,
          stream: config.streamOutput,
          // 只有在非reasoner模型且启用JSON模式时才添加response_format
          ...(config.model !== "deepseek-r1" && config.jsonMode ? { response_format: { type: "json_object" } } : {}),
          ...extraParams,
        }),
        signal: abortController?.signal,
      })

      // 其余代码保持不变...

      // 检查响应状态
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`API错误: ${errorData.error?.message || response.statusText}`)
      }

      // 处理流式响应
      if (config.streamOutput && response.body) {
        const reader = response.body.getReader()
        const decoder = new TextDecoder("utf-8")
        let fullText = ""
        let fullThinking = ""
        const buffer = ""
        const outputInterval = 30 // 每秒输出30个字符
        const intervalMs = 1000 / outputInterval
        const lastOutputTime = 0

        try {
          // 处理流式响应的主循环
          const processStream = async () => {
            while (true) {
              // 检查是否被中止
              if (!messageProcessingRef.current.isProcessing) {
                break
              }

              const { done, value } = await reader.read()
              if (done) break

              // 解码二进制数据
              const chunk = decoder.decode(value, { stream: true })

              // 解析SSE格式数据
              const lines = chunk.split("\n")
              for (const line of lines) {
                if (line.startsWith("data:")) {
                  try {
                    const data = JSON.parse(line.substring(5))

                    // 处理思考过程
                    if (data.choices && data.choices[0]?.delta?.reasoning_content) {
                      // 如果是第一个字符，隐藏思考中状态
                      if (!hasStartedOutput) {
                        setIsThinking(false)
                        setHasStartedOutput(true)
                      }

                      const thinkingContent = data.choices[0].delta.reasoning_content
                      fullThinking += thinkingContent

                      // 将思考内容添加到队列
                      outputQueue.current.push({
                        type: "thinking",
                        text: thinkingContent,
                      })
                    }

                    // 处理正常内容
                    if (data.choices && data.choices[0]?.delta?.content) {
                      // 如果是第一个字符，隐藏思考中状态
                      if (!hasStartedOutput) {
                        setIsThinking(false)
                        setHasStartedOutput(true)
                      }

                      const content = data.choices[0].delta.content
                      fullText += content

                      // 将响应内容添加到队列
                      outputQueue.current.push({
                        type: "response",
                        text: content,
                      })

                      // 如果思考过程已完成但还未显示分隔线，显示分隔线
                      if (fullThinking && !thinkingComplete && fullText) {
                        setThinkingComplete(true)
                      }
                    }

                    // 处理输出队列
                    processOutputQueue()
                  } catch (e) {
                    // 忽略解析错误
                  }
                }
              }
            }
          }

          await processStream()
        } catch (error) {
          // 检查是否是因为中止而导致的错误
          if (error.name === "AbortError") {
            console.log("Fetch aborted")
          } else {
            console.error("Error reading stream:", error)
          }
        } finally {
          // 完成流式响应后，添加完整消息
          if (fullText) {
            // 添加到消息列表
            const finalMessages = [
              ...messages,
              { role: "user", content: message },
              {
                role: "assistant",
                content: formatResponseText(fullText),
                thinking: fullThinking ? formatThinkingText(fullThinking) : undefined,
              },
            ]

            setMessages(finalMessages)

            // 如果是在历史会话中，更新历史会话
            if (conversationId) {
              saveConversation(finalMessages, true)
            } else {
              // 创建新的历史会话
              const newChatId = saveConversation(finalMessages)
              if (newChatId) {
                setConversationId(newChatId)
              }
            }

            setDisplayedResponse("")
            setDisplayedThinking("")

            // 如果语音播放开启，则朗读回复
            if (voiceEnabled) {
              speakText(formatResponseText(fullText)) // 只朗读最终答案，不朗读思考过程
            }
          }

          // 完全重置所有状态
          setIsTyping(false)
          setIsInputDisabled(false)
          setIsProcessingMessage(false)
          setIsThinking(false) // 确保思考状态被重置
          setShowThinking(false) // 确保思考显示被重置
          setThinkingComplete(false)
          setHasStartedOutput(false)

          // 更新消息处理状态
          messageProcessingRef.current = {
            userMessage: "",
            isProcessing: false,
            abortController: null,
          }
        }
      } else {
        // 处理非流式响应
        const data = await response.json()
        let content = data.choices[0].message.content
        let thinking = ""

        // 检查是否有思考过程
        if (data.choices[0].message.reasoning_content) {
          thinking = data.choices[0].message.reasoning_content
          thinking = formatThinkingText(thinking)
        }

        content = formatResponseText(content)

        // 添加到消息列表
        const finalMessages = [
          ...messages,
          { role: "user", content: message },
          {
            role: "assistant",
            content: content,
            thinking: thinking || undefined,
          },
        ]

        setMessages(finalMessages)

        // 如果是在历史会话中，更新历史会话
        if (conversationId) {
          saveConversation(finalMessages, true)
        } else {
          // 创建新的历史会话
          const newChatId = saveConversation(finalMessages)
          if (newChatId) {
            setConversationId(newChatId)
          }
        }

        setIsTyping(false)
        setIsInputDisabled(false)
        setIsProcessingMessage(false)

        // 更新消息处理状态
        messageProcessingRef.current = {
          userMessage: "",
          isProcessing: false,
          abortController: null,
        }

        // 如果语音播放开启，则朗读回复
        if (voiceEnabled) {
          speakText(content) // 只朗读最终答案，不朗读思考过程
        }
      }
    } catch (error) {
      console.error("Error in fetchAIResponse:", error)

      // 添加错误消息
      const errorMessages = [
        ...messages,
        { role: "user", content: message },
        {
          role: "assistant",
          content: `调用API时出错: ${error instanceof Error ? error.message : "未知错误"}。请检查API配置或网络连接。`,
        },
      ]

      setMessages(errorMessages)

      // 如果是在历史会话中，更新历史会话
      if (conversationId) {
        saveConversation(errorMessages, true)
      }

      setIsTyping(false)
      setIsInputDisabled(false)
      setIsThinking(false)
      setIsProcessingMessage(false)

      // 更新消息处理状态
      messageProcessingRef.current = {
        userMessage: "",
        isProcessing: false,
        abortController: null,
      }
    }
  }

  // 语音合成功能
  // 修改语音合成功能，添加结束事件处理
  const speakText = (text: string) => {
    if ("speechSynthesis" in window) {
      // 停止任何正在进行的语音
      window.speechSynthesis.cancel()

      const utterance = new SpeechSynthesisUtterance(text)

      // 获取所有可用的语音
      const voices = window.speechSynthesis.getVoices()

      // 尝试找到中文女声
      const chineseVoice = voices.find((voice) => voice.lang.includes("zh") && voice.name.includes("Female"))

      if (chineseVoice) {
        utterance.voice = chineseVoice
      }

      // 设置语音参数
      utterance.pitch = 1.2 // 稍高的音调
      utterance.rate = 1.0 // 正常速度
      utterance.volume = 1.0 // 最大音量

      // 添加结束事件处理
      utterance.onend = () => {
        // 找到所有语音按钮并重置为播放状态
        document.querySelectorAll('.voice-play-btn[data-action="stop"]').forEach((button) => {
          button.setAttribute("data-action", "play")
          button.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M11 5L6 9H2V15H6L11 19V5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M15.54 8.46C16.4774 9.39764 17.004 10.6692 17.004 11.995C17.004 13.3208 16.4774 14.5924 15.54 15.53" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          `
        })
      }

      window.speechSynthesis.speak(utterance)
    }
  }

  // 修改handleVoiceInput函数
  const handleVoiceInput = () => {
    setIsVoiceModalOpen(true)
    // 不再设置isRecordingInPlace为true，取消对话页面上的音波动画
  }

  // 修改handleStopRecording函数，不再需要
  // 删除handleStopRecording函数

  // 修改handleVoiceTranscriptionComplete函数，使其直接发送消息而不是填充输入框
  // 找到handleVoiceTranscriptionComplete函数并替换为：

  // 处理语音转写完成
  const handleVoiceTranscriptionComplete = (text: string) => {
    if (text.trim()) {
      // 直接发送消息，而不是填充输入框
      const userMessage = text.trim()

      // 添加用户消息
      const updatedMessages = [...messages, { role: "user", content: userMessage }]
      setMessages(updatedMessages)

      // 重置滚动状态，确保新消息可见
      isScrolling.current = false

      // 重置所有状态
      setIsTyping(true)
      setIsInputDisabled(true)
      setDisplayedResponse("")
      setDisplayedThinking("")
      setShowThinking(false)
      setThinkingComplete(false)
      setIsThinking(true)
      setHasStartedOutput(false)
      setOutputLineCount(0)
      setShouldScroll(true) // 强制启用滚动
      lastOutputLength.current = 0
      setIsProcessingMessage(true)

      // 清空输出缓冲区和队列
      outputBuffer.current = ""
      outputQueue.current = []
      isProcessingOutput.current = false

      // 更新消息处理状态
      messageProcessingRef.current = {
        userMessage,
        isProcessing: true,
        abortController: new AbortController(),
      }

      // 如果不是第一次对话，直接滚动到底部
      if (messages.length > 0) {
        setTimeout(() => {
          scrollToBottom(200)
        }, 50)
      }

      // 处理消息发送逻辑
      try {
        // 如果是在历史会话中，更新历史会话
        if (conversationId) {
          saveConversation(updatedMessages, true)
        }

        // 检查是否有API配置
        if (deepseekConfig.connected && deepseekConfig.apiKey) {
          // 使用DeepSeek API
          fetchAIResponse(userMessage, deepseekConfig)
        } else {
          // 使用模拟响应
          // 这里是现有的模拟响应逻辑，保持不变
          // ...
        }
      } catch (error) {
        console.error("Error processing voice message:", error)
        // 错误处理逻辑
      }
    }

    // 关闭语音转写弹窗
    setIsVoiceModalOpen(false)
    setIsRecordingInPlace(false)
  }

  // 处理键盘事件
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // 保存当前对话并开始新对话
  const saveAndStartNewChat = () => {
    // 完全重置所有状态
    setIsThinking(false)
    setIsTyping(false)
    setShowThinking(false)
    setThinkingComplete(false)
    setHasStartedOutput(false)
    setDisplayedResponse("")
    setDisplayedThinking("")
    setIsProcessingMessage(false)
    setIsInputDisabled(false)
    setShouldScroll(false)

    // 重置消息处理状态
    messageProcessingRef.current = {
      userMessage: "",
      isProcessing: false,
      abortController: null,
    }

    if (messages.length > 0) {
      // 如果有实际对话内容
      if (conversationId) {
        // 如果是在历史会话中，保存更新
        saveConversation(messages, true)
      } else {
        // 创建新的历史会话
        saveConversation(messages)
      }

      // 清空当前对话
      setMessages([])
      setConversationId(null)
    }
  }

  // 思考中动画
  const ThinkingAnimation = () => (
    <div className="flex justify-start w-full">
      <div className="w-full rounded-2xl rounded-tl-none px-4 py-3 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white">
        <div className="flex items-center">
          <span className="text-black/70 dark:text-white/70 mr-1">正在思考</span>
          <span className="inline-flex">
            <span className="animate-bounce mx-[1px] delay-0">.</span>
            <span className="animate-bounce mx-[1px] delay-150">.</span>
            <span className="animate-bounce mx-[1px] delay-300">.</span>
          </span>
        </div>
      </div>
    </div>
  )

  // 修改renderMessageContent函数，优化排版并移除特殊符号
  // 在现有函数中找到以下部分并替换：

  // 修改renderMessageContent函数，确保移除所有特殊符号
  const renderMessageContent = (content: string, isThinking = false, isComplete = true) => {
    if (isThinking) {
      // 处理思考部分内容，移除特殊符号
      return content
        .replace(/\*\*/g, "") // 移除所有**符号
        .replace(/\*/g, "") // 移除所有*符号
        .replace(/###/g, "") // 移除所有###符号
        .replace(/##/g, "") // 移除所有##符号
        .replace(/#/g, "") // 移除所有#符号
        .replace(/—{2,}/g, "") // 移除所有——符号
        .replace(/—/g, "") // 移除所有—符号
        .replace(/-{2,}/g, "") // 移除所有--符号
        .replace(/-/g, "") // 移除所有-符号
    }

    // 创建一个稳定的容器结构，防止内容跳动
    const createStableContainer = (html: string, type = "normal") => {
      const heightClass = type === "heading" ? "min-h-[32px]" : "min-h-[24px]"
      return `<div class="content-block ${heightClass} mb-2 stable-content" style="transform: translateZ(0); will-change: auto;">${html}</div>`
    }

    // 生成唯一ID
    const generateId = (prefix: string, index: number) => `${prefix}_${Date.now()}_${index}`

    // 将内容分割成段落，单独处理每个段落
    const paragraphs = content.split("\n\n").filter((p) => p.trim())
    let processedContent = ""
    let sectionIndex = 0

    // 处理每个段落
    for (let i = 0; i < paragraphs.length; i++) {
      const paragraph = paragraphs[i]

      // 处理大标题 (# 标题) - 移除#符号，保留标题内容
      if (/^#\s+(.+)$/.test(paragraph)) {
        const titleText = paragraph.replace(/^#\s+/, "")
        const sectionId = generateId("section", sectionIndex++)
        const contentId = `content_${sectionId}`

        // 创建标题背景块，添加折叠/展开按钮
        processedContent += `
          <div class="bg-black/5 dark:bg-white/5 rounded-lg p-3 my-3 flex justify-between items-center title-block stable-content" style="position: relative; z-index: 1; opacity: 1 !important; transform: none !important; transition: none !important;">
            <h1 class="text-center font-bold text-[${fontSize + 2}px] stable-heading">${titleText}</h1>
            <button class="collapse-btn w-8 h-8 flex items-center justify-center rounded-full text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white transition-colors" data-section="${contentId}" data-action="collapse">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="transform rotate-180">
                <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
          <div id="${contentId}" class="section-content">
        `

        // 在标题后添加一条超细的灰色细线，确保永久显示
        processedContent += `<div class="w-full h-[1px] bg-black/10 dark:bg-white/10 my-2 stable-separator"></div>`
        continue
      }

      // 处理二级标题 (## 标题) - 移除##符号，保留标题内容
      if (/^##\s+(.+)$/.test(paragraph)) {
        const titleText = paragraph.replace(/^##\s+/, "")
        const sectionId = generateId("subsection", sectionIndex++)
        const contentId = `content_${sectionId}`

        // 创建标题背景块，添加折叠/展开按钮
        processedContent += `
          <div class="bg-black/5 dark:bg-white/5 rounded-lg p-2 my-2 flex justify-between items-center title-block stable-content" style="position: relative; z-index: 1; opacity: 1 !important; transform: none !important; transition: none !important;">
            <h2 class="font-bold text-[${fontSize + 1}px] stable-heading">${titleText}</h2>
            <button class="collapse-btn w-7 h-7 flex items-center justify-center rounded-full text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white transition-colors" data-section="${contentId}" data-action="collapse">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="transform rotate-180">
                <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
          <div id="${contentId}" class="section-content">
        `

        // 在二级标题后添加一条超细的灰色细线，确保永久显示
        processedContent += `<div class="w-full h-[0.5px] bg-black/10 dark:bg-white/10 my-1 stable-separator"></div>`
        continue
      }

      // 处理三级标题 (### 标题) - 移除###符号，保留标题内容
      if (/^###\s+(.+)$/.test(paragraph)) {
        const titleText = paragraph.replace(/^###\s+/, "")
        const sectionId = generateId("subsubsection", sectionIndex++)
        const contentId = `content_${sectionId}`

        // 创建标题背景块，添加折叠/展开按钮
        processedContent += `
          <div class="bg-black/5 dark:bg-white/5 rounded-lg p-2 my-2 flex justify-between items-center title-block stable-content" style="position: relative; z-index: 1; opacity: 1 !important; transform: none !important; transition: none !important;">
            <h3 class="font-bold text-[${fontSize}px] stable-heading">${titleText}</h3>
            <button class="collapse-btn w-6 h-6 flex items-center justify-center rounded-full text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white transition-colors" data-section="${contentId}" data-action="collapse">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="transform rotate-180">
                <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
          <div id="${contentId}" class="section-content">
        `
        continue
      }

      // 处理背景框标记 (<背景框>内容</背景框>)
      if (/<背景框>(.*?)<\/背景框>/s.test(paragraph)) {
        // 移除内容中的特殊符号
        const cleanContent = paragraph
          .replace(/<背景框>(.*?)<\/背景框>/s, "$1")
          .replace(/\*\*/g, "")
          .replace(/\*/g, "")
          .replace(/###/g, "")
          .replace(/##/g, "")
          .replace(/#/g, "")
          .replace(/—{2,}/g, "")
          .replace(/—/g, "")
          .replace(/-{2,}/g, "")
          .replace(/-/g, "")

        processedContent += createStableContainer(
          `<div class="bg-black/5 dark:bg-white/5 p-3 rounded-md my-3 stable-box relative border-l-2 border-black/20 dark:border-white/20">
      ${cleanContent}
      ${
        isComplete && voiceEnabled
          ? `<button class="voice-play-btn absolute bottom-1 right-1 w-6 h-6 flex items-center justify-center rounded-full text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white transition-colors" data-action="play">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11 5L6 9H2V15H6L11 19V5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M15.54 8.46C16.4774 9.39764 17.004 10.6692 17.004 11.995C17.004 13.3208 16.4774 14.5924 15.54 15.53" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>`
          : ""
      }
    </div>`,
        )
        continue
      }

      // 处理大标题数字 (一、二、三...)
      if (/^(一|二|三|四|五|六|七|八|九|十)、\s*(.+)$/.test(paragraph)) {
        // 移除内容中的特殊符号
        const match = paragraph.match(/^(一|二|三|四|五|六|七|八|九|十)、\s*(.+)$/)
        if (match) {
          const [_, num, text] = match
          const cleanText = text
            .replace(/\*\*/g, "")
            .replace(/\*/g, "")
            .replace(/###/g, "")
            .replace(/##/g, "")
            .replace(/#/g, "")
            .replace(/—{2,}/g, "")
            .replace(/—/g, "")
            .replace(/-{2,}/g, "")
            .replace(/-/g, "")

          const sectionId = generateId("numbersection", sectionIndex++)
          const contentId = `content_${sectionId}`

          // 创建标题背景块，添加折叠/展开按钮
          processedContent += `
          <div class="bg-black/5 dark:bg-white/5 rounded-lg p-2 my-2 flex justify-between items-center title-block stable-content" style="position: relative; z-index: 1; opacity: 1 !important; transform: none !important; transition: none !important;">
            <h2 class="font-bold text-[${fontSize + 1}px] stable-heading">${num}、${cleanText}</h2>
            <button class="collapse-btn w-7 h-7 flex items-center justify-center rounded-full text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white transition-colors" data-section="${contentId}" data-action="collapse">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="transform rotate-180">
                <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
          <div id="${contentId}" class="section-content">
        `

          // 在大标题数字后添加一条超细的灰色细线，确保永久显示
          processedContent += `<div class="w-full h-[0.5px] bg-black/10 dark:bg-white/10 my-1 stable-separator"></div>`
          continue
        }
      }

      // 处理小标题数字 (1. 2. 3. ...)
      if (/^(\d+)\.\s+(.+)$/.test(paragraph)) {
        // 移除内容中的特殊符号
        const match = paragraph.match(/^(\d+)\.\s+(.+)$/)
        if (match) {
          const [_, num, text] = match
          const cleanText = text
            .replace(/\*\*/g, "")
            .replace(/\*/g, "")
            .replace(/###/g, "")
            .replace(/##/g, "")
            .replace(/#/g, "")
            .replace(/—{2,}/g, "")
            .replace(/—/g, "")
            .replace(/-{2,}/g, "")
            .replace(/-/g, "")

          processedContent += createStableContainer(
            `<h3 class="font-bold text-[${fontSize}px] my-2 stable-heading">${num}. ${cleanText}</h3>`,
          )
          continue
        }
      }

      // 处理步骤数字 (① ② ③ ...)
      if (/[①②③④⑤⑥⑦⑧⑨⑩]\s+(.+)/.test(paragraph)) {
        // 移除内容中的特殊符号
        const cleanContent = paragraph
          .replace(/\*\*/g, "")
          .replace(/\*/g, "")
          .replace(/###/g, "")
          .replace(/##/g, "")
          .replace(/#/g, "")
          .replace(/—{2,}/g, "")
          .replace(/—/g, "")
          .replace(/-{2,}/g, "")
          .replace(/-/g, "")

        processedContent += createStableContainer(`<div class="ml-2 stable-step">${cleanContent}</div>`)
        continue
      }

      // 处理普通段落
      const lines = paragraph.split("\n")
      let lineContent = ""

      for (const line of lines) {
        if (line.trim()) {
          // 移除行内的特殊符号
          const cleanLine = line
            .replace(/\*\*/g, "")
            .replace(/\*/g, "")
            .replace(/###/g, "")
            .replace(/##/g, "")
            .replace(/#/g, "")
            .replace(/—{2,}/g, "")
            .replace(/—/g, "")
            .replace(/-{2,}/g, "")
            .replace(/-/g, "")

          lineContent += `<div class="line-content stable-line">${cleanLine}</div>`
        }
      }

      if (lineContent) {
        processedContent += createStableContainer(lineContent)
        // 在普通段落后添加一条超细的灰色细线，增强分段效果
        if (i < paragraphs.length - 1) {
          processedContent += `<div class="w-full h-[0.5px] bg-black/5 dark:bg-white/5 my-1 paragraph-separator"></div>`
        }
      }

      // 如果是最后一个段落，关闭所有打开的section-content div
      if (i === paragraphs.length - 1) {
        processedContent += `</div>`.repeat(sectionIndex)
      }
    }

    return processedContent
  }

  // 添加事件处理函数，处理折叠/展开按钮点击
  useEffect(() => {
    const handleCollapseButtonClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const button = target.closest(".collapse-btn")

      if (button) {
        e.preventDefault()
        e.stopPropagation()

        const sectionId = button.getAttribute("data-section")
        const action = button.getAttribute("data-action")
        const sectionContent = document.getElementById(sectionId || "")

        if (sectionContent) {
          if (action === "collapse") {
            // 折叠内容
            sectionContent.style.display = "none"
            button.setAttribute("data-action", "expand")
            // 更新图标
            button.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          `
          } else {
            // 展开内容
            sectionContent.style.display = "block"
            button.setAttribute("data-action", "collapse")
            // 更新图标
            button.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="transform rotate-180">
              <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          `
          }
        }
      }
    }

    // 添加事件监听器
    document.addEventListener("click", handleCollapseButtonClick)

    // 清理函数
    return () => {
      document.removeEventListener("click", handleCollapseButtonClick)
    }
  }, [])

  // 修改消息渲染部分，调整思考部分和最终答案部分之间的分割线样式
  // 在 return 部分的 messages.map 中修改
  // 添加内容更新时的滚动检查
  useEffect(() => {
    // 当内容更新时检查是否需要滚动
    if (displayedResponse || displayedThinking) {
      checkIfShouldScroll()
    }
  }, [displayedResponse, displayedThinking, checkIfShouldScroll])

  // 添加滚动到顶部函数，确保用户输入内容始终在顶部可见
  const scrollToTop = () => {
    if (!messageContainerRef.current) return

    const container = messageContainerRef.current
    container.scrollTop = 0

    // 使用动画滚动到顶部
    container.scrollTo({
      top: 0,
      behavior: "smooth",
    })
  }

  // 2 & 3 & 4. 调整输入框位置、字体大小和按钮位置
  // 修改输入区域的样式
  // 修改消息渲染部分，添加语音播报按钮和事件处理
  // 在return部分的messages.map中修改
  // 添加语音播放按钮的事件处理
  // 在useEffect中添加事件委托处理语音播放按钮点击
  useEffect(() => {
    const handleVoiceButtonClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const button = target.closest(".voice-play-btn")

      if (button) {
        e.preventDefault()
        e.stopPropagation()

        const action = button.getAttribute("data-action")
        const content = button.closest(".stable-box")?.textContent || ""

        if (action === "play") {
          // 开始播放
          speakText(content)
          button.setAttribute("data-action", "stop")

          // 更新图标为停止图标
          button.innerHTML = `
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="6" y="5" width="4" height="14" rx="1" stroke="currentColor" strokeWidth="1.5" />
            <rect x="14" y="5" width="4" height="14" rx="1" stroke="currentColor" strokeWidth="1.5" />
          </svg>
        `
        } else {
          // 停止播放
          window.speechSynthesis.cancel()
          button.setAttribute("data-action", "play")

          // 更新图标为播放图标
          button.innerHTML = `
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11 5L6 9H2V15H6L11 19V5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M15.54 8.46C16.4774 9.39764 17.004 10.6692 17.004 11.995C17.004 13.3208 16.4774 14.5924 15.54 15.53" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        `
        }
      }
    }

    // 添加事件监听器
    document.addEventListener("click", handleVoiceButtonClick)

    // 清理函数
    return () => {
      document.removeEventListener("click", handleVoiceButtonClick)
    }
  }, [])

  return (
    <div className="flex flex-col h-[100dvh] bg-white dark:bg-black">
      {/* 顶部栏 - 保持不变 */}
      <header className="h-[60px] flex items-center justify-between px-6 fixed top-0 left-0 right-0 z-10">
        <div className="w-8 h-8"></div> {/* 空占位元素保持布局平衡 */}
        {voiceEnabled && (
          <button
            onClick={() => speakText(messages[messages.length - 1]?.content || "")}
            className="w-8 h-8 flex items-center justify-center rounded-full text-black dark:text-white opacity-0"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M11 5L6 9H2V15H6L11 19V5Z"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M15.54 8.46C16.4774 9.39764 17.004 10.6692 17.004 11.995C17.004 13.3208 16.4774 14.5924 15.54 15.53"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M19.07 5.93C20.9447 7.80528 21.9979 10.3447 21.9979 13C21.9979 15.6553 20.9447 18.1947 19.07 20.07"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        )}
      </header>

      {/* 消息区域 - 保持不变 */}
      <div ref={messageContainerRef} className="flex-1 overflow-y-auto px-4 py-6 space-y-6 mt-[60px] mb-[130px]">
        {/* 修改用户消息背景块的样式，降低高度20%并确保内容垂直居中 */}
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"} w-full`}>
            <div
              className={`${
                message.role === "user"
                  ? "bg-black text-white dark:bg-white dark:text-black rounded-tr-none max-w-[80%] flex items-center py-2" // 降低高度并添加垂直居中
                  : "bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white rounded-tl-none w-full relative"
              } rounded-2xl px-4 py-3`}
            >
              {message.thinking && (
                <>
                  <div className="flex mb-3">
                    <div className="thinking-separator mr-3 min-h-full"></div>
                    <p
                      className="leading-relaxed text-justify whitespace-pre-wrap text-black/60 dark:text-white/60 flex-1"
                      style={{ fontSize: `${Math.max(fontSize - 2, 12)}px` }}
                      dangerouslySetInnerHTML={{
                        __html: message.thinking
                          .replace(/\*\*/g, "") // 移除所有**符号
                          .replace(/\*/g, "") // 移除所有*符号
                          .replace(/###/g, "") // 移除所有###符号
                          .replace(/##/g, "") // 移除所有##符号
                          .replace(/#/g, "") // 移除所有#符号
                          .replace(/—{2,}/g, "") // 移除所有——符号
                          .replace(/—/g, ""), // 移除所有—符号
                      }}
                    />
                  </div>
                  <hr className="border-t-2 border-black/10 dark:border-white/10 my-3 stable-separator" />
                </>
              )}
              <div
                className="leading-relaxed text-justify"
                style={{ fontSize: `${fontSize}px` }}
                dangerouslySetInnerHTML={{
                  __html: renderMessageContent(message.content, false, true),
                }}
              />

              {/* 移除这里的语音播放按钮，因为已经在背景框中添加了 */}
            </div>
          </div>
        ))}

        {isThinking && <ThinkingAnimation />}

        {isTyping && !isThinking && (
          <div
            className="flex justify-start w-full"
            ref={outputContainerRef}
            style={{
              minHeight: displayedThinking || displayedResponse ? "100px" : "auto",
              position: "relative",
              transform: "translateZ(0)",
              willChange: "auto",
            }}
          >
            <div className="w-full rounded-2xl rounded-tl-none px-4 py-3 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white overflow-hidden message-container">
              {showThinking && displayedThinking && (
                <div className="mb-3 thinking-container" ref={thinkingContainerRef}>
                  <div className="flex">
                    <div className="thinking-separator mr-3 min-h-full"></div>
                    <p
                      className="leading-relaxed text-justify whitespace-pre-wrap text-black/60 dark:text-white/60 flex-1"
                      style={{ fontSize: `${Math.max(fontSize - 2, 12)}px` }}
                    >
                      {displayedThinking}
                    </p>
                  </div>

                  {thinkingComplete && (
                    <hr className="border-t-2 border-black/10 dark:border-white/10 my-3 stable-separator" />
                  )}
                </div>
              )}

              {displayedResponse ? (
                <div
                  className="leading-relaxed text-justify response-container overflow-hidden"
                  dangerouslySetInnerHTML={{
                    __html: renderMessageContent(displayedResponse, false, false),
                  }}
                  style={{ fontSize: `${fontSize}px` }}
                  ref={responseContainerRef}
                />
              ) : (
                !displayedThinking && (
                  <div className="flex space-x-1">
                    <div
                      className="w-2 h-2 rounded-full bg-black/40 dark:bg-white/40 animate-bounce"
                      style={{ animationDelay: "0ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-black/40 dark:bg-white/40 animate-bounce"
                      style={{ animationDelay: "150ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-black/40 dark:bg-white/40 animate-bounce"
                      style={{ animationDelay: "300ms" }}
                    ></div>
                  </div>
                )
              )}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 输入区域 - 修改位置和样式 */}
      <div className="px-4 pb-2 pt-3 bg-white dark:bg-black fixed bottom-0 left-0 right-0 z-10">
        <AnimatePresence>
          {isRecordingInPlace ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="relative mb-2 flex justify-between items-center w-full bg-[#F5F5F7] dark:bg-[#1A1A1A] rounded-full px-4 py-3"
            >
              <div className="flex-1">
                <VoiceWave isListening={true} transcript="" />
              </div>
              <button
                onClick={() => {}}
                className="ml-2 w-8 h-8 flex items-center justify-center rounded-full bg-red-500 text-white"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect
                    x="6"
                    y="6"
                    width="12"
                    height="12"
                    rx="1"
                    stroke="currentColor"
                    strokeWidth="2"
                    fill="currentColor"
                  />
                </svg>
              </button>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="relative mb-3"
            >
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                onFocus={() => inputRef.current?.classList.add("placeholder-transparent")}
                onBlur={() => {
                  if (!input) {
                    inputRef.current?.classList.remove("placeholder-transparent")
                  }
                }}
                placeholder="输入消息..."
                disabled={isInputDisabled}
                className="w-full min-h-[23px] max-h-[46px] px-5 pr-12 py-3 rounded-full border border-black/10 dark:border-white/10 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white text-[14px] resize-none focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white placeholder:text-black/40 dark:placeholder:text-white/40 disabled:opacity-70 flex items-center overflow-hidden placeholder-shown:leading-[23px] placeholder:leading-[23px] placeholder:flex placeholder:items-center"
                style={{ lineHeight: "1.5", verticalAlign: "middle", display: "flex", alignItems: "center" }}
              />
              <button
                onClick={input.trim() ? handleSendMessage : handleVoiceInput}
                disabled={isInputDisabled && !isRecording}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 w-8 h-8 flex items-center justify-center rounded-full bg-black dark:bg-white text-white dark:text-black disabled:opacity-50"
              >
                {input.trim() ? (
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="rotate-270" // 将发送按钮向左旋转90度
                  >
                    <path
                      d="M5 12H19"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M12 5L19 12L12 19"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M12 2V22"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M19 4V20"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M5 4V20"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                )}
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <NavBar onNewChat={saveAndStartNewChat} />
      </div>

      {/* 语音转写模态框 */}
      <VoiceTranscriptionModal
        isOpen={isVoiceModalOpen}
        onClose={() => {
          setIsVoiceModalOpen(false)
          setIsRecordingInPlace(false) // 关闭弹窗时也停止录音状态
        }}
        onSend={(text) => {
          setInput(text)
          setIsRecordingInPlace(false) // 发送文本时也停止录音状态
          setTimeout(() => handleSendMessage(), 100)
        }}
      />
    </div>
  )

  // 构建多轮对话的消息数组
  // const buildContextMessages = (currentMessage: string, contextCount: number) => {
  //   const contextMessages: { role: "user" | "assistant"; content: string }[] = []

  //   // 添加之前的消息
  //   for (let i = Math.max(0, messages.length - contextCount); i < messages.length; i++) {
  //     contextMessages.push({ role: messages[i].role, content: messages[i].content })
  //   }

  //   // 添加当前消息
  //   contextMessages.push({ role: "user", content: currentMessage })

  //   return contextMessages
  // }
}

// 模拟流式输出文本的函数
async function streamTextWithConstantRate(
  text: string,
  callback: (chunk: string) => void,
  charactersPerSecond: number,
) {
  const intervalMs = 1000 / charactersPerSecond
  let index = 0

  while (index < text.length) {
    const chunk = text.charAt(index)
    callback(chunk)
    index++
    await new Promise((resolve) => setTimeout(resolve, intervalMs))
  }
}

// 修改formatThinkingText函数，确保思考部分也移除特殊符号
function formatThinkingText(text: string) {
  // 将换行符替换为HTML换行符，并移除特殊符号
  const formattedText = text
    .replace(/\n/g, "<br />")
    .replace(/\*\*/g, "") // 移除所有**符号
    .replace(/\*/g, "") // 移除所有*符号
    .replace(/###/g, "") // 移除所有###符号
    .replace(/##/g, "") // 移除所有##符号
    .replace(/#/g, "") // 移除所有#符号
    .replace(/—{2,}/g, "") // 移除所有——符号
    .replace(/—/g, "") // 移除所有—符号

  return formattedText
}

