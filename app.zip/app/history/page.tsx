"use client"

import { useState, useEffect, useContext } from "react"
import { useRouter } from "next/navigation"
import { UserContext } from "@/context/user-context"

type ChatHistory = {
  id: string
  title: string
  date: string
  messages: { role: "user" | "assistant"; content: string }[]
}

export default function HistoryPage() {
  const router = useRouter()
  const { currentUser } = useContext(UserContext)
  const [chatHistory, setChatHistory] = useState<ChatHistory[]>([])
  // 2. 修改历史会话列表页删除按钮逻辑
  // 修改删除按钮的处理逻辑，使其向左推出两个按钮而不是显示模态框
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [showDeleteButtons, setShowDeleteButtons] = useState<string | null>(null)

  useEffect(() => {
    // 从本地存储加载聊天历史 - 使用用户ID作为前缀
    const userId = currentUser?.id || "guest"
    const storageKey = `${userId}_chatHistory`
    const storedHistory = localStorage.getItem(storageKey)
    if (storedHistory) {
      setChatHistory(JSON.parse(storedHistory))
    }
  }, [currentUser])

  // 查看特定对话
  const viewChat = (chatId: string) => {
    router.push(`/history/${chatId}`)
  }

  // 格式化日期
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // 处理删除
  const handleDelete = (id: string) => {
    const userId = currentUser?.id || "guest"
    const storageKey = `${userId}_chatHistory`
    const updatedHistory = chatHistory.filter((chat) => chat.id !== id)
    setChatHistory(updatedHistory)
    localStorage.setItem(storageKey, JSON.stringify(updatedHistory))
    setShowDeleteButtons(null)
  }

  // 二、历史会话列表页面
  // 1. 固定上方导航背景和元素，不随页面滚动
  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black">
      <header className="fixed-header h-[60px] flex items-center justify-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/chat")}
          className="absolute left-4 w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white">历史会话</h1>
      </header>

      <div className="fixed-header-content p-4">
        {chatHistory.length > 0 ? (
          <div className="space-y-3">
            {chatHistory.map((chat) => (
              <div
                key={chat.id}
                className="p-4 rounded-2xl bg-[#F5F5F7] dark:bg-[#1A1A1A] border border-black/[0.06] dark:border-white/[0.06] relative"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-[16px] font-[500] text-black dark:text-white">{chat.title}</h3>
                  <div className="flex items-center">
                    {showDeleteButtons === chat.id ? (
                      <div className="flex space-x-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDelete(chat.id)
                          }}
                          className="w-8 h-8 flex items-center justify-center text-white bg-red-500 rounded-full"
                        >
                          <svg
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M18 6L6 18M6 6l12 12"
                              stroke="currentColor"
                              strokeWidth="1.5"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            setShowDeleteButtons(null)
                          }}
                          className="w-8 h-8 flex items-center justify-center text-black dark:text-white bg-gray-200 dark:bg-gray-700 rounded-full"
                        >
                          <svg
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M19 12H5"
                              stroke="currentColor"
                              strokeWidth="1.5"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          setShowDeleteButtons(chat.id)
                        }}
                        className="w-6 h-6 flex items-center justify-center text-black/40 dark:text-white/40 hover:text-red-500 dark:hover:text-red-400"
                      >
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M3 6H5H21"
                            stroke="currentColor"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                          <path
                            d="M8 6V4C8 3.46957 8.21071 2.96086 8.58579 2.58579C8.96086 2.21071 9.46957 2 10 2H14C14.5304 2 15.0391 2.21071 15.4142 2.58579C15.7893 2.96086 16 3.46957 16 4V6M19 6V20C19 20.5304 18.7893 21.0391 18.4142 21.4142C18.0391 21.7893 17.5304 22 17 22H7C6.46957 22 5.96086 21.7893 5.58579 21.4142C5.21071 21.0391 5 20.5304 5 20V6H19Z"
                            stroke="currentColor"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </button>
                    )}
                  </div>
                </div>
                <div onClick={() => viewChat(chat.id)} className="cursor-pointer">
                  <p className="text-[14px] text-black/60 dark:text-white/60 line-clamp-2 mb-2">
                    {chat.messages[chat.messages.length - 1]?.content || ""}
                  </p>
                  {/* 将时间从左下角移到右下角显示 */}
                  <div className="flex justify-end">
                    <span className="text-[12px] text-black/40 dark:text-white/40">{formatDate(chat.date)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-[calc(100vh-180px)]">
            <svg
              width="64"
              height="64"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-black/20 dark:text-white/20 mb-4"
            >
              <path
                d="M12 8V12L15 15"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M3.05 11C3.27151 8.68261 4.51919 6.56428 6.48114 5.13446C8.44309 3.70464 10.9422 3.07123 13.3229 3.37156C15.7037 3.67188 17.8485 4.88393 19.2716 6.75731C20.6947 8.6307 21.2945 10.9887 20.9502 13.3173C20.6058 15.6459 19.3481 17.7479 17.4409 19.1464C15.5337 20.5449 13.1251 21.1359 10.7608 20.8089C8.39655 20.4819 6.27851 19.2599 4.8555 17.3899C3.43249 15.5198 2.82871 13.1716 3.05 11"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <p className="text-black/40 dark:text-white/40 text-[16px]">暂无历史会话</p>
          </div>
        )}
      </div>
    </div>
  )
}

