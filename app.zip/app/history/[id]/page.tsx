"use client"

import type React from "react"

import { useState, useEffect, useRef, useContext } from "react"
import { useRouter } from "next/navigation"
import { SettingsContext } from "@/context/settings-context"
import { UserContext } from "@/context/user-context"
import { ApiContext } from "@/context/api-context"
import { ScreenshotModal } from "@/components/screenshot-modal"
import { DownloadModal } from "@/components/download-modal"

export default function ChatHistoryDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { fontSize } = useContext(SettingsContext)
  const { voiceEnabled } = useContext(SettingsContext)
  const { currentUser } = useContext(UserContext)
  const { deepseekConfig } = useContext(ApiContext)

  const [messages, setMessages] = useState<{ role: "user" | "assistant"; content: string; thinking?: string }[]>([])
  const [title, setTitle] = useState("")
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [isThinking, setIsThinking] = useState(false)
  const [displayedResponse, setDisplayedResponse] = useState("")
  const [displayedThinking, setDisplayedThinking] = useState("")
  const [isInputDisabled, setIsInputDisabled] = useState(false)
  const [showThinking, setShowThinking] = useState(false)
  const [thinkingComplete, setThinkingComplete] = useState(false)
  const [hasStartedOutput, setHasStartedOutput] = useState(false)
  const [isProcessingMessage, setIsProcessingMessage] = useState(false)

  // 添加模态框状态
  const [isScreenshotModalOpen, setIsScreenshotModalOpen] = useState(false)
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [editTitle, setEditTitle] = useState("")
  const [editContent, setEditContent] = useState("")
  const [uploadedImages, setUploadedImages] = useState<{ [key: string]: string }>({})

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const messageContainerRef = useRef<HTMLDivElement>(null)
  const outputContainerRef = useRef<HTMLDivElement>(null)
  const thinkingContainerRef = useRef<HTMLDivElement>(null)
  const responseContainerRef = useRef<HTMLDivElement>(null)
  const outputObserver = useRef<ResizeObserver | null>(null)
  const isScrolling = useRef(false)
  const lastScrollPosition = useRef(0)
  const scrollTimer = useRef<NodeJS.Timeout | null>(null)
  const messageProcessingRef = useRef<{
    userMessage: string
    isProcessing: boolean
    abortController: AbortController | null
  }>({
    userMessage: "",
    isProcessing: false,
    abortController: null,
  })

  const fileInputRef = useRef<HTMLInputElement>(null)

  // 从本地存储加载特定聊天记录
  useEffect(() => {
    const userId = currentUser?.id || "guest"
    const storageKey = `${userId}_chatHistory`
    const storedHistory = localStorage.getItem(storageKey)
    if (storedHistory) {
      const history = JSON.parse(storedHistory)
      const currentChat = history.find((chat: any) => chat.id === params.id)
      if (currentChat) {
        setMessages(currentChat.messages)
        setTitle(currentChat.title)
      } else {
        router.push("/history")
      }
    }
  }, [params.id, router, currentUser])

  // 初始化ResizeObserver监听输出容器大小变化
  useEffect(() => {
    // 创建ResizeObserver实例
    outputObserver.current = new ResizeObserver((entries) => {
      // 如果用户正在手动滚动，不要自动滚动
      if (isScrolling.current) return

      for (const entry of entries) {
        if (
          entry.target === outputContainerRef.current ||
          entry.target === thinkingContainerRef.current ||
          entry.target === responseContainerRef.current
        ) {
          // 检查是否需要滚动
          checkIfShouldScroll()
        }
      }
    })

    // 监听输出容器
    if (outputContainerRef.current) {
      outputObserver.current.observe(outputContainerRef.current)
    }

    // 监听思考容器
    if (thinkingContainerRef.current) {
      outputObserver.current.observe(thinkingContainerRef.current)
    }

    // 监听响应容器
    if (responseContainerRef.current) {
      outputObserver.current.observe(responseContainerRef.current)
    }

    // 清理函数
    return () => {
      if (outputObserver.current) {
        outputObserver.current.disconnect()
      }
    }
  }, [])

  // 监听用户手动滚动
  useEffect(() => {
    const container = messageContainerRef.current
    if (!container) return

    const handleScroll = () => {
      // 记录当前滚动位置
      lastScrollPosition.current = container.scrollTop

      // 标记用户正在滚动
      isScrolling.current = true

      // 设置一个定时器，在滚动停止后重置标志
      if (scrollTimer.current) {
        clearTimeout(scrollTimer.current)
      }

      scrollTimer.current = setTimeout(() => {
        isScrolling.current = false

        // 检查是否需要滚动
        checkIfShouldScroll()
      }, 100)
    }

    container.addEventListener("scroll", handleScroll)

    return () => {
      container.removeEventListener("scroll", handleScroll)
      if (scrollTimer.current) {
        clearTimeout(scrollTimer.current)
      }
    }
  }, [])

  // 检查是否应该滚动
  const checkIfShouldScroll = () => {
    const container = messageContainerRef.current
    if (!container) return

    // 如果用户正在手动滚动，不要自动滚动
    if (isScrolling.current) return

    // 如果没有正在输出内容，不需要滚动
    if (!isTyping && !isThinking && !isProcessingMessage) return

    const { scrollHeight, clientHeight, scrollTop } = container
    const scrollBottom = scrollHeight - clientHeight
    const distanceFromBottom = scrollBottom - scrollTop

    // 增加滚动灵敏度，当距离底部小于150px时触发滚动
    if (distanceFromBottom < 180) {
      scrollToBottom(200)
    }
  }

  // 平滑滚动到底部
  const scrollToBottom = (duration = 300) => {
    if (!messageContainerRef.current) return

    const container = messageContainerRef.current
    const scrollHeight = container.scrollHeight
    const currentScrollTop = container.scrollTop
    const targetScrollTop = scrollHeight - container.clientHeight
    const scrollDistance = targetScrollTop - currentScrollTop

    // 如果已经在底部或接近底部，不需要滚动
    if (scrollDistance < 10) return

    // 清除之前的滚动计时器
    if (scrollTimer.current) {
      clearInterval(scrollTimer.current)
    }

    const startTime = performance.now()
    const startScrollTop = container.scrollTop

    const scrollStep = (timestamp: number) => {
      // 如果用户正在手动滚动，取消自动滚动
      if (isScrolling.current) return

      const elapsed = timestamp - startTime
      const progress = Math.min(elapsed / duration, 1)

      // 使用缓动函数使滚动更平滑
      const easeInOutQuad = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2)
      const easedProgress = easeInOutQuad(progress)

      container.scrollTop = startScrollTop + scrollDistance * easedProgress

      if (progress < 1) {
        requestAnimationFrame(scrollStep)
      }
    }

    requestAnimationFrame(scrollStep)
  }

  // 保存对话到历史记录
  const saveConversation = (msgs: typeof messages) => {
    if (msgs.length === 0) return

    const userId = currentUser?.id || "guest"
    const storageKey = `${userId}_chatHistory`
    const existingChats = JSON.parse(localStorage.getItem(storageKey) || "[]")
    const now = new Date().toISOString()

    // 更新现有对话
    const updatedChats = existingChats.map((chat: any) => {
      if (chat.id === params.id) {
        return {
          ...chat,
          messages: msgs,
          date: now, // 更新时间戳为最新
        }
      }
      return chat
    })

    localStorage.setItem(storageKey, JSON.stringify(updatedChats))
  }

  // 处理页面可见性变化
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === "hidden") {
        // 页面隐藏时，立即保存当前状态，无论是否正在处理消息
        if (messages.length > 0) {
          saveConversation(messages)
        }
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [messages])

  // 在fetchAIResponse函数前添加buildContextMessages函数
  // 构建包含上下文的消息数组
  const buildContextMessages = (currentMessage: string, contextCount: number): { role: string; content: string }[] => {
    // 创建消息数组，从最新的开始
    const contextMessages: { role: string; content: string }[] = [{ role: "user", content: currentMessage }]

    // 如果没有历史消息或上下文计数为0，则只返回当前消息
    if (messages.length === 0 || contextCount <= 0) {
      return contextMessages
    }

    // 计算要包含的历史消息数量（每轮对话包含用户和助手两条消息）
    // 所以实际消息数量是contextCount * 2
    const maxHistoryMessages = contextCount * 2

    // 从最近的消息开始，最多添加maxHistoryMessages条历史消息
    const historyMessages = [...messages].reverse().slice(0, maxHistoryMessages).reverse()

    // 将历史消息添加到contextMessages数组前面
    return [
      ...historyMessages.map((msg) => ({
        role: msg.role,
        content: msg.content,
      })),
      ...contextMessages,
    ]
  }

  // 处理发送消息
  const handleSendMessage = async () => {
    if (!input.trim() || isInputDisabled) return

    const userMessage = input.trim()

    // 添加用户消息
    const updatedMessages = [...messages, { role: "user", content: userMessage }]
    setMessages(updatedMessages)
    setInput("")
    setIsTyping(true)
    setIsInputDisabled(true)
    setDisplayedResponse("")
    setDisplayedThinking("")
    setShowThinking(false)
    setThinkingComplete(false)
    setIsThinking(true)
    setHasStartedOutput(false)
    setIsProcessingMessage(true)

    // 更新消息处理状态
    messageProcessingRef.current = {
      userMessage,
      isProcessing: true,
      abortController: new AbortController(),
    }

    try {
      // 保存更新的对话
      saveConversation(updatedMessages)

      // 检查是否有API配置
      if (deepseekConfig.connected && deepseekConfig.apiKey) {
        // 使用DeepSeek API
        await fetchAIResponse(userMessage, deepseekConfig)
      } else {
        // 使用模拟响应
        // 先显示思考中...
        await new Promise((resolve) => setTimeout(resolve, 1500))

        // 模拟思考过程
        if (deepseekConfig.showThinking) {
          setShowThinking(true)
          const thinkingText = `我需要分析用户的问题："${userMessage}"。

这个问题涉及到几个方面：
1. 用户的具体需求是什么
2. 我需要提供什么类型的信息
3. 如何组织回答使其清晰易懂

让我逐步思考这个问题...`

          // 模拟流式输出思考过程，确保平滑输出
          await streamTextWithConstantRate(
            thinkingText,
            (chunk) => {
              if (chunk === thinkingText.charAt(0)) {
                setIsThinking(false)
                setHasStartedOutput(true)
              }
              setDisplayedThinking((prev) => prev + chunk)
            },
            30,
          )

          setThinkingComplete(true)
          await new Promise((resolve) => setTimeout(resolve, 500))
        } else {
          setIsThinking(false)
          setHasStartedOutput(true)
        }

        // 模拟最终答案
        const response = `# 解决方案分析

针对您提出的问题，我提供以下全面分析和建议：

## 一、需求分析

在开始解决问题前，我们需要明确以下几点：

1. 目标定义 - 确定您希望达成的具体目标
2. 约束条件 - 了解时间、资源和技术限制
3. 优先级排序 - 区分核心需求和次要功能

## 二、解决方案

### 1. 技术路径选择

根据您的需求，我建议采用以下技术路径：

① 前端框架选择React或Vue，提供响应式用户体验
② 后端采用Node.js或Python，确保开发效率
③ 数据存储使用MongoDB，适合快速迭代

### 2. 实施步骤

具体实施可分为以下几个阶段：

<背景框>重要提示：请在每个阶段结束时进行全面测试，确保质量</背景框>

① 需求分析与规划（1-2周）
② 基础架构搭建（1周）
③ 核心功能开发（2-4周）
④ 测试与优化（1-2周）
⑤ 部署上线（3-5天）

## 三、预期成果

通过上述方案，您将获得：

1. 高质量产品 - 符合现代设计标准的应用
2. 可扩展架构 - 便于未来功能扩展
3. 优质用户体验 - 流畅的交互和响应速度

希望这个方案能够满足您的需求。如有任何疑问，请随时提出！`

        // 模拟流式输出最终答案，确保平滑输出
        await streamTextWithConstantRate(
          response,
          (chunk) => {
            setDisplayedResponse((prev) => prev + chunk)
          },
          30,
        )

        // 添加到消息列表
        const finalMessages = [
          ...updatedMessages,
          {
            role: "assistant",
            content: formatResponseText(response),
            thinking: deepseekConfig.showThinking ? formatThinkingText(displayedThinking) : undefined,
          },
        ]

        setMessages(finalMessages)

        // 保存更新的对话
        saveConversation(finalMessages)

        setIsTyping(false)
        setIsInputDisabled(false)
        setDisplayedResponse("")
        setDisplayedThinking("")
        setIsProcessingMessage(false)

        // 更新消息处理状态
        messageProcessingRef.current = {
          userMessage: "",
          isProcessing: false,
          abortController: null,
        }

        // 如果语音播放开启，则朗读回复
        if (voiceEnabled) {
          speakText(formatResponseText(response))
        }
      }
    } catch (error) {
      console.error("Error fetching AI response:", error)

      // 添加错误消息
      const errorMessages = [
        ...updatedMessages,
        {
          role: "assistant",
          content: "抱歉，我遇到了一些问题，请稍后再试。",
        },
      ]

      setMessages(errorMessages)

      // 保存更新的对话
      saveConversation(errorMessages)

      setIsTyping(false)
      setIsInputDisabled(false)
      setIsThinking(false)
      setIsProcessingMessage(false)

      // 更新消息处理状态
      messageProcessingRef.current = {
        userMessage: "",
        isProcessing: false,
        abortController: null,
      }
    }
  }

  // 以恒定速率流式输出文本，确保平滑显示
  const streamTextWithConstantRate = async (
    text: string,
    onChunk: (chunk: string) => void,
    charsPerSecond = 30,
  ): Promise<void> => {
    return new Promise((resolve) => {
      const totalChars = text.length
      const intervalMs = 1000 / charsPerSecond
      let charIndex = 0
      let buffer = ""
      const bufferSize = 40 // 增大缓冲区大小，从20增加到40

      // 处理缓冲区的函数
      const processBuffer = () => {
        if (buffer.length > 0) {
          onChunk(buffer)
          buffer = ""
        }
      }

      const interval = setInterval(() => {
        // 如果处理被中止，清除定时器并返回
        if (!messageProcessingRef.current.isProcessing) {
          clearInterval(interval)
          processBuffer() // 处理剩余的缓冲区
          resolve()
          return
        }

        if (charIndex >= totalChars) {
          clearInterval(interval)
          processBuffer() // 处理剩余的缓冲区
          resolve()
          return
        }

        // 将字符添加到缓冲区
        const currentChar = text.charAt(charIndex)
        buffer += currentChar
        charIndex++

        // 当缓冲区达到一定大小或者是最后一个字符时，处理缓冲区
        if (buffer.length >= bufferSize || charIndex >= totalChars) {
          processBuffer()
        }
      }, intervalMs)
    })
  }

  // 格式化思考过程文本，保持段落和换行
  const formatThinkingText = (text: string): string => {
    // 移除开头的"思考过程："文本
    let formattedText = text.replace(/^思考过程：\s*/i, "")

    // 确保段落之间有适当的换行
    formattedText = formattedText.replace(/\n{3,}/g, "\n\n")

    return formattedText
  }

  // 格式化最终答案文本，保持结构化输出
  const formatResponseText = (text: string): string => {
    // 移除开头的"最终答案："文本
    let formattedText = text.replace(/^最终答案：\s*/i, "")

    // 隐藏特殊符号但保持结构
    formattedText = formattedText.replace(/^\s*[*#-]+\s+/gm, "")
    formattedText = formattedText.replace(/\n\s*[-*#]{3,}\s*\n/g, "\n\n")

    // 移除**符号
    formattedText = formattedText.replace(/\*\*/g, "")

    // 确保段落之间有适当的换行
    formattedText = formattedText.replace(/\n{3,}/g, "\n\n")

    return formattedText
  }

  // 调用AI API获取响应
  const fetchAIResponse = async (message: string, config: typeof deepseekConfig) => {
    try {
      // 检查API密钥是否存在
      if (!config.apiKey) {
        throw new Error("API密钥未设置，请在管理员页面配置API密钥")
      }

      // 构建请求体 - 修正模型名称
      // DeepSeek API实际模型名称与我们的自定义名称映射
      let actualModel = "deepseek-chat"
      let extraParams = {}

      if (config.model === "deepseek-r1") {
        // 如果选择了R1模型，使用deepseek-reasoner并启用思考过程
        actualModel = "deepseek-reasoner"
        if (config.showThinking) {
          extraParams = { return_reasoning: true }
          setShowThinking(true)
        }
      } else if (config.model === "deepseek-v3") {
        actualModel = "deepseek-chat-v2"
      }

      console.log("API请求模型:", actualModel, "额外参数:", extraParams)

      // 先显示思考中...
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // 创建AbortController用于取消请求
      const abortController = messageProcessingRef.current.abortController

      // 构建多轮对话的消息数组
      const contextMessages = buildContextMessages(message, config.contextCount)

      // 发送请求到DeepSeek API
      const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          model: actualModel,
          messages: contextMessages, // 使用包含上下文的消息数组
          temperature: config.temperature,
          max_tokens: config.maxTokens,
          stream: config.streamOutput,
          // 只有在非reasoner模型且启用JSON模式时才添加response_format
          ...(config.model !== "deepseek-r1" && config.jsonMode ? { response_format: { type: "json_object" } } : {}),
          ...extraParams,
        }),
        signal: abortController?.signal,
      })

      // 检查响应状态
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`API错误: ${errorData.error?.message || response.statusText}`)
      }

      // 处理流式响应
      if (config.streamOutput && response.body) {
        const reader = response.body.getReader()
        const decoder = new TextDecoder("utf-8")
        let fullText = ""
        let fullThinking = ""
        let buffer = ""
        const outputInterval = 30 // 每秒输出30个字符
        const intervalMs = 1000 / outputInterval
        let lastOutputTime = 0

        try {
          // 处理流式响应的主循环
          const processStream = async () => {
            while (true) {
              // 检查是否被中止
              if (!messageProcessingRef.current.isProcessing) {
                break
              }

              const { done, value } = await reader.read()
              if (done) break

              // 解码二进制数据
              const chunk = decoder.decode(value, { stream: true })

              // 解析SSE格式数据
              const lines = chunk.split("\n")
              for (const line of lines) {
                if (line.startsWith("data:")) {
                  try {
                    const data = JSON.parse(line.substring(5))

                    // 处理思考过程
                    if (data.choices && data.choices[0]?.delta?.reasoning_content) {
                      // 如果是第一个字符，隐藏思考中状态
                      if (!hasStartedOutput) {
                        setIsThinking(false)
                        setHasStartedOutput(true)
                      }

                      const thinkingContent = data.choices[0].delta.reasoning_content
                      fullThinking += thinkingContent
                      buffer += thinkingContent
                    }

                    // 处理正常内容
                    if (data.choices && data.choices[0]?.delta?.content) {
                      // 如果是第一个字符，隐藏思考中状态
                      if (!hasStartedOutput) {
                        setIsThinking(false)
                        setHasStartedOutput(true)
                      }

                      const content = data.choices[0].delta.content
                      fullText += content
                      buffer += content

                      // 如果思考过程已完成但还未显示分隔线，显示分隔线
                      if (fullThinking && !thinkingComplete && fullText) {
                        setThinkingComplete(true)
                      }
                    }
                  } catch (e) {
                    // 忽略解析错误
                  }
                }
              }

              // 控制输出速率，确保平滑显示
              const now = Date.now()
              if (buffer.length > 0 && (now - lastOutputTime >= intervalMs || buffer.length > 40)) {
                // 使用更大的缓冲区，减少DOM更新频率
                const outputBuffer = buffer
                buffer = ""

                if (fullThinking.includes(outputBuffer)) {
                  setDisplayedThinking(formatThinkingText(fullThinking))
                } else {
                  setDisplayedResponse(formatResponseText(fullText))
                }

                lastOutputTime = now
              }
            }

            // 输出剩余的缓冲区内容
            if (buffer.length > 0) {
              if (fullThinking.includes(buffer)) {
                setDisplayedThinking(formatThinkingText(fullThinking))
              } else {
                setDisplayedResponse(formatResponseText(fullText))
              }
            }
          }

          await processStream()
        } catch (error) {
          // 检查是否是因为中止而导致的错误
          if (error.name === "AbortError") {
            console.log("Fetch aborted")
          } else {
            console.error("Error reading stream:", error)
          }
        } finally {
          // 完成流式响应后，添加完整消息
          if (fullText) {
            // 添加到消息列表
            const finalMessages = [
              ...messages,
              { role: "user", content: message },
              {
                role: "assistant",
                content: formatResponseText(fullText),
                thinking: fullThinking ? formatThinkingText(fullThinking) : undefined,
              },
            ]

            setMessages(finalMessages)

            // 保存更新的对话
            saveConversation(finalMessages)

            setDisplayedResponse("")
            setDisplayedThinking("")

            // 如果语音播放开启，则朗读回复
            if (voiceEnabled) {
              speakText(formatResponseText(fullText)) // 只朗读最终答案，不朗读思考过程
            }
          }

          setIsTyping(false)
          setIsInputDisabled(false)
          setIsProcessingMessage(false)

          // 更新消息处理状态
          messageProcessingRef.current = {
            userMessage: "",
            isProcessing: false,
            abortController: null,
          }
        }
      } else {
        // 处理非流式响应
        const data = await response.json()
        let content = data.choices[0].message.content
        let thinking = ""

        // 检查是否有思考过程
        if (data.choices[0].message.reasoning_content) {
          thinking = data.choices[0].message.reasoning_content
          thinking = formatThinkingText(thinking)
        }

        content = formatResponseText(content)

        // 添加到消息列表
        const finalMessages = [
          ...messages,
          { role: "user", content: message },
          {
            role: "assistant",
            content: content,
            thinking: thinking || undefined,
          },
        ]

        setMessages(finalMessages)

        // 保存更新的对话
        saveConversation(finalMessages)

        setIsTyping(false)
        setIsInputDisabled(false)
        setIsProcessingMessage(false)

        // 更新消息处理状态
        messageProcessingRef.current = {
          userMessage: "",
          isProcessing: false,
          abortController: null,
        }

        // 如果语音播放开启，则朗读回复
        if (voiceEnabled) {
          speakText(content) // 只朗读最终答案，不朗读思考过程
        }
      }
    } catch (error) {
      console.error("Error in fetchAIResponse:", error)

      // 添加错误消息
      const errorMessages = [
        ...messages,
        { role: "user", content: message },
        {
          role: "assistant",
          content: `调用API时出错: ${error instanceof Error ? error.message : "未知错误"}。请检查API配置或网络连接。`,
        },
      ]

      setMessages(errorMessages)

      // 保存更新的对话
      saveConversation(errorMessages)

      setIsTyping(false)
      setIsInputDisabled(false)
      setIsThinking(false)
      setIsProcessingMessage(false)

      // 更新消息处理状态
      messageProcessingRef.current = {
        userMessage: "",
        isProcessing: false,
        abortController: null,
      }
    }
  }

  // 语音合成功能
  const speakText = (text: string) => {
    if ("speechSynthesis" in window) {
      // 停止任何正在进行的语音
      window.speechSynthesis.cancel()

      const utterance = new SpeechSynthesisUtterance(text)

      // 获取所有可用的语音
      const voices = window.speechSynthesis.getVoices()

      // 尝试找到中文女声
      const chineseVoice = voices.find((voice) => voice.lang.includes("zh") && voice.name.includes("Female"))

      if (chineseVoice) {
        utterance.voice = chineseVoice
      }

      // 设置语音参数
      utterance.pitch = 1.2 // 稍高的音调
      utterance.rate = 1.0 // 正常速度
      utterance.volume = 1.0 // 最大音量

      window.speechSynthesis.speak(utterance)
    }
  }

  // 处理键盘事件
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // 2. 优化截图功能
  const handleScreenshot = () => {
    setIsScreenshotModalOpen(true)
  }

  // 3. 优化下载功能
  const handleDownload = () => {
    setIsDownloadModalOpen(true)
  }

  // 下载为Word文档
  const downloadAsWord = async () => {
    try {
      if (!messages.length) return

      // 创建Word文档内容
      let content = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
  <head>
    <meta charset="utf-8">
    <title>${title || "聊天记录"}</title>
    <style>
      body { font-family: 'Microsoft YaHei', Arial, sans-serif; }
      .message { margin-bottom: 20px; }
      .user-message { text-align: right; }
      .assistant-message { text-align: left; }
      .message-content { 
        display: inline-block; 
        padding: 10px 15px; 
        border-radius: 10px; 
        max-width: 80%; 
      }
      .user-content { 
        background-color: #000000; 
        color: #ffffff; 
      }
      .assistant-content { 
        background-color: #F5F5F7; 
        color: #000000; 
      }
      .thinking { 
        font-size: smaller; 
        color: #666666; 
        margin-bottom: 10px; 
        border-left: 3px solid #999999;
        padding-left: 10px;
      }
      h1 { 
        font-size: 24px; 
        font-weight: bold; 
        text-align: center; 
        margin-top: 20px; 
        margin-bottom: 10px; 
      }
      h2 { 
        font-size: 20px; 
        font-weight: bold; 
        margin-top: 16px; 
        margin-bottom: 8px; 
      }
      h3 { 
        font-size: 18px; 
        font-weight: bold; 
        margin-top: 14px; 
        margin-bottom: 7px; 
      }
      .background-box {
        background-color: #f0f0f0;
        padding: 10px;
        border-radius: 5px;
        margin: 10px 0;
        border-left: 2px solid #999999;
      }
      .paragraph-separator {
        height: 1px;
        background-color: #e0e0e0;
        margin: 8px 0;
        width: 100%;
      }
    </style>
  </head>
  <body>
    <h1>${title || "聊天记录"}</h1>`

      // 添加消息内容
      messages.forEach((message) => {
        if (message.role === "user") {
          content += `
      <div class="message user-message">
        <div class="message-content user-content">
          ${message.content.replace(/\n/g, "<br>")}
        </div>
      </div>`
        } else {
          content += `
      <div class="message assistant-message">`

          // 添加思考过程
          if (message.thinking) {
            content += `
        <div class="thinking">
          ${message.thinking.replace(/\n/g, "<br>")}
        </div>
        <div class="paragraph-separator"></div>`
          }

          // 处理内容中的标题和背景框
          let processedContent = message.content

          // 处理大标题 (# 标题)
          processedContent = processedContent.replace(
            /^# (.+)$/gm,
            "<h1>$1</h1><div class='paragraph-separator'></div>",
          )

          // 处理二级标题 (## 标题)
          processedContent = processedContent.replace(
            /^## (.+)$/gm,
            "<h2>$1</h2><div class='paragraph-separator'></div>",
          )

          // 处理三级标题 (### 标题)
          processedContent = processedContent.replace(/^### (.+)$/gm, "<h3>$1</h3>")

          // 处理背景框
          processedContent = processedContent.replace(
            /<背景框>(.*?)<\/背景框>/gs,
            '<div class="background-box">$1</div>',
          )

          // 处理换行
          processedContent = processedContent.replace(/\n\n/g, "<div class='paragraph-separator'></div>")
          processedContent = processedContent.replace(/\n/g, "<br>")

          content += `
        <div class="message-content assistant-content">
          ${processedContent}
        </div>
      </div>`
        }
      })

      content += `
  </body>
  </html>`

      // 创建Blob对象
      const blob = new Blob([content], { type: "application/msword" })
      const url = URL.createObjectURL(blob)

      // 创建下载链接
      const link = document.createElement("a")
      link.href = url
      link.download = `${title || "聊天记录"}_${new Date().toISOString().slice(0, 10)}.doc`
      link.click()

      // 释放URL对象
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Word文档生成失败:", error)
      throw error
    }
  }

  // 下载为PDF文档
  const downloadAsPdf = async () => {
    try {
      if (!messages.length) return

      // 在实际应用中，这里应该使用专门的PDF生成库
      // 这里我们使用一个简单的方法，先生成Word文档，然后提示用户手动转换为PDF
      await downloadAsWord()

      // 在实际应用中，这里应该使用PDF生成库，如jsPDF或者服务器端的PDF生成服务
      // 例如：
      // const pdf = new jsPDF();
      // pdf.html(document.getElementById('content'), {
      //   callback: function(pdf) {
      //     pdf.save(`${title || "聊天记录"}_${new Date().toISOString().slice(0, 10)}.pdf`);
      //   }
      // });
    } catch (error) {
      console.error("PDF文档生成失败:", error)
      throw error
    }
  }

  // 打开编辑模态框时初始化数据
  useEffect(() => {
    if (isEditModalOpen) {
      setEditTitle(title)

      // 将所有消息内容合并为一个字符串
      let content = ""
      messages.forEach((message) => {
        if (message.role === "user") {
          content += `【用户】: ${message.content}\n\n`
        } else {
          if (message.thinking) {
            content += `【思考】: ${message.thinking}\n\n`
          }
          content += `【AI】: ${message.content}\n\n`
        }
      })

      setEditContent(content)
    }
  }, [isEditModalOpen, messages, title])

  // 保存编辑内容
  const handleSaveEdit = () => {
    // 更新标题
    setTitle(editTitle)

    // 解析编辑后的内容
    const updatedMessages = parseEditedContent(editContent)

    // 更新消息列表
    if (updatedMessages.length > 0) {
      setMessages(updatedMessages)
    }

    // 更新本地存储
    const userId = currentUser?.id || "guest"
    const storageKey = `${userId}_chatHistory`
    const existingChats = JSON.parse(localStorage.getItem(storageKey) || "[]")

    const updatedChats = existingChats.map((chat: any) => {
      if (chat.id === params.id) {
        return {
          ...chat,
          title: editTitle,
          messages: updatedMessages.length > 0 ? updatedMessages : chat.messages,
          date: new Date().toISOString(), // 更新时间戳
        }
      }
      return chat
    })

    localStorage.setItem(storageKey, JSON.stringify(updatedChats))

    // 关闭编辑模态框
    setIsEditModalOpen(false)

    // 显示保存成功提示
    const successToast = document.createElement("div")
    successToast.className =
      "fixed bottom-20 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded-full shadow-lg"
    successToast.textContent = "保存成功"
    document.body.appendChild(successToast)

    // 1秒后移除提示
    setTimeout(() => {
      document.body.removeChild(successToast)
    }, 1000)
  }

  // 处理图片上传按钮点击
  const handleImageUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  // 处理文件选择
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // 检查文件类型
    if (!file.type.startsWith("image/")) {
      alert("请选择图片文件")
      return
    }

    // 读取文件并转换为Base64
    const reader = new FileReader()
    reader.onload = (event) => {
      if (event.target?.result) {
        // 生成唯一ID
        const imageId = `img_${Date.now()}`

        // 保存图片到状态
        setUploadedImages((prev) => ({
          ...prev,
          [imageId]: event.target!.result as string,
        }))

        // 在光标位置或内容末尾插入图片标记
        const textarea = document.querySelector("textarea") as HTMLTextAreaElement
        if (textarea) {
          const cursorPos = textarea.selectionStart
          const textBefore = editContent.substring(0, cursorPos)
          const textAfter = editContent.substring(cursorPos)

          // 插入图片标记而不是完整的图片URL
          setEditContent(textBefore + `\n[图片已加载:${imageId}]\n` + textAfter)
        } else {
          setEditContent(editContent + `\n[图片已加载:${imageId}]\n`)
        }
      }
    }
    reader.readAsDataURL(file)

    // 清除文件输入，以便可以再次选择同一文件
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  // 添加解析编辑内容的函数
  const parseEditedContent = (content: string) => {
    const lines = content.split("\n\n")
    const updatedMessages: { role: "user" | "assistant"; content: string; thinking?: string }[] = []

    let currentRole: "user" | "assistant" | null = null
    let currentContent = ""
    let currentThinking = ""

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim()

      if (line.startsWith("【用户】:")) {
        // 如果已经有一个消息在处理中，先保存它
        if (currentRole) {
          updatedMessages.push({
            role: currentRole,
            content: currentContent.trim(),
            ...(currentRole === "assistant" && currentThinking ? { thinking: currentThinking.trim() } : {}),
          })
        }

        // 开始新的用户消息
        currentRole = "user"
        currentContent = line.replace("【用户】:", "").trim()
        currentThinking = ""
      } else if (line.startsWith("【思考】:")) {
        // 如果已经有一个消息在处理中且不是AI，先保存它
        if (currentRole && currentRole !== "assistant") {
          updatedMessages.push({
            role: currentRole,
            content: currentContent.trim(),
          })
          currentRole = "assistant"
          currentContent = ""
        }

        // 如果还没有开始AI消息，开始一个
        if (!currentRole) {
          currentRole = "assistant"
        }

        // 添加思考内容
        currentThinking = line.replace("【思考】:", "").trim()
      } else if (line.startsWith("【AI】:")) {
        // 如果已经有一个消息在处理中且不是AI，先保存它
        if (currentRole && currentRole !== "assistant") {
          updatedMessages.push({
            role: currentRole,
            content: currentContent.trim(),
          })
        }

        // 开始新的AI消息
        currentRole = "assistant"
        currentContent = line.replace("【AI】:", "").trim()
      } else if (line) {
        // 处理图片标记
        if (line.startsWith("[图片已加载:") && line.endsWith("]")) {
          const imageId = line.substring(7, line.length - 1)
          if (uploadedImages[imageId]) {
            // 将图片标记替换为实际的图片HTML
            currentContent += `\n<img src="${uploadedImages[imageId]}" alt="上传图片" style="max-width:100%; height:auto;" />\n`
          } else {
            // 如果找不到图片，保留原始文本
            currentContent += `\n${line}\n`
          }
        } else {
          // 继续添加到当前内容
          if (currentRole) {
            currentContent += "\n\n" + line
          }
        }
      }
    }

    // 添加最后一个消息
    if (currentRole) {
      updatedMessages.push({
        role: currentRole,
        content: currentContent.trim(),
        ...(currentRole === "assistant" && currentThinking ? { thinking: currentThinking.trim() } : {}),
      })
    }

    return updatedMessages
  }

  // 渲染消息内容
  const renderMessageContent = (content: string, isThinking = false) => {
    if (isThinking) return content

    // 创建一个稳定的容器结构，防止内容跳动
    const createStableContainer = (html: string, type = "normal") => {
      const heightClass = type === "heading" ? "min-h-[32px]" : "min-h-[24px]"
      return `<div class="content-block ${heightClass} mb-2 stable-content" style="transform: translateZ(0);">${html}</div>`
    }

    // 处理图片标签
    content = content.replace(/<img.*?src="(.*?)".*?>/g, (match, src) => {
      return `<img src="${src}" alt="上传图片" style="max-width:100%; height:auto; margin:10px 0; border-radius:8px;" />`
    })

    // 将内容分割成段落，单独处理每个段落
    const paragraphs = content.split("\n\n").filter((p) => p.trim())
    let processedContent = ""

    // 处理每个段落
    for (let i = 0; i < paragraphs.length; i++) {
      const paragraph = paragraphs[i]

      // 处理大标题 (# 标题)
      if (/^#\s+(.+)$/.test(paragraph)) {
        processedContent += createStableContainer(
          `<h1 class="text-center font-bold text-[${fontSize + 2}px] my-3 stable-heading">${paragraph.replace(/^#\s+/, "")}</h1>`,
          "heading",
        )
        // 在标题后添加一条超细的灰色细线
        processedContent += `<div class="w-full h-[1px] bg-black/10 dark:bg-white/10 my-2 stable-separator"></div>`
        continue
      }

      // 处理二级标题 (## 标题)
      if (/^##\s+(.+)$/.test(paragraph)) {
        processedContent += createStableContainer(
          `<h2 class="font-bold text-[${fontSize + 1}px] my-2 stable-heading">${paragraph.replace(/^##\s+/, "")}</h2>`,
          "heading",
        )
        // 在二级标题后添加一条超细的灰色细线
        processedContent += `<div class="w-full h-[0.5px] bg-black/10 dark:bg-white/10 my-1 stable-separator"></div>`
        continue
      }

      // 处理三级标题 (### 标题)
      if (/^###\s+(.+)$/.test(paragraph)) {
        processedContent += createStableContainer(
          `<h3 class="font-bold text-[${fontSize}px] my-2 stable-heading">${paragraph.replace(/^###\s+/, "")}</h3>`,
          "heading",
        )
        continue
      }

      // 处理背景框标记 (<背景框>内容</背景框>)
      if (/<背景框>(.*?)<\/背景框>/s.test(paragraph)) {
        processedContent += createStableContainer(
          `<div class="bg-black/5 dark:bg-white/5 p-3 rounded-md my-3 stable-box relative border-l-2 border-black/20 dark:border-white/20">
        ${paragraph.replace(/<背景框>(.*?)<\/背景框>/s, "$1")}
      </div>`,
        )
        continue
      }

      // 处理大标题数字 (一、二、三...)
      if (/^(一|二|三|四|五|六|七|八|九|十)、\s*(.+)$/.test(paragraph)) {
        processedContent += createStableContainer(
          paragraph.replace(
            /^(一|二|三|四|五|六|七|八|九|十)、\s*(.+)$/,
            `<h2 class="font-bold text-[${fontSize + 1}px] my-2 stable-heading">$1、$2</h2>`,
          ),
          "heading",
        )
        // 在大标题数字后添加一条超细的灰色细线
        processedContent += `<div class="w-full h-[0.5px] bg-black/10 dark:bg-white/10 my-1 stable-separator"></div>`
        continue
      }

      // 处理小标题数字 (1. 2. 3. ...)
      if (/^(\d+)\.\s+(.+)$/.test(paragraph)) {
        processedContent += createStableContainer(
          paragraph.replace(
            /^(\d+)\.\s+(.+)$/,
            `<h3 class="font-bold text-[${fontSize}px] my-2 stable-heading">$1. $2</h3>`,
          ),
        )
        continue
      }

      // 处理步骤数字 (① ② ③ ...)
      if (/[①②③④⑤⑥⑦⑧⑨⑩]\s+(.+)/.test(paragraph)) {
        processedContent += createStableContainer(`<div class="ml-2 stable-step">${paragraph}</div>`)
        continue
      }

      // 处理普通段落
      const lines = paragraph.split("\n")
      let lineContent = ""

      for (const line of lines) {
        if (line.trim()) {
          // 检查是否是图片标签
          if (line.trim().startsWith("<img")) {
            lineContent += line
          } else {
            lineContent += `<div class="line-content stable-line">${line}</div>`
          }
        }
      }

      if (lineContent) {
        processedContent += createStableContainer(lineContent)
        // 在普通段落后添加一条超细的灰色细线，增强分段效果
        if (i < paragraphs.length - 1) {
          processedContent += `<div class="w-full h-[0.5px] bg-black/5 dark:bg-white/5 my-1 paragraph-separator"></div>`
        }
      }
    }

    // 移除**符号
    processedContent = processedContent.replace(/\*\*/g, "")

    return processedContent
  }

  return (
    <div className="min-h-[100dvh] bg-white dark:bg-black">
      <header className="fixed-header h-[60px] flex items-center justify-center px-4 border-b border-black/[0.06] dark:border-white/[0.06]">
        <button
          onClick={() => router.push("/history")}
          className="absolute left-4 w-10 h-10 flex items-center justify-center rounded-full text-black dark:text-white"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M15 6L9 12L15 18"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <h1 className="text-[17px] font-[600] text-black dark:text-white">{title}</h1>
      </header>
      <div
        ref={messageContainerRef}
        className="fixed-header-content flex-1 overflow-y-auto px-4 py-6 space-y-6 mb-[60px] ai-content-container"
      >
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"} w-full`}>
            <div
              className={`${
                message.role === "user"
                  ? "bg-black text-white dark:bg-white dark:text-black rounded-tr-none max-w-[80%]"
                  : "bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white rounded-tl-none w-full"
              } rounded-2xl px-4 py-3`}
            >
              {message.thinking && (
                <>
                  <div className="flex mb-3">
                    <div className="thinking-separator mr-3 min-h-full"></div>
                    <p
                      className="leading-relaxed text-justify whitespace-pre-wrap text-black/60 dark:text-white/60 flex-1"
                      style={{ fontSize: `${Math.max(fontSize - 2, 12)}px` }}
                      dangerouslySetInnerHTML={{
                        __html: message.thinking
                          .replace(/\*\*/g, "") // 移除所有**符号
                          .replace(/\*/g, "") // 移除所有*符号
                          .replace(/###/g, "") // 移除所有###符号
                          .replace(/##/g, "") // 移除所有##符号
                          .replace(/#/g, "") // 移除所有#符号
                          .replace(/—{2,}/g, "") // 移除所有——符号
                          .replace(/—/g, ""), // 移除所有—符号
                      }}
                    />
                  </div>
                  <hr className="border-t-2 border-black/10 dark:border-white/10 my-3 stable-separator" />
                </>
              )}
              <div
                className="leading-relaxed text-justify"
                style={{ fontSize: `${fontSize}px` }}
                dangerouslySetInnerHTML={{
                  __html: renderMessageContent(message.content, false),
                }}
              />
            </div>
          </div>
        ))}

        {isThinking && <ThinkingAnimation />}

        {isTyping && !isThinking && (
          <div
            className="flex justify-start w-full"
            ref={outputContainerRef}
            style={{ minHeight: displayedThinking || displayedResponse ? "50px" : "auto" }}
          >
            <div className="w-full rounded-2xl rounded-tl-none px-4 py-3 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white overflow-hidden">
              {showThinking && displayedThinking && (
                <div className="mb-3" ref={thinkingContainerRef}>
                  <p
                    className="leading-relaxed text-justify whitespace-pre-wrap text-black/60 dark:text-white/60"
                    style={{ fontSize: `${Math.max(fontSize - 2, 12)}px` }}
                  >
                    {displayedThinking}
                  </p>

                  {thinkingComplete && <hr className="border-t-2 border-black/10 dark:border-white/10 my-3" />}
                </div>
              )}

              {displayedResponse ? (
                <div
                  className="leading-relaxed text-justify"
                  dangerouslySetInnerHTML={{
                    __html: renderMessageContent(displayedResponse, false),
                  }}
                  style={{ fontSize: `${fontSize}px` }}
                  ref={responseContainerRef}
                />
              ) : (
                !displayedThinking && (
                  <div className="flex space-x-1">
                    <div
                      className="w-2 h-2 rounded-full bg-black/40 dark:bg-white/40 animate-bounce"
                      style={{ animationDelay: "0ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-black/40 dark:bg-white/40 animate-bounce"
                      style={{ animationDelay: "150ms" }}
                    ></div>
                    <div
                      className="w-2 h-2 rounded-full bg-black/40 dark:bg-white/40 animate-bounce"
                      style={{ animationDelay: "300ms" }}
                    ></div>
                  </div>
                )
              )}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>
      {/* 底部操作栏 - 添加转发、截图、下载图标，降低高度 */}
      <div className="px-4 py-2 bg-white dark:bg-black fixed bottom-0 left-0 right-0 z-10 border-t border-black/[0.06] dark:border-white/[0.06]">
        <div className="flex justify-around items-center h-[30px]">
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="flex items-center justify-center h-full w-full text-black/70 dark:text-white/70"
          >
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M11 4H4C3.46957 4 2.96086 4.21071 2.58579 4.58579C2.21071 4.96086 2 5.46957 2 6V20C2 20.5304 2.21071 21.0391 2.58579 21.4142C2.96086 21.7893 3.46957 22 4 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V13"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M18.5 2.50001C18.8978 2.10219 19.4374 1.87869 20 1.87869C20.5626 1.87869 21.1022 2.10219 21.5 2.50001C21.8978 2.89784 22.1213 3.4374 22 1.87869C22.1213 4.56262 21.8978 5.10219 21.5 5.50001L12 15L8 16L9 12L18.5 2.50001Z"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <button
            onClick={handleScreenshot}
            className="flex items-center justify-center h-full w-full text-black/70 dark:text-white/70"
          >
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M19 3H5C3.89543 3 3 3.89543 3 5V19C3 20.1046 3.89543 21 5 21H19C20.1046 21 21 20.1046 21 19V5C21 3.89543 20.1046 3 19 3Z"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M8.5 10C9.32843 10 10 9.32843 10 8.5C10 7.67157 9.32843 7 8.5 7C7.67157 7 7 7.67157 7 8.5C7 9.32843 7.67157 10 8.5 10Z"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M21 15L16 10L5 21"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center justify-center h-full w-full text-black/70 dark:text-white/70"
          >
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M21 15V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V15"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M7 10L12 15L17 10"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path d="M12 15V3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      </div>
      ;
      <ScreenshotModal
        isOpen={isScreenshotModalOpen}
        onClose={() => setIsScreenshotModalOpen(false)}
        title={title}
        containerRef={messageContainerRef}
      />
      ;
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        title={title}
        onDownloadWord={downloadAsWord}
        onDownloadPdf={downloadAsPdf}
      />
      {isEditModalOpen && (
        <div className="fixed inset-0 bg-black/50 dark:bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="w-full h-full flex flex-col">
            <div className="p-4 flex-1 overflow-hidden">
              {" "}
              {/* 修改为overflow-hidden */}
              <div className="h-full overflow-auto">
                {" "}
                {/* 添加内部滚动容器 */}
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full text-[20px] font-[600] mb-4 p-2 bg-[#F5F5F7] dark:bg-[#1A1A1A] border-b border-black/20 dark:border-white/20 text-black dark:text-white focus:outline-none focus:border-black dark:focus:border-white"
                  placeholder="标题"
                />
                <textarea
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  className="w-full h-[calc(100vh-200px)] p-2 bg-[#F5F5F7] dark:bg-[#1A1A1A] border border-black/20 dark:border-white/20 rounded-lg text-black dark:text-white focus:outline-none focus:border-black dark:focus:border-white resize-none"
                  style={{ fontSize: `${fontSize}px` }}
                ></textarea>
              </div>
            </div>

            <div className="p-4 flex justify-center space-x-4">
              <button
                onClick={() => router.push(`/history/${params.id}`)}
                className="w-12 h-12 rounded-full bg-gray-500 flex items-center justify-center text-white shadow-lg"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M19 12H5"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M12 19L5 12L12 5"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
              <button
                onClick={handleImageUpload}
                className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white shadow-lg"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <circle
                    cx="16"
                    cy="8"
                    r="2"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
              <button
                onClick={handleSaveEdit}
                className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white shadow-lg"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M20 6L9 17L4 12"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
    </div>
  )
}

// 思考中动画
const ThinkingAnimation = () => (
  <div className="flex justify-start w-full">
    <div className="w-full rounded-2xl rounded-tl-none px-4 py-3 bg-[#F5F5F7] dark:bg-[#1A1A1A] text-black dark:text-white">
      <div className="flex items-center">
        <span className="text-black/70 dark:text-white/70 mr-1">正在思考</span>
        <span className="inline-flex">
          <span className="animate-bounce mx-[1px] delay-0">.</span>
          <span className="animate-bounce mx-[1px] delay-150">.</span>
          <span className="animate-bounce mx-[1px] delay-300">.</span>
        </span>
      </div>
    </div>
  </div>
)

