"use client"

import { useEffect, useState } from "react"

export function VoiceWave({ isListening = false, transcript = "" }) {
  const [bars, setBars] = useState<number[]>([])
  const [isError, setIsError] = useState(false)
  const [isInitialized, setIsInitialized] = useState(false) // 新增：初始化状态

  useEffect(() => {
    // 检查transcript是否包含错误消息
    setIsError(
      transcript.includes("未检测到") ||
        transcript.includes("无法访问") ||
        transcript.includes("权限被拒绝") ||
        transcript.includes("超时") ||
        transcript.includes("错误"),
    )

    // 增加波形数量，使宽度翻倍
    if (!isInitialized) {
      const initialBars = Array.from({ length: 60 }, () => Math.random() * 50 + 10)
      setBars(initialBars)
      setIsInitialized(true)
    }

    // 动画效果
    const interval = setInterval(() => {
      if (isListening) {
        // 当正在录音时，波形更活跃
        setBars((prev) => prev.map(() => Math.random() * 70 + 20))
      } else {
        setBars((prev) => prev.map(() => Math.random() * 50 + 10))
      }
    }, 100)

    return () => clearInterval(interval)
  }, [isListening, transcript, isInitialized])

  // 优化移动端显示
  return (
    <div className="h-[40px] w-full rounded-full flex items-center justify-center">
      <div className="flex items-center justify-center h-full w-full gap-[1px] px-5 overflow-hidden">
        {bars.map((height, index) => (
          <div
            key={index}
            className={`w-[2px] ${isError ? "bg-red-400 dark:bg-red-500" : "bg-black/60 dark:bg-white/60"} rounded-full transition-all`}
            style={{ height: `${height}%` }}
          ></div>
        ))}
      </div>
      {transcript && (
        <div className="absolute top-[-30px] left-0 right-0 text-center">
          <span className={`text-[14px] ${isError ? "text-red-500 font-medium" : "text-black/70 dark:text-white/70"}`}>
            {transcript}
          </span>
        </div>
      )}
    </div>
  )
}

