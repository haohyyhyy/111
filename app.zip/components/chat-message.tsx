import { format } from "date-fns"

import { cn } from "@/lib/utils"

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface ChatMessageProps {
  message: Message
}

export function ChatMessage({ message }: ChatMessageProps) {
  const isUser = message.role === "user"

  return (
    <div className={cn("flex items-start", isUser && "flex-row-reverse")}>
      <div
        className={cn(
          "h-10 w-10 rounded-full flex items-center justify-center",
          isUser
            ? "bg-[#000000] dark:bg-[#FFFFFF] text-[#FFFFFF] dark:text-[#000000]"
            : "bg-[#F5F5F7] dark:bg-[#1A1A1A] text-[#000000] dark:text-[#FFFFFF] border border-[#000000]/10 dark:border-[#FFFFFF]/10",
        )}
      >
        {isUser ? (
          <span className="text-[15px] font-[500]">您</span>
        ) : (
          <span className="text-[15px] font-[500]">AI</span>
        )}
      </div>

      <div className={cn("max-w-[75%] px-4", isUser ? "pr-0" : "pl-4")}>
        <div
          className={cn(
            "rounded-[22px] px-6 py-4 text-[17px] leading-[1.5] font-[400]",
            isUser
              ? "bg-[#000000] text-[#FFFFFF] dark:bg-[#FFFFFF] dark:text-[#000000] rounded-tr-[6px]"
              : "bg-[#F5F5F7] dark:bg-[#1A1A1A] text-[#000000] dark:text-[#FFFFFF] rounded-tl-[6px]",
          )}
        >
          {message.content}
        </div>
        <div className={cn("text-[13px] text-[#6E6E73] dark:text-[#86868B] mt-1", isUser && "text-right")}>
          {format(message.timestamp, "HH:mm")}
        </div>
      </div>
    </div>
  )
}

