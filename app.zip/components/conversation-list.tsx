"use client"

import { format } from "date-fns"

import { cn } from "@/lib/utils"

type Conversation = {
  id: string
  title: string
  lastMessage: string
  timestamp: Date
}

interface ConversationListProps {
  conversations: Conversation[]
  activeConversation: string
  onSelect: (id: string) => void
}

export function ConversationList({ conversations, activeConversation, onSelect }: ConversationListProps) {
  return (
    <div className="space-y-2">
      {conversations.map((conversation) => (
        <button
          key={conversation.id}
          className={cn(
            "w-full text-left rounded-xl p-3 transition-all",
            activeConversation === conversation.id
              ? "bg-[#000000]/[0.06] dark:bg-[#FFFFFF]/[0.06]"
              : "hover:bg-[#000000]/[0.03] dark:hover:bg-[#FFFFFF]/[0.03]",
          )}
          onClick={() => onSelect(conversation.id)}
        >
          <div className="flex items-start gap-3">
            <div
              className={cn(
                "h-10 w-10 rounded-full flex items-center justify-center",
                activeConversation === conversation.id
                  ? "bg-[#000000] dark:bg-[#FFFFFF] text-[#FFFFFF] dark:text-[#000000]"
                  : "bg-[#F5F5F7] dark:bg-[#1A1A1A] text-[#000000] dark:text-[#FFFFFF] border border-[#000000]/10 dark:border-[#FFFFFF]/10",
              )}
            >
              <span className="text-[15px] font-[500]">{conversation.title.charAt(0)}</span>
            </div>
            <div className="space-y-1 overflow-hidden flex-1">
              <p
                className={cn(
                  "font-[500] truncate text-[15px]",
                  activeConversation === conversation.id
                    ? "text-[#000000] dark:text-[#FFFFFF]"
                    : "text-[#000000] dark:text-[#FFFFFF]",
                )}
              >
                {conversation.title}
              </p>
              <p className="line-clamp-1 text-[13px] text-[#6E6E73] dark:text-[#86868B]">{conversation.lastMessage}</p>
              <p className="text-[12px] text-[#6E6E73] dark:text-[#86868B]">
                {format(conversation.timestamp, "MM月dd日 HH:mm")}
              </p>
            </div>
          </div>
        </button>
      ))}
    </div>
  )
}

