import type React from "react"
import { cn } from "@/lib/utils"

interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary"
  size?: "sm" | "md" | "lg"
  children: React.ReactNode
}

export function IconButton({ variant = "primary", size = "md", className, children, ...props }: IconButtonProps) {
  return (
    <button
      className={cn(
        "relative group flex items-center justify-center rounded-xl transition-all duration-200",
        // Base styles
        "before:absolute before:inset-0 before:rounded-xl before:transition-all before:duration-200",
        "after:absolute after:inset-0 after:rounded-xl after:transition-all after:duration-200",

        // Size variants
        size === "sm" && "h-8 w-8",
        size === "md" && "h-10 w-10",
        size === "lg" && "h-12 w-12",

        // Primary variant
        variant === "primary" && [
          "bg-gradient-to-b from-[#2A2A2A] to-[#1A1A1A] dark:from-[#FFFFFF] dark:to-[#E5E5E5]",
          "before:bg-gradient-to-b before:from-black/10 before:to-transparent dark:before:from-black/5 dark:before:to-transparent",
          "after:bg-gradient-to-b after:from-white/5 after:to-transparent dark:after:from-white/10 dark:after:to-transparent",
          "shadow-lg shadow-black/10 dark:shadow-white/10",
          "hover:scale-105 active:scale-95",
          "text-white dark:text-black",
        ],

        // Secondary variant
        variant === "secondary" && [
          "bg-gradient-to-b from-[#F5F5F7] to-[#E5E5E5] dark:from-[#2A2A2A] dark:to-[#1A1A1A]",
          "before:bg-gradient-to-b before:from-black/5 before:to-transparent dark:before:from-black/10 dark:before:to-transparent",
          "after:bg-gradient-to-b after:from-white/40 after:to-transparent dark:after:from-white/5 dark:after:to-transparent",
          "shadow-lg shadow-black/5 dark:shadow-white/5",
          "hover:scale-105 active:scale-95",
          "text-black dark:text-white",
        ],

        className,
      )}
      {...props}
    >
      {children}
    </button>
  )
}

