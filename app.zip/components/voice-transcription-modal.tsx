"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import CryptoJS from "crypto-js"

interface VoiceTranscriptionModalProps {
  isOpen: boolean
  onClose: () => void
  onSend: (text: string) => void
  initialTranscript?: string
}

// 定义 VoiceWave 组件
interface VoiceWaveProps {
  isListening: boolean
  transcript: string
}

const VoiceWave: React.FC<VoiceWaveProps> = ({ isListening, transcript }) => {
  const barCount = 20
  const bars = Array.from({ length: barCount }, (_, i) => i)

  return (
    <div className="flex items-center justify-center h-10">
      {bars.map((index) => (
        <div
          key={index}
          className={`mx-0.5 w-1 rounded-full transition-height duration-300 ${
            isListening && !transcript ? "bg-blue-500" : "bg-gray-400"
          }`}
          style={{
            height: isListening && !transcript ? `${Math.sin(index + Date.now() / 100) * 2 + 2}vh` : "0.5vh",
          }}
        />
      ))}
    </div>
  )
}

// 修改语音转写模态框，使用讯飞语音听写API
export function VoiceTranscriptionModal({
  isOpen,
  onClose,
  onSend,
  initialTranscript = "",
}: VoiceTranscriptionModalProps) {
  const [transcript, setTranscript] = useState(initialTranscript)
  const [isListening, setIsListening] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [editedTranscript, setEditedTranscript] = useState("")
  const [isOrganizing, setIsOrganizing] = useState(false) // 新增：是否正在整理文本
  const recognitionRef = useRef<any>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const [errorMessage, setErrorMessage] = useState("") // 新增：错误信息状态
  const [xunfeiEnabled, setXunfeiEnabled] = useState(false) // 新增：是否启用讯飞语音听写
  const [xunfeiConfig, setXunfeiConfig] = useState<{ appId: string; apiKey: string; apiSecret: string }>({
    appId: "",
    apiKey: "",
    apiSecret: "",
  })
  const [wsConnection, setWsConnection] = useState<WebSocket | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null)
  const processorRef = useRef<ScriptProcessorNode | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const [isXunfeiInitialized, setIsXunfeiInitialized] = useState(false)
  // 在组件的状态定义部分添加重试计数器
  const [noSpeechRetryCount, setNoSpeechRetryCount] = useState(0)
  const MAX_NO_SPEECH_RETRIES = 3 // 最大重试次数
  // 添加WebSocket连接重试计数器和最大重试次数
  const [wsRetryCount, setWsRetryCount] = useState(0)
  const MAX_WS_RETRIES = 3
  const wsRetryTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // 辅助函数：将Float32Array转换为Int16Array (PCM 16bit)
  function convertFloat32ToInt16(data: Float32Array): Int16Array {
    const l = data.length
    const buf = new Int16Array(l)
    for (let i = 0; i < l; i++) {
      buf[i] = Math.min(1, data[i]) * 0x7fff
    }
    return buf
  }

  // 辅助函数：处理WebSocket错误并进行重连
  const handleWebSocketError = (error: any) => {
    console.error("WebSocket error:", error)
    setErrorMessage(`WebSocket error: ${error.message || "Unknown error"}`)
    setIsListening(false)

    // 增加重试计数
    const newRetryCount = wsRetryCount + 1
    setWsRetryCount(newRetryCount)

    if (newRetryCount <= MAX_WS_RETRIES) {
      // 在重试次数内，延迟后重试
      setErrorMessage(`WebSocket连接失败，正在尝试重连... (${newRetryCount}/${MAX_WS_RETRIES})`)
      wsRetryTimeoutRef.current = setTimeout(() => {
        console.log("尝试重新初始化讯飞语音听写...")
        closeXunfeiConnection()
        setIsXunfeiInitialized(false)
        initXunfeiRecognition(xunfeiConfig)
      }, 2000) // 2秒后重试
    } else {
      // 超过最大重试次数，停止重试并提示用户
      setErrorMessage("WebSocket连接多次失败，请检查网络或稍后重试")
      stopRecognition()
    }
  }

  // 清理定时器和连接
  useEffect(() => {
    return () => {
      stopRecognition()
      closeXunfeiConnection()
      // 清理WebSocket重试定时器
      if (wsRetryTimeoutRef.current) {
        clearTimeout(wsRetryTimeoutRef.current)
        wsRetryTimeoutRef.current = null
      }
    }
  }, [])

  // 初始化语音识别
  useEffect(() => {
    if (!isOpen) return

    // 清空之前的转写内容
    if (!initialTranscript) {
      setTranscript("")
      setEditedTranscript("")
    }

    // 重置错误状态和重试计数器
    setErrorMessage("")
    setNoSpeechRetryCount(0)
    setWsRetryCount(0)

    // 检查是否启用讯飞语音听写
    const storedXunfeiConfig = localStorage.getItem("xunfeiConfig")
    if (storedXunfeiConfig) {
      try {
        const config = JSON.parse(storedXunfeiConfig)
        if (config.appId && config.apiKey && config.apiSecret) {
          setXunfeiEnabled(true)
          setXunfeiConfig(config)
          // 初始化讯飞语音听写
          initXunfeiRecognition(config)
          return
        }
      } catch (error) {
        console.error("解析讯飞配置失败:", error)
        // 降级到浏览器API
        initBrowserRecognition()
      }
    } else {
      // 使用浏览器API
      initBrowserRecognition()
    }

    return () => {
      stopRecognition()
    }
  }, [isOpen, initialTranscript])

  // 初始化浏览器语音识别API
  const initBrowserRecognition = () => {
    // 如果没有启用讯飞，使用浏览器API
    // 检查浏览器支持
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()

      // 配置语音识别
      recognitionRef.current.lang = "zh-CN"
      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.maxAlternatives = 3
      // 新增配置
      const SpeechGrammarList = window.SpeechGrammarList || window.webkitSpeechGrammarList
      if (SpeechGrammarList) {
        recognitionRef.current.speechRecognitionList = new SpeechGrammarList()
      }
      // 降低语音识别的灵敏度阈值，使其更容易捕获声音
      if ("audioThreshold" in recognitionRef.current) {
        recognitionRef.current.audioThreshold = 0.2 // 降低阈值，如果API支持
      }

      // 开始识别
      recognitionRef.current.onstart = () => {
        setIsListening(true)
        setErrorMessage("") // 清除错误信息
      }

      // 处理结果
      recognitionRef.current.onresult = (event: any) => {
        let finalTranscript = ""
        let interimTranscript = ""

        // 处理所有结果
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i]
          if (result.isFinal) {
            finalTranscript += result[0].transcript
          } else {
            interimTranscript += result[0].transcript
          }
        }

        // 更新转写文本
        if (finalTranscript) {
          setTranscript((prev) => {
            // 如果前一个转写以标点符号结尾，确保有空格
            if (
              prev &&
              !prev.endsWith(" ") &&
              !prev.endsWith("。") &&
              !prev.endsWith("，") &&
              !prev.endsWith("？") &&
              !prev.endsWith("！")
            ) {
              return prev + "，" + finalTranscript
            }
            return prev + finalTranscript
          })
        } else if (interimTranscript) {
          // 显示临时结果
          const fullText = transcript + (transcript && !transcript.endsWith(" ") ? " " : "") + interimTranscript
          const interimElement = document.getElementById("interim-transcript")
          if (interimElement) {
            interimElement.textContent = fullText
          }
        }
      }

      // 处理错误
      recognitionRef.current.onerror = (event: any) => {
        console.error("语音识别错误:", event.error)

        // 改进错误处理
        if (event.error === "no-speech") {
          // 增加重试计数
          const newRetryCount = noSpeechRetryCount + 1
          setNoSpeechRetryCount(newRetryCount)

          if (newRetryCount <= MAX_NO_SPEECH_RETRIES) {
            // 在重试次数内，继续尝试
            setErrorMessage(`未检测到语音，请说话或靠近麦克风 (${newRetryCount}/${MAX_NO_SPEECH_RETRIES})`)
            // 增加延迟，给系统更多准备时间
            setTimeout(() => {
              restartRecognition()
            }, 800)
          } else {
            // 超过最大重试次数，暂停识别并提示用户手动重启
            setErrorMessage("未检测到语音，请点击麦克风图标重新开始")
            setIsListening(false)
            stopRecognition()
          }
        } else if (event.error === "audio-capture") {
          setErrorMessage("无法访问麦克风，请检查设备权限")
          stopRecognition()
        } else if (event.error === "not-allowed") {
          setErrorMessage("麦克风权限被拒绝，请允许访问")
          stopRecognition()
        } else if (event.error === "aborted") {
          // 用户中止，不显示错误
          setErrorMessage("")
        } else if (event.error === "network") {
          setErrorMessage("网络错误，请检查连接")
          restartRecognition()
        } else {
          setErrorMessage(`识别出错，正在重试...`)
          restartRecognition()
        }
      }

      // 识别结束后自动重启
      recognitionRef.current.onend = () => {
        if (isListening && isOpen) {
          // 添加延迟，避免立即重启导致的问题
          setTimeout(() => {
            restartRecognition()
          }, 300)
        }
      }

      // 启动识别
      try {
        recognitionRef.current.start()
      } catch (e) {
        console.error("启动语音识别失败:", e)
        setErrorMessage("启动语音识别失败，请重试")
        // 尝试延迟启动
        setTimeout(() => {
          try {
            recognitionRef.current.start()
          } catch (e) {
            console.error("重试启动语音识别失败:", e)
          }
        }, 500)
      }
    } else {
      setTranscript("您的浏览器不支持语音识别功能")
      setIsListening(false)
      setErrorMessage("浏览器不支持语音识别")
    }
  }

  // 修改initXunfeiRecognition函数，使用讯飞语音听写API
  const initXunfeiRecognition = async (config: { appId: string; apiKey: string; apiSecret: string }) => {
    if (!config.appId || !config.apiKey || !config.apiSecret || isXunfeiInitialized) return

    try {
      setIsXunfeiInitialized(true)
      setErrorMessage("正在初始化讯飞语音听写...")

      // 请求麦克风权限
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
        streamRef.current = stream
      } catch (err) {
        console.error("获取麦克风权限失败:", err)
        setErrorMessage("无法访问麦克风，请检查设备权限")
        setIsXunfeiInitialized(false)
        // 降级到浏览器API
        initBrowserRecognition()
        return
      }

      // 创建音频上下文
      try {
        const audioContext = new AudioContext()
        audioContextRef.current = audioContext

        // 创建音频源节点
        const source = audioContext.createMediaStreamSource(streamRef.current!)
        sourceRef.current = source

        // 创建处理器节点
        const processor = audioContext.createScriptProcessor(16384, 1, 1)
        processorRef.current = processor

        // 连接节点
        source.connect(processor)
        processor.connect(audioContext.destination)
      } catch (err) {
        console.error("创建音频处理节点失败:", err)
        setErrorMessage("初始化音频处理失败，请重试")
        setIsXunfeiInitialized(false)
        return
      }

      // 根据讯飞语音听写API文档构建连接
      try {
        // 1. 构建鉴权URL
        const host = "iat-api.xfyun.cn"
        const apiPath = "/v2/iat"
        const url = `wss://${host}${apiPath}`

        // 2. 构建鉴权参数
        const now = Math.floor(Date.now() / 1000)
        const expireTime = now + 60 // 授权有效期1分钟

        // 3. 生成RFC1123格式的日期
        const date = new Date().toUTCString()

        // 4. 构建鉴权字符串
        const signatureOrigin = `host: ${host}\ndate: ${date}\nGET ${apiPath} HTTP/1.1`

        // 5. 使用HMAC-SHA256计算签名
        const signature = CryptoJS.HmacSHA256(signatureOrigin, config.apiSecret)
        const signatureBase64 = CryptoJS.enc.Base64.stringify(signature)

        // 6. 构建鉴权参数
        const authorizationOrigin = `api_key="${config.apiKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signatureBase64}"`
        const authorization = btoa(authorizationOrigin)

        // 7. 构建请求参数
        const requestParams = {
          common: {
            app_id: config.appId,
          },
          business: {
            language: "zh_cn",
            domain: "iat",
            accent: "mandarin",
            vad_eos: 3000, // 静默检测时间，单位ms
            dwa: "wpgs", // 开启动态修正功能
          },
          data: {
            status: 0, // 0: 第一帧, 1: 中间帧, 2: 最后一帧
            format: "audio/L16;rate=16000",
            encoding: "raw",
          },
        }

        // 8. 构建完整的WebSocket URL
        const connectionUrl = `${url}?authorization=${authorization}&date=${encodeURIComponent(date)}&host=${host}`

        console.log("讯飞WebSocket连接URL:", connectionUrl)
        console.log("讯飞AppID:", config.appId)
        console.log("讯飞API Key:", config.apiKey.substring(0, 4) + "****") // 只显示前4位，保护密钥安全

        // 9. 创建WebSocket连接
        const ws = new WebSocket(connectionUrl)
        setWsConnection(ws)

        // 设置超时处理
        const connectionTimeout = setTimeout(() => {
          if (ws.readyState !== WebSocket.OPEN) {
            console.error("讯飞WebSocket连接超时")
            ws.close()
            handleWebSocketError(new Error("连接超时"))
          }
        }, 10000) // 10秒超时

        // 辅助函数：将ArrayBuffer转换为Base64
        function arrayBufferToBase64(buffer) {
          const bytes = new Uint8Array(buffer)
          let binary = ""
          for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i])
          }
          return btoa(binary)
        }

        ws.onopen = () => {
          clearTimeout(connectionTimeout)
          console.log("讯飞WebSocket连接已建立")
          setIsListening(true)
          setErrorMessage("")
          setWsRetryCount(0) // 重置重试计数

          // 发送业务参数帧
          ws.send(JSON.stringify(requestParams))

          // 设置音频处理事件
          if (processorRef.current) {
            processorRef.current.onaudioprocess = (e) => {
              // 只有在连接开启且正在监听时发送数据
              if (ws.readyState === WebSocket.OPEN && isListening) {
                // 获取音频数据
                const inputData = e.inputBuffer.getChannelData(0)

                // 将Float32Array转换为Int16Array (PCM 16bit)
                const pcmData = convertFloat32ToInt16(inputData)

                // 将音频数据转换为Base64
                const audioBase64 = arrayBufferToBase64(pcmData.buffer)

                // 构建音频数据帧
                const audioFrame = {
                  data: {
                    status: 1, // 1: 中间帧
                    format: "audio/L16;rate=16000",
                    audio: audioBase64,
                    encoding: "raw",
                  },
                }

                // 发送音频数据
                try {
                  ws.send(JSON.stringify(audioFrame))
                } catch (err) {
                  console.error("发送音频数据失败:", err)
                }
              }
            }
          }
        }

        ws.onmessage = (e) => {
          try {
            const data = JSON.parse(e.data)
            console.log("收到讯飞消息:", data)

            // 处理不同类型的消息
            if (data.code !== 0) {
              // 处理错误
              console.error("讯飞语音听写错误:", data)
              setErrorMessage(`讯飞语音听写错误: ${data.message || "未知错误"} (${data.code})`)
              return
            }

            // 处理正常结果
            if (data.data && data.data.result) {
              // 处理转写结果
              const resultData = data.data.result

              // 检查是否有转写结果
              if (resultData.ws) {
                let text = ""

                // 拼接所有词
                resultData.ws.forEach((ws) => {
                  if (ws.cw && ws.cw.length > 0) {
                    // 取置信度最高的词
                    text += ws.cw[0].w
                  }
                })

                // 检查是否是最终结果
                const isFinal = resultData.ls

                if (isFinal) {
                  // 更新转写文本
                  setTranscript((prev) => {
                    if (
                      prev &&
                      !prev.endsWith(" ") &&
                      !prev.endsWith("。") &&
                      !prev.endsWith("，") &&
                      !prev.endsWith("？") &&
                      !prev.endsWith("！")
                    ) {
                      return prev + "，" + text
                    }
                    return prev + text
                  })
                } else {
                  // 显示临时结果
                  const interimElement = document.getElementById("interim-transcript")
                  if (interimElement) {
                    interimElement.textContent = text
                  }
                }
              }
            }
          } catch (error) {
            console.error("处理讯飞消息时出错:", error)
          }
        }

        ws.onerror = (e) => {
          clearTimeout(connectionTimeout)
          console.error("讯飞WebSocket错误:", e)
          handleWebSocketError(e)
        }

        ws.onclose = (e) => {
          clearTimeout(connectionTimeout)
          console.log("讯飞WebSocket连接已关闭", e.code, e.reason)

          // 如果是正常关闭，不需要重试
          if (e.code === 1000) {
            setIsListening(false)
            return
          }

          // 非正常关闭，尝试重连
          handleWebSocketError(new Error(`连接关闭: ${e.code} ${e.reason}`))
        }
      } catch (err) {
        console.error("计算签名或建立WebSocket连接失败:", err)
        setErrorMessage(`初始化讯飞语音听写失败: ${err instanceof Error ? err.message : "未知错误"}`)
        setIsXunfeiInitialized(false)
        // 降级到浏览器API
        initBrowserRecognition()
      }
    } catch (error) {
      console.error("初始化讯飞语音听写失败:", error)
      setErrorMessage(`初始化讯飞语音听写失败: ${error instanceof Error ? error.message : "未知错误"}`)
      setIsListening(false)
      setIsXunfeiInitialized(false)
      // 降级到浏览器API
      initBrowserRecognition()
    }
  }

  // 修改closeXunfeiConnection函数，发送结束帧
  const closeXunfeiConnection = () => {
    // 清理WebSocket重试定时器
    if (wsRetryTimeoutRef.current) {
      clearTimeout(wsRetryTimeoutRef.current)
      wsRetryTimeoutRef.current = null
    }

    if (wsConnection) {
      // 发送结束标志
      if (wsConnection.readyState === WebSocket.OPEN) {
        try {
          // 发送最后一帧，status=2表示最后一帧
          const endFrame = {
            data: {
              status: 2, // 2表示最后一帧
              format: "audio/L16;rate=16000",
              audio: "",
              encoding: "raw",
            },
          }
          wsConnection.send(JSON.stringify(endFrame))
        } catch (e) {
          console.error("发送结束帧失败:", e)
        }
      }

      // 关闭连接
      try {
        wsConnection.close(1000, "Normal closure")
      } catch (e) {
        console.error("关闭WebSocket连接失败:", e)
      }
      setWsConnection(null)
    }

    // 清理录音资源
    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach((track) => track.stop())
      } catch (e) {
        console.error("停止音频轨道失败:", e)
      }
      streamRef.current = null
    }

    if (audioContextRef.current) {
      try {
        if (audioContextRef.current.state !== "closed") {
          audioContextRef.current.close()
        }
      } catch (e) {
        console.error("关闭音频上下文失败:", e)
      }
      audioContextRef.current = null
    }

    if (sourceRef.current) {
      try {
        sourceRef.current.disconnect()
      } catch (e) {
        console.error("断开音频源连接失败:", e)
      }
      sourceRef.current = null
    }

    if (processorRef.current) {
      try {
        processorRef.current.disconnect()
      } catch (e) {
        console.error("断开处理器连接失败:", e)
      }
      processorRef.current = null
    }

    setIsXunfeiInitialized(false)
  }

  // 修改restartRecognition函数
  const restartRecognition = () => {
    // 重置no-speech错误计数
    setNoSpeechRetryCount(0)

    if (xunfeiEnabled && xunfeiConfig.appId && xunfeiConfig.apiKey && xunfeiConfig.apiSecret) {
      // 重启讯飞语音听写
      closeXunfeiConnection()
      setIsXunfeiInitialized(false)
      initXunfeiRecognition(xunfeiConfig)
    } else if (recognitionRef.current) {
      try {
        recognitionRef.current.start()
      } catch (e) {
        // 如果已经在运行，先停止再启动
        try {
          recognitionRef.current.stop()
          // 添加延迟，确保完全停止后再启动
          setTimeout(() => {
            try {
              recognitionRef.current.start()
            } catch (e) {
              console.error("无法重启语音识别:", e)
              setErrorMessage("重启识别失败，请手动点击继续")
            }
          }, 300)
        } catch (e) {
          console.error("停止语音识别失败:", e)
        }
      }
    }
  }

  // 修改handleWaveClick函数
  const handleWaveClick = () => {
    setNoSpeechRetryCount(0)
    setWsRetryCount(0)

    if (isListening) {
      stopRecognition()
    } else {
      setIsListening(true)
      restartRecognition()
    }
  }

  // 停止语音识别
  const stopRecognition = () => {
    if (xunfeiEnabled) {
      // 停止讯飞语音听写
      closeXunfeiConnection()
    } else if (recognitionRef.current) {
      try {
        recognitionRef.current.stop()
        setIsListening(false)
      } catch (e) {
        console.error("停止语音识别时出错:", e)
      }
    }
  }

  // 处理返回按钮点击
  const handleBack = () => {
    stopRecognition()
    setTranscript("") // 清空转写内容
    onClose()
  }

  // 处理编辑按钮点击
  const handleEdit = () => {
    setIsEditing(true)
    setEditedTranscript(transcript)
    // 停止语音识别
    stopRecognition()

    // 等待DOM更新后聚焦文本框
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus()
        textareaRef.current.setSelectionRange(textareaRef.current.value.length, textareaRef.current.value.length)
      }
    }, 50)
  }

  // 处理发送按钮点击
  const handleSend = () => {
    onSend(transcript)
    setTranscript("") // 清空转写内容
    onClose()
  }

  // 处理确认编辑
  const handleConfirmEdit = () => {
    setTranscript(editedTranscript)
    setIsEditing(false)
  }

  // 新增：处理整理文本功能
  const handleOrganizeText = async () => {
    if (!transcript.trim()) return

    setIsOrganizing(true)

    try {
      // 简单的文本整理逻辑
      let organizedText = transcript // 修复标点符号
        .replace(/，{2,}/g, "，")
        .replace(/。{2,}/g, "。")
        .replace(/\s+/g, " ")
        .replace(/([。！？，：；])\s*/g, "$1")
        .replace(/\s*([。！？，：；])/g, "$1")

      // 添加适当的标点符号
      if (!organizedText.match(/[。！？]$/)) {
        organizedText += "。"
      }

      // 分段处理
      const sentences = organizedText.split(/[。！？]/).filter((s) => s.trim())
      if (sentences.length > 3) {
        // 如果句子较多，尝试分段
        const paragraphs = []
        let currentParagraph = ""

        for (let i = 0; i < sentences.length; i++) {
          if (sentences[i].trim()) {
            currentParagraph += sentences[i] + "。"

            // 每2-3个句子形成一个段落
            if ((i + 1) % 3 === 0) {
              paragraphs.push(currentParagraph)
              currentParagraph = ""
            }
          }
        }

        if (currentParagraph) {
          paragraphs.push(currentParagraph)
        }

        organizedText = paragraphs.join("\n\n")
      }

      // 更新文本
      setTranscript(organizedText)
    } catch (error) {
      console.error("整理文本时出错:", error)
    } finally {
      setIsOrganizing(false)
    }
  }

  // 如果模态框未打开，不渲染任何内容
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 dark:bg-black/50 backdrop-blur-sm z-50 flex flex-col">
      {/* 修改弹窗样式，高度与对话页面一致，背景50%透明 */}
      <div className="w-full h-full flex flex-col">
        <div className="flex-1 p-4 overflow-hidden">
          {/* 转写内容显示区域 */}
          <div
            className="h-[calc(100vh-280px)] overflow-auto bg-white/10 dark:bg-white/5 rounded-xl p-4 mb-4"
            style={{ zIndex: 2, position: "relative" }}
          >
            {isEditing ? (
              <textarea
                ref={textareaRef}
                value={editedTranscript}
                onChange={(e) => setEditedTranscript(e.target.value)}
                className="w-full h-full bg-transparent text-black dark:text-white text-lg p-2 border-none focus:outline-none resize-none"
                autoFocus
              />
            ) : (
              <>
                <p className="text-black dark:text-white text-lg whitespace-pre-wrap break-words">{transcript}</p>
                <p id="interim-transcript" className="text-black/60 dark:text-white/60 text-lg italic"></p>
                {/* 显示错误信息 */}
                {errorMessage && <p className="text-red-500 text-sm mt-2">{errorMessage}</p>}
                {isOrganizing && <p className="text-blue-500 text-sm mt-2">正在整理文本...</p>}
              </>
            )}
          </div>

          {/* 音波动画区域 - 调整到与对话页面输入框位置一致，移动端自适应 */}
          <div
            className="relative mb-3 transform translate-y-[0px] sm:transform-none"
            style={{ marginBottom: "60px", marginTop: "20px" }} // 增加顶部边距，确保不覆盖转写框
          >
            <div
              className="w-full px-5 py-3 rounded-full border border-black/10 dark:border-white/10 bg-transparent flex items-center"
              onClick={handleWaveClick}
              style={{ zIndex: 1 }} // 确保正确的层级关系
            >
              <div className="flex-1">
                <VoiceWave isListening={isListening} transcript={errorMessage} />
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  if (isListening) {
                    stopRecognition()
                  } else {
                    setIsListening(true)
                    restartRecognition()
                  }
                }}
                className="ml-2 w-8 h-8 flex items-center justify-center rounded-full bg-black dark:bg-white text-white dark:text-black"
              >
                {isListening ? (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect
                      x="6"
                      y="5"
                      width="4"
                      height="14"
                      rx="1"
                      stroke="currentColor"
                      strokeWidth="2"
                      fill="currentColor"
                    />
                    <rect
                      x="14"
                      y="5"
                      width="4"
                      height="14"
                      rx="1"
                      stroke="currentColor"
                      strokeWidth="2"
                      fill="currentColor"
                    />
                  </svg>
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M12 2V22"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M19 4V20"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M5 4V20"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* 底部按钮区域 - 调整到与对话页面底部按钮位置一致 */}
        <div className="px-4 pb-2 pt-3 bg-transparent" style={{ zIndex: 3, position: "relative" }}>
          <div className="flex justify-around items-center h-[60px]">
            {isEditing ? (
              <button
                onClick={handleConfirmEdit}
                className="w-12 h-12 rounded-full bg-green-500/90 flex items-center justify-center text-white shadow-sm hover:bg-green-500 transition-colors"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M20 6L9 17L4 12"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            ) : (
              <>
                <button
                  onClick={handleBack}
                  className="w-12 h-12 rounded-full bg-gray-500/90 flex items-center justify-center text-white shadow-sm hover:bg-gray-500 transition-colors"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M19 12H5"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M12 19L5 12L12 5"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
                {/* 整理按钮 - 简约风格 */}
                <button
                  onClick={handleOrganizeText}
                  className="w-12 h-12 rounded-full bg-purple-500/90 flex items-center justify-center text-white shadow-sm hover:bg-purple-500 transition-colors"
                  disabled={isOrganizing || !transcript.trim()}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M4 21h16M4 10h16M4 3h16"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
                <button
                  onClick={handleEdit}
                  className="w-12 h-12 rounded-full bg-blue-500/90 flex items-center justify-center text-white shadow-sm hover:bg-blue-500 transition-colors"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M11 4H4C3.46957 4 2.96086 4.21071 2.58579 4.58579C2.21071 4.96086 2 5.46957 2 6V20C2 20.5304 2.21071 21.0391 2.58579 21.4142C2.96086 21.7893 3.46957 22 4 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V13"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M18.5 2.50001C18.8978 2.10219 19.4374 1.87869 20 1.87869C20.5626 1.87869 21.1022 2.10219 21.5 2.50001C21.8978 2.89784 22.1213 3.4374 22.1213 4.00001C22.1213 4.56262 21.8978 5.10219 21.5 5.50001L12 15L8 16L9 12L18.5 2.50001Z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
                <button
                  onClick={handleSend}
                  className="w-12 h-12 rounded-full bg-green-500/90 flex items-center justify-center text-white shadow-sm hover:bg-green-500 transition-colors"
                  disabled={!transcript.trim()}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M22 2L11 13"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M22 2L15 22L11 13L2 9L22 2Z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

