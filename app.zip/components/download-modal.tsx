"use client"

import { useState, useRef, useEffect } from "react"

interface DownloadModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  onDownloadWord: () => Promise<void>
  onDownloadPdf: () => Promise<void>
}

export function DownloadModal({ isOpen, onClose, title, onDownloadWord, onDownloadPdf }: DownloadModalProps) {
  const [step, setStep] = useState<"confirm" | "downloading" | "complete">("confirm")
  const [format, setFormat] = useState<"word" | "pdf" | null>(null)
  const [progress, setProgress] = useState(0)
  const [downloadComplete, setDownloadComplete] = useState(false)
  const [showCompletionMessage, setShowCompletionMessage] = useState(true)

  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const completionTimerRef = useRef<NodeJS.Timeout | null>(null)

  // 清理定时器
  useEffect(() => {
    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current)
      }
      if (completionTimerRef.current) {
        clearTimeout(completionTimerRef.current)
      }
    }
  }, [])

  // 重置状态
  useEffect(() => {
    if (!isOpen) {
      setTimeout(() => {
        setStep("confirm")
        setFormat(null)
        setProgress(0)
        setDownloadComplete(false)
        setShowCompletionMessage(true)
      }, 300)
    }
  }, [isOpen])

  // 开始下载
  const startDownload = async () => {
    if (!format) return

    setStep("downloading")

    // 模拟进度条
    progressIntervalRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          return prev
        }
        return prev + Math.random() * 10
      })
    }, 100)

    try {
      // 根据选择的格式执行下载
      if (format === "word") {
        await onDownloadWord()
      } else {
        await onDownloadPdf()
      }

      // 设置进度为100%并完成
      setProgress(100)
      setTimeout(() => {
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current)
        }
        setDownloadComplete(true)
        setStep("complete")

        // 1秒后自动关闭
        completionTimerRef.current = setTimeout(() => {
          setShowCompletionMessage(false)
          setTimeout(() => {
            onClose()
          }, 300)
        }, 1000)
      }, 500)
    } catch (error) {
      console.error("下载失败:", error)
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current)
      }
      setStep("confirm")
      alert("下载失败，请重试")
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/30 dark:bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="w-full max-w-[320px] bg-transparent rounded-2xl p-6">
        {step === "confirm" && (
          <>
            <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">
              确定将 "{title}" 下载到本地吗？
            </h3>
            <div className="flex justify-center space-x-4 mb-6">
              <button
                onClick={() => {
                  setFormat("word")
                  startDownload()
                }}
                className="w-[120px] h-[48px] rounded-full bg-[#F5F5F7] dark:bg-[#2A2A2A] text-black dark:text-white text-[16px] font-[500] flex items-center justify-center"
              >
                <svg
                  className="mr-2"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M14 2V8H20"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M16 13H8"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M16 17H8"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M10 9H9H8"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                Word
              </button>
              <button
                onClick={() => {
                  setFormat("pdf")
                  startDownload()
                }}
                className="w-[120px] h-[48px] rounded-full bg-[#F5F5F7] dark:bg-[#2A2A2A] text-black dark:text-white text-[16px] font-[500] flex items-center justify-center"
              >
                <svg
                  className="mr-2"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M14 2V8H20"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M9 15H15"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                PDF
              </button>
            </div>
            <button
              onClick={onClose}
              className="w-full h-[48px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500]"
            >
              取消
            </button>
          </>
        )}

        {step === "downloading" && (
          <>
            <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">正在下载...</h3>
            <div className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-full mb-6">
              <div
                className="h-full bg-green-500 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </>
        )}

        {step === "complete" && showCompletionMessage && (
          <>
            <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">下载已完成</h3>
            <div className="flex justify-center">
              <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M20 6L9 17L4 12"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

