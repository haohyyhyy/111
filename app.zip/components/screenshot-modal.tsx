"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import html2canvas from "html2canvas"

interface ScreenshotModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  containerRef: React.RefObject<HTMLDivElement>
}

export function ScreenshotModal({ isOpen, onClose, title, containerRef }: ScreenshotModalProps) {
  const [step, setStep] = useState<"confirm" | "generating" | "complete">("confirm")
  const [quality, setQuality] = useState<"normal" | "high">("normal")
  const [progress, setProgress] = useState(0)
  const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)
  const [isDownloading, setIsDownloading] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [downloadComplete, setDownloadComplete] = useState(false)
  const [showCompletionMessage, setShowCompletionMessage] = useState(true)

  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const downloadIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const completionTimerRef = useRef<NodeJS.Timeout | null>(null)

  // 清理定时器
  useEffect(() => {
    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current)
      }
      if (downloadIntervalRef.current) {
        clearInterval(downloadIntervalRef.current)
      }
      if (completionTimerRef.current) {
        clearTimeout(completionTimerRef.current)
      }
    }
  }, [])

  // 重置状态
  useEffect(() => {
    if (!isOpen) {
      setTimeout(() => {
        setStep("confirm")
        setProgress(0)
        setScreenshotUrl(null)
        setIsPreviewOpen(false)
        setIsDownloading(false)
        setDownloadProgress(0)
        setDownloadComplete(false)
        setShowCompletionMessage(true)
      }, 300)
    }
  }, [isOpen])

  // 生成截图
  const generateScreenshot = async () => {
    if (!containerRef.current) return

    setStep("generating")

    // 模拟进度条
    progressIntervalRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          return prev
        }
        return prev + Math.random() * 5
      })
    }, 200)

    try {
      // 创建一个临时容器，复制消息内容
      const tempContainer = document.createElement("div")
      tempContainer.style.position = "absolute"
      tempContainer.style.left = "-9999px"
      tempContainer.style.width = `${containerRef.current.offsetWidth}px`
      tempContainer.style.backgroundColor = "transparent" // 透明背景
      tempContainer.style.padding = "20px"
      tempContainer.style.color = document.documentElement.classList.contains("dark") ? "white" : "black"

      // 添加标题
      const titleElement = document.createElement("h1")
      titleElement.textContent = title
      titleElement.style.fontSize = "24px"
      titleElement.style.fontWeight = "bold"
      titleElement.style.marginBottom = "20px"
      titleElement.style.textAlign = "center"
      titleElement.style.color = document.documentElement.classList.contains("dark") ? "white" : "black"
      tempContainer.appendChild(titleElement)

      // 复制消息内容
      const messagesClone = containerRef.current.cloneNode(true) as HTMLElement
      messagesClone.style.height = "auto"
      messagesClone.style.overflow = "visible"
      messagesClone.style.marginTop = "0"
      messagesClone.style.marginBottom = "0"
      messagesClone.style.paddingTop = "20px" // 增加顶部内边距，防止文字被遮挡
      messagesClone.style.paddingBottom = "20px" // 增加底部内边距，防止文字被遮挡

      // 移除滚动条和不必要的元素
      const scrollbars = messagesClone.querySelectorAll("::-webkit-scrollbar")
      scrollbars.forEach((scrollbar) => {
        ;(scrollbar as HTMLElement).style.display = "none"
      })

      tempContainer.appendChild(messagesClone)
      document.body.appendChild(tempContainer)

      // 使用html2canvas生成截图
      const canvas = await html2canvas(tempContainer, {
        scale: quality === "high" ? 8 : 4, // 提高分辨率，超清模式使用8倍缩放
        useCORS: true,
        logging: false,
        backgroundColor: null, // 透明背景
        allowTaint: false,
      })

      // 移除临时容器
      document.body.removeChild(tempContainer)

      // 将canvas转换为图片
      const image = canvas.toDataURL("image/png")
      setScreenshotUrl(image)

      // 设置进度为100%并完成
      setProgress(100)
      setTimeout(() => {
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current)
        }
        setStep("complete")
      }, 500)
    } catch (error) {
      console.error("截图生成失败:", error)
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current)
      }
      setStep("confirm")
      alert("截图生成失败，请重试")
    }
  }

  // 下载截图
  const downloadScreenshot = () => {
    if (!screenshotUrl) return

    setIsDownloading(true)

    // 模拟下载进度
    downloadIntervalRef.current = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 90) {
          return prev
        }
        return prev + Math.random() * 10
      })
    }, 100)

    setTimeout(() => {
      try {
        const link = document.createElement("a")
        link.href = screenshotUrl
        link.download = `${title || "聊天记录"}_${new Date().toISOString().slice(0, 10)}.png`
        link.click()

        // 设置下载进度为100%并完成
        setDownloadProgress(100)
        setTimeout(() => {
          if (downloadIntervalRef.current) {
            clearInterval(downloadIntervalRef.current)
          }
          setDownloadComplete(true)

          // 1秒后自动关闭
          completionTimerRef.current = setTimeout(() => {
            setShowCompletionMessage(false)
            setTimeout(() => {
              onClose()
            }, 300)
          }, 1000)
        }, 500)
      } catch (error) {
        console.error("下载失败:", error)
        if (downloadIntervalRef.current) {
          clearInterval(downloadIntervalRef.current)
        }
        setIsDownloading(false)
        alert("下载失败，请重试")
      }
    }, 1000)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/30 dark:bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      {isPreviewOpen ? (
        <div className="relative w-full max-w-3xl bg-transparent rounded-2xl overflow-hidden">
          <button
            onClick={() => setIsPreviewOpen(false)}
            className="absolute top-4 left-4 w-10 h-10 flex items-center justify-center rounded-full bg-black/10 dark:bg-white/10 text-black dark:text-white z-10"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M15 6L9 12L15 18"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          {screenshotUrl && (
            <div className="w-full h-[80vh] overflow-auto bg-transparent">
              <img src={screenshotUrl || "/placeholder.svg"} alt="截图预览" className="w-full h-auto" />
            </div>
          )}
        </div>
      ) : (
        <div className="w-full max-w-[320px] bg-transparent rounded-2xl p-6">
          {step === "confirm" && (
            <>
              <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">
                确定将 "{title}" 保存为截图吗？
              </h3>
              <div className="flex space-x-4 mb-4">
                <button
                  onClick={() => {
                    setQuality("normal")
                    generateScreenshot()
                  }}
                  className="flex-1 h-[48px] rounded-full bg-[#F5F5F7] dark:bg-[#2A2A2A] text-black dark:text-white text-[16px] font-[500]"
                >
                  普通
                </button>
                <button
                  onClick={() => {
                    setQuality("high")
                    generateScreenshot()
                  }}
                  className="flex-1 h-[48px] rounded-full bg-[#F5F5F7] dark:bg-[#2A2A2A] text-black dark:text-white text-[16px] font-[500]"
                >
                  超清
                </button>
              </div>
              <button
                onClick={onClose}
                className="w-full h-[48px] rounded-full border border-black/10 dark:border-white/10 text-black dark:text-white text-[16px] font-[500]"
              >
                取消
              </button>
            </>
          )}

          {step === "generating" && (
            <>
              <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">
                正在生成截图，请稍后...
              </h3>
              <div className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-full mb-6">
                <div
                  className="h-full bg-green-500 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </>
          )}

          {step === "complete" && !isDownloading && !downloadComplete && (
            <>
              <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">截图已生成</h3>
              <div className="flex space-x-4">
                <button
                  onClick={() => setIsPreviewOpen(true)}
                  className="flex-1 h-[48px] rounded-full bg-[#F5F5F7] dark:bg-[#2A2A2A] text-black dark:text-white text-[16px] font-[500]"
                >
                  预览
                </button>
                <button
                  onClick={downloadScreenshot}
                  className="flex-1 h-[48px] rounded-full bg-[#F5F5F7] dark:bg-[#2A2A2A] text-black dark:text-white text-[16px] font-[500]"
                >
                  下载
                </button>
              </div>
            </>
          )}

          {step === "complete" && isDownloading && !downloadComplete && (
            <>
              <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">正在下载...</h3>
              <div className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-full mb-6">
                <div
                  className="h-full bg-green-500 rounded-full transition-all duration-300"
                  style={{ width: `${downloadProgress}%` }}
                ></div>
              </div>
            </>
          )}

          {step === "complete" && downloadComplete && showCompletionMessage && (
            <>
              <h3 className="text-[18px] font-[600] text-black dark:text-white text-center mb-6">下载已完成</h3>
              <div className="flex justify-center">
                <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M20 6L9 17L4 12"
                      stroke="white"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  )
}

