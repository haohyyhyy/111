declare module "html2canvas" {
  interface Html2CanvasOptions {
    /** Whether to allow cross-origin images to taint the canvas */
    allowTaint?: boolean
    /** Canvas background color, if none is specified in DOM. Set null for transparent */
    backgroundColor?: string | null
    /** Define the heigt of the canvas in pixels. If null, renders with full height of the window. */
    height?: number | null
    /** Whether to render each letter separately. Necessary if letter-spacing is used. */
    letterRendering?: boolean
    /** Whether to log events in the console. */
    logging?: boolean
    /** Url to the proxy which is to be used for loading cross-origin images. If left empty, cross-origin images won't be loaded. */
    proxy?: string
    /** Whether to test each image if it taints the canvas before drawing them */
    taintTest?: boolean
    /** Whether to attempt to load cross-origin images as CORS served, before reverting back to proxy. */
    useCORS?: boolean
    /** Define the width of the canvas in pixels. If null, renders with full width of the window. */
    width?: number | null
    /** Window to use for rendering. Defaults to window object of the current document */
    windowHeight?: number
    /** Window to use for rendering. Defaults to window object of the current document */
    windowWidth?: number
    /** Canvas scale ratio */
    scale?: number
    /** Whether to use ForeignObject rendering if the browser supports it */
    foreignObjectRendering?: boolean
    /** A proxy for loading cross-origin images */
    imageTimeout?: number
    /** Whether to use the default canvas size (300x150) or the custom one */
    useDefaultCanvasSize?: boolean
    /** Whether to attempt using CORS images */
    useCORS?: boolean
    /** Window object to use as the document */
    x?: number
    /** Window object to use as the document */
    y?: number
  }

  export default function html2canvas(element: HTMLElement, options?: Html2CanvasOptions): Promise<HTMLCanvasElement>
}

