export const addUser = (user: any) => {
  // In a real application, this is where you would
  // make an API call to your backend to add the user.
  // For this example, we'll just log the user to the console.
  console.log("Adding user:", user)

  // Optimistically update local storage
  try {
    const storedUsers = localStorage.getItem("users")
    let users = storedUsers ? JSON.parse(storedUsers) : []
    users = [...users, user]
    localStorage.setItem("users", JSON.stringify(users))
  } catch (error) {
    console.error("Error updating local storage:", error)
    // Handle the error appropriately, e.g., show an error message to the user
  }
}

